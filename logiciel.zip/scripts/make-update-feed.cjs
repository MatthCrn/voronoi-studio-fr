// Generate the generic HTTPS feed after building NSIS. Publishing is a separate
// explicit step; no credentials or upstream repository are used by this script.
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const version = require('../package.json').version
const release = path.resolve(process.argv[2] || 'release')
const name = `Voronoi-Studio-FR-${version}-x64-installation.exe`
const file = path.join(release, name)
if (!fs.existsSync(file) || !fs.existsSync(`${file}.blockmap`)) throw Error('Construire l’installateur et son blockmap avant le flux de mise à jour.')
const sha512 = crypto.createHash('sha512').update(fs.readFileSync(file)).digest('base64')
const yaml = `version: ${JSON.stringify(version)}\nfiles:\n  - url: ${JSON.stringify(name)}\n    sha512: ${sha512}\n    size: ${fs.statSync(file).size}\npath: ${JSON.stringify(name)}\nsha512: ${sha512}\nreleaseDate: ${JSON.stringify(new Date().toISOString())}\nreleaseNotes: "Sélection multiple, groupes, fusion de panneaux et suppression avec emplacement vide, motif continu et exports préservés."\n`
fs.writeFileSync(path.join(release, 'latest.yml'), yaml)
console.log(`Flux prêt dans ${release} : latest.yml + installateur + blockmap. Aucun fichier publié.`)
