const api = window.voronoiDesktop?.updates
const byId = id => document.getElementById(id)
let initialized = false
const messages = {
  unconfigured: ['Service à configurer', 'Les mises à jour sont prêtes à être raccordées. Aucun hébergement n’est encore configuré ; le logiciel continue de fonctionner sans connexion.'],
  portable: ['Version portable', 'La mise à jour intégrée concerne la version installée. Pour cette version portable, remplacer le fichier de l’application.'],
  development: ['Version de développement', 'Les installations de mises à jour sont disponibles dans la version Windows installée.'],
  idle: ['Prêt à vérifier', 'La recherche ne transmet aucun dessin ni fichier de projet.'],
  checking: ['Recherche en cours…', 'Vérification des nouvelles versions.'],
  available: ['Une nouvelle version est disponible', 'Téléchargez-la maintenant ou continuez à travailler.'],
  current: ['Votre application est à jour', 'Aucune nouvelle version n’est disponible sur ce service.'],
  downloading: ['Téléchargement en cours…', 'Vous pouvez continuer à dessiner. Le redémarrage attendra votre choix.'],
  downloaded: ['La mise à jour est prête', 'Le logiciel redémarrera lorsque vous le déciderez.'],
  installing: ['Préparation du redémarrage…', 'Sauvegarde du dessin en cours avant l’installation.'],
  error: ['Mise à jour indisponible', 'Vous pouvez réessayer plus tard et continuer à utiliser cette version.'],
}
function render(s) {
  byId('version').textContent = `Voronoi Studio — Français · Version ${s.version}`
  const message = messages[s.phase] || messages.error
  byId('status').textContent = message[0] + (s.phase === 'available' ? ` (${s.nextVersion})` : '')
  byId('message').textContent = message[1]
  byId('error').textContent = s.error || ''
  byId('check').disabled = !s.url || ['checking', 'downloading', 'downloaded', 'installing', 'portable', 'development'].includes(s.phase)
  byId('download').hidden = s.phase !== 'available'
  byId('restart').hidden = s.phase !== 'downloaded'
  byId('progress').hidden = s.phase !== 'downloading'
  byId('progress').value = s.progress
  byId('notes').textContent = s.notes || ''
  byId('notes').hidden = !s.notes
  byId('save').disabled = ['checking', 'downloading', 'downloaded', 'installing'].includes(s.phase)
  if (!initialized) {
    byId('url').value = s.url
    byId('startup').checked = s.startup
    byId('settings').open = s.phase === 'unconfigured'
    initialized = true
  }
}
async function action(run) {
  try { render(await run()) } catch { byId('error').textContent = 'Cette action n’a pas abouti. Vérifiez l’adresse HTTPS du service puis réessayez.' }
}
if (api) {
  api.onChange(render)
  action(() => api.state())
  byId('check').onclick = () => action(() => api.check())
  byId('download').onclick = () => action(() => api.download())
  byId('restart').onclick = () => action(() => api.restart())
  byId('config').onsubmit = async event => {
    event.preventDefault()
    byId('save').disabled = true
    byId('result').textContent = ''
    try {
      render(await api.configure({ url: byId('url').value.trim(), startup: byId('startup').checked }))
      byId('result').textContent = 'Configuration enregistrée.'
      byId('error').textContent = ''
    } catch { byId('error').textContent = 'Configuration non enregistrée. Utilisez une adresse HTTPS sans identifiant, mot de passe ni paramètres, puis réessayez.' }
    finally { byId('save').disabled = false }
  }
} else {
  byId('status').textContent = 'Mises à jour Windows'
  byId('message').textContent = 'Ouvrez cette fenêtre depuis le menu Application de la version Windows.'
  byId('check').disabled = true
  byId('settings').hidden = true
}
