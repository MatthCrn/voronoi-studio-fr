# Voronoi Studio — Français

Version française 1.11.0 fondée sur Voronoi Studio 1.4.0 de Gilbert Chen.
Voir [NOTICE.md](NOTICE.md) et [LICENSE](LICENSE) pour l’attribution et les licences.

## Utilisation

**En ligne** : ouvrir le site publié. Tous les calculs et fichiers restent traités
dans le navigateur. L’application ne nécessite ni compte dans son moteur, ni serveur de calcul.
L’hébergement privé de prévisualisation peut demander une connexion à son propriétaire.

**Windows 64 bits** : lancer l’installateur `*-installation.exe` pour installer
l’application et créer ses raccourcis. Le fichier `*-portable.exe` permet aussi
de l’utiliser sans installation. La version PC fonctionne sans connexion et ne
charge aucun site distant. Cette première distribution n’est pas signée par un
certificat d’éditeur commercial.

1. Dans **Support**, choisir les dimensions, la forme et la bordure, ou importer un contour SVG.
2. Dans **Motif**, régler les cellules, la répartition, le gradient et la relaxation.
3. Déplacer, ajouter ou effacer les points à l’aide des outils et raccourcis.
4. Dans **Style**, choisir Lignes ou Ajours et régler l’épaisseur de matière et les arrondis.
5. Dans **Fichier**, enregistrer le projet ou exporter en SVG laser, DXF, SVG ou PNG.

Les points et lignes visibles sont aussi inclus dans les exports : masquer
**Points** et **Delaunay** si l’on souhaite uniquement les découpes.
Les exports représentent toujours le support entier et respectent ses dimensions réelles.

## Compatibilité et conservation

### Commandes simplifiées et contours organiques

Dans **Motif**, choisir **Uniforme**, **Dégradé** ou **Radial** pour les parois.
Le dégradé utilise deux épaisseurs et une direction ; le radial permet de choisir
le centre ou les bords. Une seule commande lie la taille des cellules aux parois.
Les réglages de points, la densité indépendante et la régularité sont repliés.

Dans **Style > Ajours > Contours**, choisir **Organiques**, puis régler
**Souplesse**. À 100 %, les côtés entiers deviennent courbes : les ajours prennent
une forme de galet et la matière se renfle aux jonctions. Le rendu peut être
combiné avec les variations d’épaisseur et de densité. L’arrondi des angles
reste disponible pour les contours géométriques.

Un arrondi minimal proportionnel à la taille de chaque cellule évite les pointes
aux angles aigus et aux côtés très courts. Aucun réglage supplémentaire n’est nécessaire.

Les courbes sont construites dans la géométrie réelle, puis approchées par des
arcs circulaires à une précision inférieure au micromètre. L’aperçu, le PNG,
le SVG et le DXF partagent ces contours. Les formes importées concaves utilisent
des segments fins et un découpage de sécurité pour conserver les limites et les
ponts de matière. L’effet rétrécit les ajours ; les trop petits restent pleins.
Il ne garantit pas un rayon minimal adapté à une fraise.

Les anciens projets conservent leurs paramètres détaillés, y compris ceux qui
ne sont plus proposés dans le panneau simplifié. Un bouton explicite permet
un retour aux réglages simples. Ouvrir un ancien projet n’active pas les courbes.
Les nouveaux projets utilisent la version 6 du format ; les versions 1 à 5
restent lisibles. Conserver une copie pour utiliser aussi l’ancienne application,
qui ne peut pas ouvrir le nouveau format.

Les épaisseurs et la souplesse réutilisent les points existants. La densité
recalcule les points et respecte la protection des retouches manuelles.
Les contours organiques et spatiaux sont calculés en arrière-plan ; les exports
sont bloqués pendant le calcul ou en cas d’erreur.

L’extension `.voronoi.json` est conservée : les projets originaux, y compris la
version 1 du format, restent lisibles. Les noms de calques SVG/DXF et les nombres
écrits dans ces fichiers ne sont pas traduits. La virgule française concerne les
nombres affichés dans l’interface.

Le site et l’application PC possèdent chacun leur propre sauvegarde de session.
Pour passer de l’un à l’autre, enregistrer un projet puis l’ouvrir dans l’autre.
Les projets ne sont pas synchronisés par un service en ligne.

## Développement et fabrication

Prérequis : Node.js 24 ou plus récent et pnpm 11.25.0.

```text
pnpm install --frozen-lockfile
pnpm test
pnpm run build
pnpm run dev
```

La sortie `dist/` peut être hébergée sur tout serveur statique HTTPS, y compris
GitHub Pages. Les chemins d’assets sont relatifs, comme dans le projet original.

Pour Windows :

```text
pnpm run desktop:install-runtime
pnpm run build
pnpm run desktop
pnpm run desktop:build
```

Les installateurs se trouvent dans `release/`. Sous Windows, utiliser un chemin
de travail court si NSIS refuse un chemin de dépendance trop long.

Le moteur de génération, de relaxation et d’export est celui du projet original.
Les modifications comprennent les textes français, le formatage d’affichage,
la variation spatiale intégrée et l’enveloppe Windows avec sa boîte native
d’enregistrement. Aucun nouveau paquet de dépendances n’est ajouté pour cette évolution.

## Mises à jour Windows

Ouvrir **Application > Mises à jour…**. Le mécanisme est intégré, mais attend
un hébergement HTTPS. Son adresse pourra être ajoutée dans cette fenêtre
sans réinstallation. Téléchargement puis redémarrage sur choix explicite,
avec sauvegarde immédiate de la session. Voir [le guide de distribution](docs/mises-a-jour.md).

## Rectangles d’or

Dans **Support**, saisir directement la largeur ou la hauteur et activer
**Rectangles d’or**. La galerie propose les quinze formes de Grosjean.
La dernière dimension saisie reste fixe ; l’autre suit le rapport choisi.
Le bouton de permutation change l’orientation. Désactiver l’interrupteur
conserve les dimensions obtenues. Voir [le fonctionnement et les rapports](docs/rectangles-or.md).

## Composition de panneaux

Le mode **Composition** répartit 1 à 24 panneaux dans un format global, avec
un **Jeu** constant. Proposer plusieurs compositions, glisser les panneaux et
les groupes, ajuster les séparations et verrouiller des éléments. Le motif
Voronoi peut habiller la sélection. Les contours et les lignes intérieures
possèdent des couleurs distinctes. Les plans et fichiers individuels SVG/DXF,
le tableau des dimensions et un ZIP complet sont disponibles dans Fichier.
Voir [le guide de composition](docs/composition.md).

## Nouveautés 1.10

Le style initial utilise des ajours organiques à 59 %, une largeur de matière de 8 mm et des traits bordeaux de 0,3 mm sur fond blanc, sans remplissage. Les anciens projets conservent leurs réglages. **Appliquer le style par défaut**, dans Style ou Habillage, permet de retrouver ce style sur un projet existant.

En Composition, le motif est unique et continu sur le format global, sans répétition par panneau. Les nouveaux panneaux reçoivent automatiquement leur partie du motif. **Afficher le motif** agit uniquement sur la vue : les exports conservent le motif appliqué. Pour une ancienne composition sans motif, utiliser **Appliquer le motif à tous les panneaux**. Le clic droit sur un panneau propose **Diviser en n…**, avec choix du nombre et du sens, respect du jeu, des dimensions minimales et des verrouillages.

## Nouveautés 1.11

**Ctrl + clic** sélectionne plusieurs panneaux. Le clic droit permet de **Grouper**, **Dégrouper**, **Fusionner en un panneau** ou **Supprimer et laisser vide**. Les mêmes commandes sont disponibles sous la sélection dans Panneaux. Les groupes conservent leurs jeux et leurs contours ; une fusion les supprime à l’intérieur du nouveau panneau. Les zones vides ne sont pas exportées. Clic droit sur un emplacement vide : **Créer un panneau ici**. Les projets sont enregistrés au format 7 pour conserver les groupes et les suppressions ; les versions antérieures restent lisibles par cette application.
