const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('voronoiDesktop', {
  saveFile: (filename, bytes) => ipcRenderer.invoke('save-design-file', { filename, bytes }),
  updates: {
    state: () => ipcRenderer.invoke('updates-state'),
    check: () => ipcRenderer.invoke('updates-check'),
    configure: config => ipcRenderer.invoke('updates-configure', config),
    download: () => ipcRenderer.invoke('updates-download'),
    restart: () => ipcRenderer.invoke('updates-restart'),
    onChange: callback => {
      const listener = (_event, state) => callback(state)
      ipcRenderer.on('updates-changed', listener)
      return () => ipcRenderer.removeListener('updates-changed', listener)
    },
  },
  onBeforeUpdate: callback => {
    const listener = async (_event, nonce) => {
      try { await ipcRenderer.invoke('updates-checkpoint', { nonce, ...callback() }) }
      catch { ipcRenderer.invoke('updates-checkpoint', { nonce, failed: true }).catch(() => {}) }
    }
    ipcRenderer.on('updates-before-restart', listener)
    return () => ipcRenderer.removeListener('updates-before-restart', listener)
  },
})
