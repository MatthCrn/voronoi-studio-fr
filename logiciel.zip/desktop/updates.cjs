const { EventEmitter } = require('node:events')

function updateUrl(value) {
  if (typeof value !== 'string' || value.length > 2048) throw Error('Adresse de mise à jour invalide.')
  const url = new URL(value)
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
    throw Error('Utilisez une adresse HTTPS sans identifiant, mot de passe ni paramètres.')
  }
  return url.href.replace(/\/?$/, '/')
}

// Electron is injected so the real update lifecycle can be tested without
// closing the editor, running an installer or contacting a production server.
class Updates extends EventEmitter {
  constructor({ version, portable, packaged, config, saveConfig, factory, checkpoint, install }) {
    super()
    Object.assign(this, { portable, packaged, saveConfig, factory, checkpoint, install })
    let url = ''
    try { if (config.url) url = updateUrl(config.url) } catch { /* remain offline */ }
    this.state = { version, url, startup: config.startup !== false, phase: 'idle', progress: 0, nextVersion: '', notes: '' }
    if (!url) this.state.phase = 'unconfigured'
    if (portable) this.state.phase = 'portable'
    if (!packaged) this.state.phase = 'development'
  }
  snapshot() { return { ...this.state } }
  set(patch) { Object.assign(this.state, patch); this.emit('change', this.snapshot()) }
  async configure({ url, startup }) {
    if (['checking', 'downloading', 'downloaded', 'installing'].includes(this.state.phase)) throw Error('Terminez la mise à jour en cours avant de changer son adresse.')
    const config = { url: url ? updateUrl(url) : '', startup: startup !== false }
    await this.saveConfig(config)
    this.updater = null
    this.set({ ...config, phase: this.portable ? 'portable' : !this.packaged ? 'development' : config.url ? 'idle' : 'unconfigured', error: '' })
  }
  client() {
    if (!this.updater) {
      const client = this.factory(this.state.url)
      client.autoDownload = false
      client.autoInstallOnAppQuit = false
      client.allowDowngrade = false
      client.allowPrerelease = false
      client.on('update-available', info => {
        const notes = typeof info.releaseNotes === 'string' ? info.releaseNotes : Array.isArray(info.releaseNotes)
          ? info.releaseNotes.map(n => n.note || '').join('\n') : ''
        this.set({ phase: 'available', nextVersion: String(info.version), notes: notes.slice(0, 12000) })
      })
      client.on('update-not-available', () => this.set({ phase: 'current', nextVersion: '', notes: '' }))
      client.on('download-progress', p => this.set({ progress: Math.max(0, Math.min(100, Number(p.percent) || 0)) }))
      client.on('update-downloaded', () => this.set({ phase: 'downloaded', progress: 100 }))
      client.on('error', () => this.fail())
      this.updater = client
    }
    return this.updater
  }
  fail() { this.set({ phase: 'error', error: 'La mise à jour n’a pas abouti. Vérifiez la connexion et l’adresse du service, puis réessayez. Votre version actuelle reste disponible.' }) }
  async check() {
    if (this.portable || !this.packaged || !this.state.url || ['checking', 'downloading', 'downloaded', 'installing'].includes(this.state.phase)) return this.snapshot()
    this.set({ phase: 'checking', error: '', progress: 0 })
    try { await this.client().checkForUpdates() } catch { this.fail() }
    return this.snapshot()
  }
  async download() {
    if (this.state.phase !== 'available') return this.snapshot()
    this.set({ phase: 'downloading', error: '', progress: 0 })
    try { await this.client().downloadUpdate() } catch { this.fail() }
    return this.snapshot()
  }
  async restart() {
    if (this.state.phase !== 'downloaded') return this.snapshot()
    this.set({ phase: 'installing', error: '' })
    try {
      if (!await this.checkpoint()) throw Error('No checkpoint')
      await this.install(this.client())
    } catch {
      this.set({ phase: 'downloaded', error: 'Le redémarrage a été annulé : la session n’a pas pu être sauvegardée ou l’installation n’a pas pu démarrer. Enregistrez votre projet et réessayez.' })
    }
    return this.snapshot()
  }
}
module.exports = { Updates, updateUrl }
