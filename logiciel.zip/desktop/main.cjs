const { app, BrowserWindow, Menu, dialog, ipcMain, net, protocol } = require('electron')
const path = require('node:path')
const { pathToFileURL } = require('node:url')
const { readFile, writeFile, rename, mkdir } = require('node:fs/promises')
const { randomUUID } = require('node:crypto')
const { Updates } = require('./updates.cjs')

const ORIGIN = 'voronoi://studio'
let editor, updateWindow, updates, pendingCheckpoint
function openUpdates() {
  if (updateWindow && !updateWindow.isDestroyed()) { updateWindow.show(); updateWindow.focus(); return }
  updateWindow = new BrowserWindow({
    width: 580, height: 650, minWidth: 480, minHeight: 520, parent: editor,
    title: 'Mises à jour — Voronoi Studio', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  })
  updateWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
  updateWindow.webContents.on('will-navigate', event => event.preventDefault())
  updateWindow.loadURL(`${ORIGIN}/updates.html`)
}
async function atomicJson(filename, data) {
  await mkdir(path.dirname(filename), { recursive: true })
  const temporary = `${filename}.tmp`
  await writeFile(temporary, JSON.stringify(data), 'utf8')
  await rename(temporary, filename)
}
async function checkpoint() {
  if (!editor || editor.isDestroyed() || pendingCheckpoint) return false
  editor.setEnabled(false)
  const success = await new Promise(resolve => {
    const nonce = randomUUID()
    const timer = setTimeout(() => {
      pendingCheckpoint = null; resolve(false)
    }, 8000)
    pendingCheckpoint = { nonce, finish: ok => { clearTimeout(timer); pendingCheckpoint = null; resolve(ok) } }
    editor.webContents.send('updates-before-restart', nonce)
  })
  if (!success && !editor.isDestroyed()) editor.setEnabled(true)
  return success
}
protocol.registerSchemesAsPrivileged([{ scheme: 'voronoi', privileges: {
  standard: true, secure: true, supportFetchAPI: true, corsEnabled: true,
} }])

function createWindow() {
  const window = new BrowserWindow({
    width: 1440, height: 960, minWidth: 720, minHeight: 600,
    title: 'Voronoi Studio — Français', backgroundColor: '#e5e9ee',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  })
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
  window.webContents.on('will-navigate', (event, url) => {
    const target = new URL(url)
    if (target.protocol !== 'voronoi:' || target.hostname !== 'studio') event.preventDefault()
  })
  window.loadURL(`${ORIGIN}/index.html`)
  return window
}

app.whenReady().then(async () => {
  const directory = path.join(app.getAppPath(), 'dist')
  protocol.handle('voronoi', async request => {
    const url = new URL(request.url)
    if (url.hostname !== 'studio' || request.method !== 'GET') return new Response(null, { status: 403 })
    let filename
    try { filename = path.resolve(directory, '.' + decodeURIComponent(url.pathname)) }
    catch { return new Response(null, { status: 400 }) }
    const relative = path.relative(directory, filename)
    if (relative.startsWith('..') || path.isAbsolute(relative)) return new Response(null, { status: 403 })
    try { return await net.fetch(pathToFileURL(filename).href) }
    catch { return new Response(null, { status: 404 }) }
  })
  // No remote documents or browser permissions are needed by this offline application.
  const { session } = require('electron')
  session.defaultSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false))
  ipcMain.handle('save-design-file', async (event, { filename, bytes } = {}) => {
    if (event.senderFrame?.url !== `${ORIGIN}/index.html`) return 'failed'
    if (typeof filename !== 'string' || path.basename(filename) !== filename || !/\.(json|svg|dxf|png|zip|csv)$/i.test(filename)) return 'failed'
    if (!(bytes instanceof Uint8Array) || bytes.length > 512 * 1024 * 1024) return 'failed'
    const window = BrowserWindow.fromWebContents(event.sender)
    const extension = path.extname(filename).slice(1)
    const result = await dialog.showSaveDialog(window, {
      title: 'Enregistrer le fichier', defaultPath: filename,
      filters: [{ name: extension.toUpperCase(), extensions: [extension] }],
    })
    if (result.canceled || !result.filePath) return 'cancelled'
    try { await writeFile(result.filePath, bytes); return 'saved' }
    catch { return 'failed' }
  })
  let config = {}
  const configFile = path.join(app.getPath('userData'), 'updates.json')
  try { config = JSON.parse(await readFile(configFile, 'utf8')) || {} } catch { /* no update service yet */ }
  const saveUpdateConfig = value => atomicJson(configFile, {
    provider: 'generic', updaterCacheDirName: 'voronoi-studio-fr-updater', ...value,
  })
  updates = new Updates({
    version: app.getVersion(), portable: !!process.env.PORTABLE_EXECUTABLE_FILE, packaged: app.isPackaged, config,
    saveConfig: saveUpdateConfig,
    factory: url => {
      const { NsisUpdater } = require('electron-updater')
      const client = new NsisUpdater({ provider: 'generic', url, channel: 'latest' })
      // The same user-writable JSON is valid YAML for electron-updater and
      // supplies its persistent download cache configuration as well as URL.
      client.updateConfigPath = configFile
      return client
    },
    checkpoint,
    install: client => { client.quitAndInstall(true, true) },
  })
  updates.on('change', state => {
    if (updateWindow && !updateWindow.isDestroyed()) updateWindow.webContents.send('updates-changed', state)
    if (state.phase === 'available' && (!updateWindow || updateWindow.isDestroyed())) openUpdates()
    if (['downloaded', 'error'].includes(state.phase) && editor && !editor.isDestroyed()) editor.setEnabled(true)
  })
  const updateAction = action => async (event, arg) => {
    if (event.sender !== updateWindow?.webContents || event.senderFrame?.url !== `${ORIGIN}/updates.html`) throw Error('Action non autorisée.')
    return action(arg)
  }
  ipcMain.handle('updates-state', updateAction(() => updates.snapshot()))
  ipcMain.handle('updates-check', updateAction(() => updates.check()))
  ipcMain.handle('updates-download', updateAction(() => updates.download()))
  ipcMain.handle('updates-restart', updateAction(() => updates.restart()))
  ipcMain.handle('updates-configure', updateAction(async arg => {
    await updates.configure({ url: arg?.url, startup: arg?.startup })
    return updates.snapshot()
  }))
  ipcMain.handle('updates-checkpoint', async (event, data) => {
    const pending = pendingCheckpoint
    if (!pending || data?.nonce !== pending.nonce || event.sender !== editor?.webContents || event.senderFrame?.url !== `${ORIGIN}/index.html`) return
    try {
      if (data.failed || typeof data.project !== 'string' || data.project.length > 32 * 1024 * 1024) throw Error('Missing session')
      const project = JSON.parse(data.project)
      if (project.schema !== 'voronoi-studio/project' || !Array.isArray(project.points) || !project.settings) throw Error('Invalid session')
      await atomicJson(path.join(app.getPath('userData'), 'update-session-backup.json'), { project, unsaved: !!data.unsaved })
      editor.webContents.session.flushStorageData()
      pending.finish(true)
    } catch { pending.finish(false) }
  })
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Application', submenu: [
      { label: 'Mises à jour…', click: openUpdates },
      { type: 'separator' },
      { label: 'À propos de Voronoi Studio', click: () => dialog.showMessageBox({
        type: 'info', title: 'Voronoi Studio — Français', message: 'Voronoi Studio — Français',
        detail: `Version ${app.getVersion()}\nAdaptation française de Voronoi Studio de Gilbert Chen.\nProjet original : github.com/gil336699/voronoi-studio\nLicence MIT — Copyright © 2026 Gilbert Chen.\nFonctionne entièrement sur votre ordinateur, sans connexion.`,
      }) },
      { type: 'separator' }, { label: 'Quitter', role: 'quit' },
    ] },
    { label: 'Édition', submenu: [
      { label: 'Couper', role: 'cut' }, { label: 'Copier', role: 'copy' },
      { label: 'Coller', role: 'paste' }, { label: 'Tout sélectionner', role: 'selectAll' },
    ] },
    { label: 'Fenêtre', submenu: [
      { label: 'Plein écran', role: 'togglefullscreen' }, { label: 'Réduire', role: 'minimize' },
    ] },
  ]))
  editor = createWindow()
  if (updates.state.startup && updates.state.url && app.isPackaged && !updates.portable) {
    const timer = setTimeout(() => updates.check(), 15000)
    timer.unref()
  }
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow() })
})
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
