import { buildGeometry, type PatternSettings } from '../voronoi/pattern'
import type { CustomShape } from '../voronoi/shape'
let points: Float64Array = new Float64Array()
let shapeSignature = ''
let sharedShape: CustomShape | null = null
self.onmessage = (event: MessageEvent<{ id: number; points?: Float64Array; settings: PatternSettings }>) => {
  const job = event.data
  if (job.points) points = job.points
  // Structured cloning changes object identity, so retain one canonical imported
  // shape to keep region/diagram caches effective for thickness-only jobs.
  const signature = JSON.stringify(job.settings.customShape)
  if (signature !== shapeSignature) { shapeSignature = signature; sharedShape = job.settings.customShape }
  else job.settings.customShape = sharedShape
  try { self.postMessage({ id: job.id, geometry: buildGeometry(points, job.settings) }) }
  catch (error) { self.postMessage({ id: job.id, error: error instanceof Error ? error.message : String(error) }) }
}
