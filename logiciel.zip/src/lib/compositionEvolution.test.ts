import { describe, expect, it } from 'vitest'
import { dividePanel, panelNodes, panelRects, placeLayout, proposal, sanitizeLayout, type LayoutNode } from './composition'
import { DEFAULTS, LEGACY_DEFAULTS, REFERENCE_STYLE, sanitizeSettings } from './settings'
import { parseProject, serializeProject } from './project'
import { planChange } from './changes'
import { buildGeometry } from '../voronoi/pattern'
import { buildPanelGeometries, compositionDxf, compositionSvg, panelDxf, panelLaser } from './compositionExport'

const single: LayoutNode = { kind: 'panel', id: 'P01', locked: false, pattern: true }
describe('panel subdivision', () => {
  it.each(['x', 'y'] as const)('creates equal physical panels with the exact jeu on %s', axis => {
    for (const n of [2, 3, 5, 24]) {
      const result = dividePanel(single, 'P01', n, axis, 1500, 1200, 4, 20)!
      const panels = panelRects(result.tree, 1500, 1200, 4)
      expect(panels).toHaveLength(n)
      const size = ((axis === 'x' ? 1500 : 1200) - (n - 1) * 4) / n
      panels.forEach((p, i) => {
        expect(axis === 'x' ? p.width : p.height).toBeCloseTo(size, 8)
        expect(axis === 'x' ? p.x : p.y).toBeCloseTo(i * (size + 4), 8)
        expect(p.node.pattern).toBe(true)
      })
      expect(sanitizeLayout(result.tree)).toEqual(result.tree)
    }
  })
  it('preserves neighbours, locks and original identity, and rejects impossible divisions', () => {
    const tree: LayoutNode = { kind: 'split', id: 'divide01', axis: 'x', ratio: .5, a: single, b: { ...single, id: 'P02', locked: true, pattern: false } }
    const next = dividePanel(tree, 'P01', 3, 'y', 600, 400, 3, 20)!
    expect(panelRects(next.tree, 600, 400, 3).find(p => p.node.id === 'P02')).toEqual(panelRects(tree, 600, 400, 3).find(p => p.node.id === 'P02'))
    const ids = placeLayout(next.tree, 600, 400, 3).map(p => p.node.id)
    expect(new Set(ids).size).toBe(ids.length)
    expect(ids).toContain('P01')
    expect(dividePanel(tree, 'P02', 2, 'x', 600, 400, 3, 20)).toBeNull()
    for (const n of [0, 1, 2.5, NaN, Infinity, 25]) expect(dividePanel(single, 'P01', n, 'x', 600, 400, 3, 20)).toBeNull()
    expect(dividePanel(single, 'P01', 4, 'x', 80, 100, 3, 20)).toBeNull()
    expect(dividePanel(next.tree, next.groupId, 2, 'x', 600, 400, 3, 20)).toBeNull()
  })
})
describe('continuous panel artwork and visibility', () => {
  const tree: LayoutNode = { kind: 'split', id: 'root', axis: 'x', ratio: .5, a: single, b: { ...single, id: 'P02' } }
  const s = { ...DEFAULTS, width: 300, height: 180, border: 0, compositionEnabled: true, compositionTree: tree, compositionJeu: 4, cellStyle: 'lines' as const, organicEnabled: false }
  const points = Float64Array.from([30, 40, 110, 130, 230, 30, 270, 150])
  const base = buildGeometry(points, s)
  it('creates new panels with the motif applied and uses different parts of one global motif', () => {
    expect(panelNodes(proposal(null, 6, 600, 400, 3, 20, 1)!).every(p => p.pattern)).toBe(true)
    const panels = buildPanelGeometries(base, s)
    expect(panels.every(p => p.geometry.edges.internal.length > 0)).toBe(true)
    for (const panel of panels) for (const [x, y, bx, by] of panel.geometry.edges.internal) {
      expect(base.edges.internal.some(([a, b, c, d]) => Math.abs((x - a) * (d - b) - (y - b) * (c - a)) < 1e-6 && Math.abs((bx - a) * (d - b) - (by - b) * (c - a)) < 1e-6)).toBe(true)
    }
    expect(panelLaser(panels[0])).not.toEqual(panelLaser(panels[1]))
  })
  it('keeps motifs and outer contours in vector exports even when the preview is hidden', () => {
    const visible = buildPanelGeometries(base, s), hidden = buildPanelGeometries(base, { ...s, compositionShowPattern: false })
    expect(compositionSvg(hidden, s)).toBe(compositionSvg(visible, s))
    expect(compositionDxf(hidden)).toBe(compositionDxf(visible))
    hidden.forEach(p => {
      expect(panelLaser(p)).toContain('id="cut-inner"')
      expect(panelLaser(p)).toContain('id="cut-outer"')
      expect(panelDxf(p)).toContain('CUT_INNER')
      expect(panelDxf(p)).toContain('CUT_OUTER')
    })
    const change = planChange({ settings: s, points, handEdited: true, stale: false }, { compositionShowPattern: false })
    expect(change.next.points).toBe(points)
    expect(change.remake).toBe(false)
    expect(change.next.settings.compositionTree).toEqual(tree)
  })
})
describe('reference style and older documents', () => {
  it('uses the requested style for new documents, and preserves old missing defaults', () => {
    expect(DEFAULTS).toMatchObject(REFERENCE_STYLE)
    expect(DEFAULTS.organicAmount).toBe(59)
    const legacy = parseProject(JSON.stringify({ schema: 'voronoi-studio/project', version: 1, settings: {}, points: [] }))
    expect(legacy.settings.organicEnabled).toBe(false)
    expect(legacy.settings.cellStyle).toBe(LEGACY_DEFAULTS.cellStyle)
    const fresh = parseProject(serializeProject({ settings: DEFAULTS, points: new Float64Array(), handEdited: false }))
    expect(fresh.settings).toEqual(DEFAULTS)
    expect(sanitizeSettings({ compositionShowPattern: false }).compositionShowPattern).toBe(false)
  })
})
