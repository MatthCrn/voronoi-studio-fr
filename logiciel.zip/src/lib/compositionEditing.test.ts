import { describe, expect, it } from 'vitest'
import { deletePanels, groupSelection, isolateSelection, mergePanels, sanitizeGroups, selectionContainer, swapGroupAt, updateSelection } from './compositionEditing'
import { dividePanel, hasLocked, moveElement, moveSeparation, panelNodes, panelRects, placeLayout, proposal, replaceNode, respectsLocks, sanitizeLayout, type LayoutNode } from './composition'
import { DEFAULTS, sanitizeSettings, type Settings } from './settings'
import { parseProject, serializeProject, VERSION } from './project'
import { planChange } from './changes'
import { emptyHistory, record, redo, undo } from './history'
import { buildGeometry } from '../voronoi/pattern'
import { buildPanelGeometries, compositionCsv, compositionDxf, compositionSvg } from './compositionExport'

const panel = (id: string, locked = false): LayoutNode => ({ kind: 'panel', id, locked, pattern: true })
const tree: LayoutNode = { kind: 'split', id: 'root', axis: 'x', ratio: .5,
  a: { kind: 'split', id: 'left', axis: 'y', ratio: .5, a: panel('P01'), b: panel('P02') },
  b: { kind: 'split', id: 'right', axis: 'y', ratio: .5, a: panel('P03'), b: panel('P04') } }
const rects = (n: LayoutNode) => panelRects(n, 600, 400, 4)
const boxes = (n: LayoutNode) => rects(n).map(({ node, x, y, width, height }) => ({ id: node.id, x, y, width, height }))
describe('grouped panel editing', () => {
  it('saves disjoint groups, keeps unselected group members, and rejects untrusted memberships', () => {
    expect(groupSelection([['P01', 'P02', 'P03']], ['P03', 'P04'])).toEqual([['P01', 'P02'], ['P03', 'P04']])
    expect(sanitizeGroups([['P01', 'P01', 'P02', 5], ['P02', 'P03', 'P04'], ['missing']], tree)).toEqual([['P01', 'P02'], ['P03', 'P04']])
    expect(sanitizeSettings({ compositionTree: tree, compositionGroups: 'invalid' }).compositionGroups).toEqual([])
    expect(selectionContainer(tree, ['P01'])?.id).toBe('P01')
    expect(selectionContainer(tree, ['P01', 'P02'])?.id).toBe('left')
    expect(selectionContainer(tree, ['P01', 'P03'])).toBeNull()
    const locked = updateSelection(tree, ['P01', 'P03'], { locked: true })
    expect(rects(locked).filter(p => p.node.locked).map(p => p.node.id)).toEqual(['P01', 'P03'])
    expect(boxes(locked)).toEqual(boxes(tree))
  })
  it('isolates adjacent panels across old divisions without moving them, then moves them together', () => {
    const group = isolateSelection(tree, ['P01', 'P03'], 600, 400, 4)!
    expect(group).not.toBeNull()
    expect(boxes(group.tree).sort((a, b) => a.id.localeCompare(b.id))).toEqual(boxes(tree).sort((a, b) => a.id.localeCompare(b.id)))
    expect(panelNodes(selectionContainer(group.tree, ['P01', 'P03'])!).map(p => p.id)).toEqual(['P01', 'P03'])
    const moved = moveElement(group.tree, group.id, 'P02', 'centre', 600, 400, 4, 20)!
    expect(moved).not.toBeNull()
    const a = rects(moved).find(p => p.node.id === 'P01')!, b = rects(moved).find(p => p.node.id === 'P03')!
    expect(a.y).toBeCloseTo(b.y); expect(b.x - a.x - a.width).toBeCloseTo(4)
  })
  it('moves a nonrectangular group rigidly between matching sets of slots and protects target locks', () => {
    let layout = dividePanel(panel('P01'), 'P01', 3, 'x', 606, 403, 3, 20)!.tree
    for (const id of panelNodes(layout).map(p => p.id)) layout = dividePanel(layout, id, 2, 'y', 606, 403, 3, 20)!.tree
    const panels = panelRects(layout, 606, 403, 3), columns = [...panels].sort((a, b) => a.x - b.x || a.y - b.y)
    const ids = [columns[0].node.id, columns[3].node.id], target = columns[2].node.id
    const moved = swapGroupAt(layout, ids, ids[0], target, 606, 403, 3)!
    expect(moved).not.toBeNull()
    const after = panelRects(moved, 606, 403, 3), dx = columns[2].x - columns[0].x
    for (const id of ids) {
      const before = panels.find(p => p.node.id === id)!, result = after.find(p => p.node.id === id)!
      expect(result.x - before.x).toBeCloseTo(dx); expect(result.y).toBeCloseTo(before.y)
      expect(result.width).toBeCloseTo(before.width); expect(result.height).toBeCloseTo(before.height)
    }
    expect(swapGroupAt(replaceNode(layout, target, panel(target, true)), ids, ids[0], target, 606, 403, 3)).toBeNull()
  })
})
describe('merge and vacant positions', () => {
  it('inverts a subdivision and removes all internal gaps', () => {
    const divided = dividePanel(panel('P01'), 'P01', 5, 'x', 600, 400, 4, 20)!.tree
    const result = mergePanels(divided, panelNodes(divided).map(p => p.id), 600, 400, 4)
    expect('error' in result).toBe(false)
    if ('error' in result) throw Error(result.error)
    expect(rects(result.tree)).toHaveLength(1)
    expect(rects(result.tree)[0]).toMatchObject({ x: 0, y: 0, width: 600, height: 400 })
    expect(result.tree).toEqual(panel('P01'))
  })
  it('merges a rectangle across old partitions and preserves all other boxes and locks', () => {
    const original = replaceNode(tree, 'P04', panel('P04', true))
    const result = mergePanels(original, ['P01', 'P03'], 600, 400, 4)
    if ('error' in result) throw Error(result.error)
    expect(rects(result.tree)).toHaveLength(3)
    expect(rects(result.tree).find(p => p.node.id === result.id)).toMatchObject({ x: 0, y: 0, width: 600, height: 198 })
    for (const id of ['P02', 'P04']) expect(boxes(result.tree).find(p => p.id === id)).toEqual(boxes(original).find(p => p.id === id))
    expect(respectsLocks(original, result.tree, 600, 400, 4)).toBe(true)
    expect(sanitizeLayout(result.tree)).toEqual(result.tree)
    expect(mergePanels(original, ['P03', 'P04'], 600, 400, 4)).toHaveProperty('error')
    expect(mergePanels(tree, ['P01', 'P04'], 600, 400, 4)).toHaveProperty('error')
    expect(mergePanels(tree, ['P01', 'P02', 'P03'], 600, 400, 4)).toHaveProperty('error')
  })
  it('deletes only chosen panels, allows deleting every panel, and never collapses neighbours', () => {
    const next = deletePanels(tree, ['P01'])!
    expect(rects(next)).toHaveLength(3)
    expect(boxes(next)).toEqual(boxes(tree).filter(p => p.id !== 'P01'))
    expect(placeLayout(next, 600, 400, 4).find(p => p.node.id === 'P01')!.node).toMatchObject({ empty: true, locked: false, pattern: false })
    expect(selectionContainer(next, ['P02'])?.id).toBe('P02')
    expect(mergePanels(next, ['P02', 'P03', 'P04'], 600, 400, 4)).toHaveProperty('error')
    const all = deletePanels(tree, panelNodes(tree).map(p => p.id))!
    expect(panelNodes(all)).toHaveLength(0)
    expect(sanitizeLayout(all)).toEqual(all)
    expect(deletePanels(replaceNode(tree, 'P01', panel('P01', true)), ['P01', 'P02'])).toBeNull()
    const proposed = proposal(next, 3, 600, 400, 4, 20, 6)!
    expect(proposed).not.toBeNull()
    expect(sanitizeLayout(proposed)).toEqual(proposed)
  })
  it('does not restore deleted panels when drawing or exporting, and round-trips groups and vacancies', () => {
    const next = deletePanels(tree, ['P01'])!
    const settings = { ...DEFAULTS, width: 600, height: 400, cellStyle: 'lines' as const, compositionEnabled: true, compositionTree: next, compositionGroups: [['P03', 'P04']] }
    const points = Float64Array.from([40, 40, 200, 300, 330, 80, 510, 300])
    const saved = serializeProject({ settings, points, handEdited: true }), back = parseProject(saved)
    expect(VERSION).toBe(7); expect(back.settings).toEqual(settings)
    const panels = buildPanelGeometries(buildGeometry(points, { ...settings, border: 0 }), settings)
    expect(panels.map(p => p.panel.node.id)).toEqual(['P02', 'P03', 'P04'])
    expect(compositionSvg(panels, settings)).not.toContain('id="P01"')
    expect(compositionDxf(panels)).not.toContain('P01_CUT_')
    expect(compositionCsv(panels, settings)).not.toContain('P01;')
    expect(panels.every(p => p.geometry.edges.internal.length > 0)).toBe(true)
    const changed = planChange({ settings, points, handEdited: true, stale: false }, { compositionGroups: [['P01', 'P02'], ['P03', 'P04']] })
    expect(changed.next.settings.compositionGroups).toEqual([['P03', 'P04']])
    expect(changed.next.points).toBe(points); expect(changed.remake).toBe(false)
    expect(hasLocked(back.settings.compositionTree)).toBe(false)
  })
  it('undoes a deletion or fusion atomically, with its groups and counts', () => {
    const before: Settings = { ...DEFAULTS, compositionTree: tree, compositionCount: 4, compositionGroups: [['P01', 'P02']] }
    const nextTree = deletePanels(tree, ['P01', 'P02'])!
    const after = { ...before, compositionTree: nextTree, compositionCount: 2, compositionGroups: [] }
    const history = record(emptyHistory<typeof before>(), before, 'delete:once')
    const back = undo(history, after)!
    expect(back.state).toEqual(before)
    expect(redo(back.history, back.state)!.state).toEqual(after)
  })
  it('keeps separators and saved geometry valid when a vacant area is reduced to its limit', () => {
    const layout = deletePanels(tree, ['P01', 'P02'])!
    const moved = moveSeparation(layout, 'root', -500, 600, 400, 4, 20)!
    expect(moved).not.toBeNull()
    expect(sanitizeLayout(moved.tree)).toEqual(moved.tree)
    const withLocks = replaceNode(layout, 'P04', panel('P04', true))
    const next = proposal(withLocks, 2, 600, 400, 4, 20, 5)!
    expect(next).not.toBeNull()
    expect(respectsLocks(withLocks, next, 600, 400, 4)).toBe(true)
  })
  it('retains real coordinates through repeated merges and deletions over many generated layouts', () => {
    for (let seed = 1; seed <= 25; seed++) {
      const layout = proposal(null, 12, 1200, 600, 4, 20, seed)!
      const branches = placeLayout(layout, 1200, 600, 4).filter(p => p.node.kind === 'split' && panelNodes(p.node).length === 2)
      for (const branch of branches) {
        const ids = panelNodes(branch.node).map(p => p.id)
        const merged = mergePanels(layout, ids, 1200, 600, 4)
        if ('error' in merged) throw Error(merged.error)
        expect(sanitizeLayout(merged.tree)).toEqual(merged.tree)
        const after = panelRects(merged.tree, 1200, 600, 4)
        const piece = after.find(p => p.node.id === merged.id)!
        for (const key of ['x', 'y', 'width', 'height'] as const) expect(piece[key]).toBeCloseTo(branch[key], 7)
        const deleted = deletePanels(merged.tree, [merged.id])!
        expect(sanitizeLayout(deleted)).toEqual(deleted)
        expect(panelNodes(deleted)).toHaveLength(10)
      }
    }
  })
})
