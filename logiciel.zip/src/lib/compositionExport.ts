import type { Geometry } from '../voronoi/pattern'
import type { Settings } from './settings'
import { area, clipConvex, type Polygon, type Segment } from '../voronoi/geometry'
import { makeHoles, type Hole } from '../voronoi/holes'
import { organicActive, organicHoles } from '../voronoi/organic'
import { makeSpatialHoles } from '../voronoi/spatialHoles'
import { spatialConfig } from '../voronoi/spatial'
import type { Region } from '../voronoi/region'
import { panelRects, type Box, type PanelNode, type PlacedNode } from './composition'
import { artworkSvg, laserSvg } from './svgExport'
import { cutDxf } from './dxfExport'
import { num } from './cutPaths'
export type PanelGeometry = { panel: PlacedNode & { node: PanelNode }; geometry: Geometry; settings: Settings }
const region = (p: Box): Region => ({ shape: 'rect', x0: p.x, y0: p.y, x1: p.x + p.width, y1: p.y + p.height })
const polygon = (p: Box): Polygon => [[p.x, p.y], [p.x + p.width, p.y], [p.x + p.width, p.y + p.height], [p.x, p.y + p.height]]
function clipSegment(segment: Segment, p: Box): Segment | null {
  const [x, y, bx, by] = segment, dx = bx - x, dy = by - y
  let lo = 0, hi = 1
  for (const [a, b] of [[-dx, x - p.x], [dx, p.x + p.width - x], [-dy, y - p.y], [dy, p.y + p.height - y]]) {
    if (Math.abs(a) < 1e-12) { if (b < 0) return null; continue }
    const t = b / a
    if (a < 0) lo = Math.max(lo, t); else hi = Math.min(hi, t)
    if (lo > hi) return null
  }
  return [x + lo * dx, y + lo * dy, x + hi * dx, y + hi * dy]
}
export function buildPanelGeometries(base: Geometry, s: Settings): PanelGeometry[] {
  if (!s.compositionTree) return []
  return panelRects(s.compositionTree, s.width, s.height, s.compositionJeu).map(panel => {
    const sheet = region(panel)
    const active = panel.node.pattern
    const border = active ? Math.min(s.border, Math.min(panel.width, panel.height) / 3) : 0
    const inset = active && s.cellStyle === 'holes' && !s.spatialEnabled ? Math.max(0, border - s.web / 2) : border
    const box = { x: panel.x + inset, y: panel.y + inset, width: Math.max(.001, panel.width - 2 * inset), height: Math.max(.001, panel.height - 2 * inset) }
    const clip = polygon(box)
    const cells = active ? base.cells.map(cell => {
      const pieces = cell?.map(p => clipConvex(p, clip)).filter(p => p.length >= 3 && area(p) > 1e-8) ?? []
      return pieces.length ? pieces : null
    }) : []
    let holes: Hole[] = []
    if (active && s.cellStyle === 'holes') {
      if (s.spatialEnabled) holes = makeSpatialHoles(cells, { ...spatialConfig(s), cornerRadius: s.cornerRadius, organicEnabled: s.organicEnabled, organicAmount: s.organicAmount }, base.region, sheet).holes
      else cells.forEach((cell, i) => {
        if (!cell) return
        const raw = makeHoles(cell, i, { web: s.web, radius: organicActive(s) ? 0 : s.cornerRadius, minHole: s.minHole })
        holes.push(...(organicActive(s) ? organicHoles(raw, s.organicAmount, s.minHole) : raw))
      })
    }
    const edges = active ? base.edges.internal.map(e => clipSegment(e, box)).filter((e): e is Segment => !!e) : []
    const geometry: Geometry = { sheet, region: region(box), cells, edges: { internal: edges }, holes, delaunay: [], metrics: { ...base.metrics, cells: cells.filter(Boolean).length, holes: holes.length } }
    const settings = { ...s, border, shape: 'rect' as const, customShape: null, showEdges: active, showSites: false, showDelaunay: false, sheetOutline: true }
    return { panel, geometry, settings }
  })
}
export const svgBody = (svg: string) => svg.slice(svg.indexOf('>', svg.indexOf('<svg')) + 1, svg.lastIndexOf('</svg>'))
export function panelArtwork(p: PanelGeometry): string {
  return svgBody(artworkSvg(p.geometry, new Float64Array(), p.settings)).replace(/id="([^"]+)"/g, `id="${p.panel.node.id}-$1"`)
}
export function localPanel(p: PanelGeometry): PanelGeometry {
  const { x, y, width, height } = p.panel
  const point = ([a, b]: [number, number]): [number, number] => [a - x, b - y]
  const shiftRegion = (r: Region): Region => ({ ...r, x0: r.x0 - x, y0: r.y0 - y, x1: r.x1 - x, y1: r.y1 - y })
  return { panel: { ...p.panel, x: 0, y: 0 }, settings: { ...p.settings, width, height }, geometry: {
    ...p.geometry, sheet: shiftRegion(p.geometry.sheet), region: shiftRegion(p.geometry.region),
    cells: p.geometry.cells.map(cell => cell?.map(poly => poly.map(point)) ?? null),
    edges: { internal: p.geometry.edges.internal.map(([a, b, c, d]) => [a - x, b - y, c - x, d - y]) },
    holes: p.geometry.holes.map(h => ({ ...h, outline: { ...h.outline, points: h.outline.points.map(point) } })),
  } }
}
export const panelLaser = (p: PanelGeometry) => { const q = localPanel(p); return laserSvg(q.geometry, new Float64Array(), q.settings) }
export const panelDxf = (p: PanelGeometry) => { const q = localPanel(p); return cutDxf(q.geometry, new Float64Array(), q.settings) }
export function compositionSvg(panels: PanelGeometry[], s: Settings, labels = true): string {
  const unit = s.units === 'in' ? 'in' : 'mm', factor = unit === 'in' ? 1 / 25.4 : 1
  let out = `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${num(s.width * factor, 6)}${unit}" height="${num(s.height * factor, 6)}${unit}" viewBox="0 0 ${num(s.width)} ${num(s.height)}"><title>Composition de panneaux</title><desc>Format ${num(s.width)} × ${num(s.height)} mm ; jeu ${num(s.compositionJeu)} mm. Aucun jeu périphérique ajouté.</desc>`
  for (const p of panels) {
    out += `<g id="${p.panel.node.id}">${panelArtwork(p)}<rect x="${num(p.panel.x)}" y="${num(p.panel.y)}" width="${num(p.panel.width)}" height="${num(p.panel.height)}" fill="none" stroke="${s.panelContourColor}" stroke-width="${num(s.width / 1800)}"/></g>`
    if (labels) {
      const font = Math.min(p.panel.width / 13, p.panel.height / 5, s.width / 80)
      out += `<text x="${num(p.panel.x + p.panel.width / 2)}" y="${num(p.panel.y + p.panel.height / 2)}" text-anchor="middle" font-family="sans-serif" font-size="${num(font)}" fill="#24384c" stroke="#ffffff" stroke-width="${num(font / 6)}" paint-order="stroke">${p.panel.node.id} · ${num(p.panel.width, 2)} × ${num(p.panel.height, 2)} mm</text>`
    }
  }
  return `${out}</svg>`
}
// Assemble valid R12 tables and entities, with one layer prefix per panel.
export function compositionDxf(panels: PanelGeometry[]): string {
  if (!panels.length) return ''
  const files = panels.map(p => cutDxf(p.geometry, new Float64Array(), p.settings).replace(/\n(CUT_INNER|CUT_OUTER|SITES|DELAUNAY)\n/g, `\n${p.panel.node.id}_$1\n`))
  const records = files.map(f => f.slice(f.indexOf('\n0\nLAYER\n') + 1, f.indexOf('0\nENDTAB\n'))).join('')
  const count = (records.match(/0\nLAYER\n/g) ?? []).length
  const tables = `0\nTABLE\n2\nLAYER\n70\n${count}\n${records}0\nENDTAB\n`
  const first = files[0], start = first.indexOf('0\nTABLE\n2\nLAYER\n'), end = first.indexOf('0\nENDTAB\n') + '0\nENDTAB\n'.length
  const header = first.slice(0, start) + tables + first.slice(end, first.indexOf('0\nSECTION\n2\nENTITIES\n'))
  const entities = files.map(f => f.slice(f.indexOf('0\nSECTION\n2\nENTITIES\n') + '0\nSECTION\n2\nENTITIES\n'.length, f.lastIndexOf('0\nENDSEC\n'))).join('')
  return `${header}0\nSECTION\n2\nENTITIES\n${entities}0\nENDSEC\n0\nEOF\n`
}
export function compositionCsv(panels: PanelGeometry[], s: Settings): string {
  return '\ufeff' + ['Panneau;Largeur_mm;Hauteur_mm;Position_X_mm;Position_Y_mm;Jeu_mm;Motif;Verrouille', ...panels.map(p => [p.panel.node.id, ...[p.panel.width, p.panel.height, p.panel.x, p.panel.y, s.compositionJeu].map(v => num(v, 4).replace('.', ',')), p.panel.node.pattern ? 'Voronoi' : 'Plein', p.panel.node.locked ? 'Oui' : 'Non'].join(';'))].join('\r\n')
}
export async function compositionPng(svg: string, width: number, height: number): Promise<Blob | null> {
  const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }))
  try {
    const image = new Image(); image.src = url
    await image.decode()
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height
    const ctx = canvas.getContext('2d'); if (!ctx) return null
    ctx.drawImage(image, 0, 0, width, height)
    return await new Promise(resolve => canvas.toBlob(resolve, 'image/png'))
  } catch { return null } finally { URL.revokeObjectURL(url) }
}
