import { describe, expect, it } from 'vitest'
import { hasLocked, layoutProblem, minimumBox, moveElement, moveSeparation, panelRects, placeLayout, proposal, replaceNode, resizeElement, respectsLocks, sanitizeLayout, type LayoutNode } from './composition'
import { DEFAULTS } from './settings'
import { parseProject, serializeProject } from './project'
import { planChange } from './changes'
import { buildGeometry } from '../voronoi/pattern'
import { buildPanelGeometries, compositionCsv, compositionDxf, compositionSvg, localPanel, panelDxf, panelLaser } from './compositionExport'
import { flattenOrganic } from '../voronoi/organic'
import { zipFiles } from './zip'
const p = (id: string, locked = false): LayoutNode => ({ kind: 'panel', id, locked, pattern: false })
const tree: LayoutNode = { kind: 'split', id: 'root', axis: 'x', ratio: .5, a: p('P01'), b: { kind: 'split', id: 'right', axis: 'y', ratio: .5, a: p('P02'), b: p('P03') } }
const previous = () => ({ settings: { ...DEFAULTS, compositionEnabled: true, compositionTree: tree, width: 300, height: 200 }, points: Float64Array.from([30, 30, 160, 70, 280, 180]), handEdited: true, stale: false })
describe('multi-panel composition geometry', () => {
  it('places an exact jeu once at every division, with no peripheral gap', () => {
    const panels = panelRects(tree, 300, 200, 4)
    expect(panels.map(p => [p.x, p.y, p.width, p.height])).toEqual([[0, 0, 148, 200], [152, 0, 148, 98], [152, 102, 148, 98]])
    expect(layoutProblem(tree, 300, 200, 4, 20)).toBeNull()
    expect(minimumBox(tree, 20, 4)).toEqual({ width: 44, height: 44 })
  })
  it('produces repeatable varied layouts within bounds, with unique identities and no overlap', () => {
    const signatures = new Set<string>()
    for (const count of [2, 6, 12, 24]) for (let seed = 1; seed <= 12; seed++) {
      const result = proposal(null, count, 1200, 600, 3, 25, seed)!
      expect(result).not.toBeNull()
      expect(proposal(null, count, 1200, 600, 3, 25, seed)).toEqual(result)
      expect(sanitizeLayout(result)).toEqual(result)
      const panels = panelRects(result, 1200, 600, 3)
      expect(panels.length).toBe(count)
      for (const [i, a] of panels.entries()) {
        expect(Math.min(a.width, a.height)).toBeGreaterThanOrEqual(25 - 1e-7)
        expect(a.x).toBeGreaterThanOrEqual(0); expect(a.y).toBeGreaterThanOrEqual(0)
        expect(a.x + a.width).toBeLessThanOrEqual(1200 + 1e-7); expect(a.y + a.height).toBeLessThanOrEqual(600 + 1e-7)
        for (const b of panels.slice(i + 1)) expect(Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) <= 1e-7 || Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) <= 1e-7).toBe(true)
      }
      if (count === 2) signatures.add(JSON.stringify(result))
    }
    expect(signatures.size).toBeGreaterThan(2)
    expect(proposal(null, 24, 20, 20, 5, 10, 1)).toBeNull()
  }, 15000)
  it('keeps locked positions and dimensions through proposals and refuses conflicting edits', () => {
    const locked = replaceNode(tree, 'P01', p('P01', true))
    expect(hasLocked(locked)).toBe(true)
    for (let seed = 1; seed < 10; seed++) {
      const next = proposal(locked, 3, 300, 200, 4, 20, seed)!
      expect(respectsLocks(locked, next, 300, 200, 4)).toBe(true)
      expect(sanitizeLayout(next)).toEqual(next)
    }
    expect(proposal(locked, 4, 300, 200, 4, 20, 2)).toBeNull()
    expect(moveSeparation(locked, 'root', 200, 300, 200, 4, 20)).toBeNull()
    expect(moveElement(locked, 'P01', 'P02', 'centre', 300, 200, 4, 20)).toBeNull()
    expect(() => planChange({ ...previous(), settings: { ...previous().settings, compositionTree: locked } }, { width: 500 })).toThrow(/Déverrouillez/)
  })
  it('moves panels and groups by swapping or inserting while retaining coverage and jeu', () => {
    const swapped = moveElement(tree, 'P01', 'P02', 'centre', 300, 200, 4, 20)!
    expect(panelRects(swapped, 300, 200, 4).find(p => p.node.id === 'P02')!.width).toBe(148)
    expect(panelRects(swapped, 300, 200, 4).find(p => p.node.id === 'P02')!.height).toBe(200)
    const inserted = moveElement(tree, 'P01', 'P02', 'top', 300, 200, 4, 20)!
    expect(inserted).not.toBeNull(); expect(panelRects(inserted, 300, 200, 4).length).toBe(3)
    expect(layoutProblem(inserted, 300, 200, 4, 20)).toBeNull()
    const grouped = moveElement(tree, 'right', 'P01', 'centre', 300, 200, 4, 20)!
    expect(grouped).not.toBeNull(); expect(sanitizeLayout(grouped)).toEqual(grouped)
    expect(moveElement(tree, 'root', 'P01', 'centre', 300, 200, 4, 20)).toBeNull()
  })
  it('resizes by pointer or exact dimension and snaps to actual golden rectangles', () => {
    const moved = moveSeparation(tree, 'root', 180, 300, 200, 4, 20)!
    expect(panelRects(moved.tree, 300, 200, 4)[0].width).toBe(178)
    const resized = resizeElement(tree, 'P01', 'x', 180, 300, 200, 4, 20)!
    expect(panelRects(resized, 300, 200, 4)[0].width).toBeCloseTo(180)
    expect(resizeElement(tree, 'P01', 'y', 180, 300, 200, 4, 20)).toBeNull()
    const snap = moveSeparation(tree, 'root', 200 / 1.618033988749895 + 2 + .5, 300, 200, 4, 20, 1)!
    expect(snap.guide).toBe('Rectangle I')
    expect(panelRects(snap.tree, 300, 200, 4)[0].width).toBeCloseTo(200 / 1.618033988749895)
  })
  it('saves layouts, locks and finishes, and opens old projects without activating composition', () => {
    const settings = { ...previous().settings, compositionTree: replaceNode(tree, 'P02', { kind: 'panel', id: 'P02', locked: true, pattern: true }) }
    expect(parseProject(serializeProject({ ...previous(), settings })).settings.compositionTree).toEqual(settings.compositionTree)
    const old = JSON.parse(serializeProject(previous())); old.version = 5
    for (const key of Object.keys(old.settings)) if (key.startsWith('composition')) delete old.settings[key]
    expect(parseProject(JSON.stringify(old)).settings.compositionEnabled).toBe(false)
    expect(sanitizeLayout({ ...tree, b: p('P01') })).toBeNull()
    expect(sanitizeLayout({ ...tree, ratio: Infinity })).toBeNull()
  })
  it('keeps contour and interior colors distinct and scales jeu with pixel resolution', () => {
    expect(() => planChange(previous(), { panelContourColor: DEFAULTS.lineColor })).toThrow(/couleurs différentes/)
    const enabled = planChange({ ...previous(), settings: { ...previous().settings, compositionEnabled: false, lineColor: '#0066cc' } }, { compositionEnabled: true })
    expect(enabled.next.settings.panelContourColor).not.toBe(enabled.next.settings.lineColor)
    const px = { ...previous(), settings: { ...previous().settings, units: 'px' as const, compositionJeu: 4 } }
    expect(planChange(px, { dpi: 150 }).next.settings.compositionJeu).toBe(8)
  })
})
describe('composition fabrication files', () => {
  const settings = { ...previous().settings, organicEnabled: true, organicAmount: 80, cellStyle: 'holes' as const, border: 5,
    compositionTree: replaceNode(tree, 'P02', { kind: 'panel' as const, id: 'P02', locked: false, pattern: true }) }
  const points = previous().points
  const geometry = buildGeometry(points, { ...settings, border: 0 })
  const panels = buildPanelGeometries(geometry, settings)
  it('constructs real closed holes inside each panel, with a frame', () => {
    expect(panels[0].geometry.holes).toHaveLength(0)
    expect(panels[1].geometry.holes.length).toBeGreaterThan(0)
    for (const h of panels[1].geometry.holes) for (const [x, y] of flattenOrganic(h.outline)) {
      const p = panels[1].panel
      expect(x).toBeGreaterThanOrEqual(p.x + settings.border - .01)
      expect(x).toBeLessThanOrEqual(p.x + p.width - settings.border + .01)
      expect(y).toBeGreaterThanOrEqual(p.y + settings.border - .01)
      expect(y).toBeLessThanOrEqual(p.y + p.height - settings.border + .01)
    }
  })
  it('exports local panel dimensions and world positions consistently in SVG, DXF and CSV', () => {
    const local = localPanel(panels[1])
    expect(local.geometry.sheet.x0).toBe(0); expect(local.geometry.sheet.y0).toBe(0)
    expect(panelLaser(panels[1])).toContain(`width="148.5mm"`)
    expect(panelLaser(panels[1])).toContain(`id="cut-outer" fill="none" stroke="${settings.panelContourColor}"`)
    expect(panelLaser(panels[1])).toContain(`id="cut-inner" fill="none" stroke="${settings.lineColor}"`)
    expect(panelDxf(panels[1])).toContain('POLYLINE')
    expect(compositionSvg(panels, settings)).toContain('jeu 3 mm')
    const dxf = compositionDxf(panels)
    expect((dxf.match(/0\nSECTION\n/g) ?? []).length).toBe(3)
    expect(dxf).toContain('P01_CUT_OUTER'); expect(dxf).toContain('P02_CUT_INNER'); expect(dxf).toContain('P03_CUT_OUTER')
    expect(dxf).toMatch(/P02_CUT_INNER\n70\n0\n62\n1\n/)
    expect(dxf).toMatch(/P02_CUT_OUTER\n70\n0\n62\n5\n/)
    expect((dxf.match(/0\nEOF\n/g) ?? []).length).toBe(1)
    expect(compositionCsv(panels, settings)).toContain('P02;148,5;98,5;151,5;0;3;Voronoi;Non')
  })
  it('builds an offline ZIP with local files and no path traversal', async () => {
    expect(() => zipFiles([{ name: '../outside.svg', text: '' }])).toThrow(/invalide/)
    const blob = zipFiles([{ name: 'panneaux/P01.svg', text: panelLaser(panels[0]) }, { name: 'dimensions.csv', text: compositionCsv(panels, settings) }])
    const bytes = new Uint8Array(await blob.arrayBuffer()), view = new DataView(bytes.buffer)
    expect(view.getUint32(0, true)).toBe(0x04034b50)
    expect(view.getUint32(bytes.length - 22, true)).toBe(0x06054b50)
    expect(view.getUint16(bytes.length - 14, true)).toBe(2)
    expect(new TextDecoder().decode(bytes)).toContain('panneaux/P01.svg')
  })
})
