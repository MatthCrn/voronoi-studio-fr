import { findNode, hasLocked, panelNodes, panelRects, placeLayout, replaceNode, respectsLocks, sanitizeLayout, type Box, type LayoutNode, type PanelNode } from './composition'

export const sameIds = (a: string[], b: string[]) => a.length === b.length && a.every(id => b.includes(id))
export function sanitizeGroups(raw: unknown, tree: LayoutNode | null): string[][] {
  if (!Array.isArray(raw) || !tree) return []
  const valid = new Set(panelNodes(tree).map(p => p.id)), used = new Set<string>(), groups: string[][] = []
  for (const item of raw.slice(0, 24)) {
    if (!Array.isArray(item)) continue
    const ids = [...new Set(item.slice(0, 64).filter((id): id is string => typeof id === 'string' && valid.has(id) && !used.has(id)))].slice(0, 24)
    if (ids.length >= 2) { groups.push(ids); ids.forEach(id => used.add(id)) }
  }
  return groups
}
export function groupSelection(groups: string[][], ids: string[]): string[][] {
  return [...groups.map(g => g.filter(id => !ids.includes(id))).filter(g => g.length >= 2), [...ids]]
}
export function selectionContainer(tree: LayoutNode, ids: string[]): LayoutNode | null {
  if (!ids.length) return null
  const child = tree.kind === 'split' ? selectionContainer(tree.a, ids) ?? selectionContainer(tree.b, ids) : null
  return child ?? (sameIds(panelNodes(tree).map(p => p.id), ids) ? tree : null)
}
export function selectionBounds(tree: LayoutNode, ids: string[], width: number, height: number, jeu: number): Box | null {
  const panels = panelRects(tree, width, height, jeu).filter(p => ids.includes(p.node.id))
  if (!panels.length) return null
  const x = Math.min(...panels.map(p => p.x)), y = Math.min(...panels.map(p => p.y))
  return { x, y, width: Math.max(...panels.map(p => p.x + p.width)) - x, height: Math.max(...panels.map(p => p.y + p.height)) - y }
}
export function deletePanels(tree: LayoutNode, ids: string[]): LayoutNode | null {
  const selected = panelNodes(tree).filter(p => ids.includes(p.id))
  if (!selected.length || selected.some(p => p.locked)) return null
  return selected.reduce((result, p) => replaceNode(result, p.id, { kind: 'panel', id: p.id, locked: false, pattern: false, empty: true }), tree)
}
type Piece = Box & { node: PanelNode }
const near = (a: number, b: number) => Math.abs(a - b) < 1e-6
const sameBox = (a: Box, b: Box) => near(a.x, b.x) && near(a.y, b.y) && near(a.width, b.width) && near(a.height, b.height)

// Reconstruct only along existing physical gaps; no surviving panel changes size.
function rebuild(pieces: Piece[], box: Box, jeu: number, used: Set<string>, together?: string[]): LayoutNode | null {
  let budget = 12000, serial = 0
  const fresh = () => { let id: string; do { id = `edit${++serial}` } while (used.has(id)); used.add(id); return id }
  function build(items: Piece[], area: Box): LayoutNode | null {
    if (--budget < 0 || !items.length) return null
    if (items.length === 1) return sameBox(items[0], area) ? items[0].node : null
    for (const axis of ['x', 'y'] as const) {
      const start = axis === 'x' ? area.x : area.y, size = axis === 'x' ? area.width : area.height
      const candidates = [...new Set(items.map(p => axis === 'x' ? p.x + p.width : p.y + p.height))].sort((a, b) => a - b)
      for (const edge of candidates) {
        if (edge <= start + 1e-7 || edge + jeu >= start + size - 1e-7) continue
        const a = items.filter(p => (axis === 'x' ? p.x + p.width : p.y + p.height) <= edge + 1e-7)
        const b = items.filter(p => (axis === 'x' ? p.x : p.y) >= edge + jeu - 1e-7)
        if (!a.length || !b.length || a.length + b.length !== items.length) continue
        const groupHere = together && together.every(id => items.some(p => p.node.id === id)) && items.some(p => !p.node.empty && !together.includes(p.node.id))
        if (groupHere && a.some(p => together!.includes(p.node.id)) && b.some(p => together!.includes(p.node.id))) continue
        const first = edge - start, available = size - jeu
        const aa = axis === 'x' ? { ...area, width: first } : { ...area, height: first }
        const bb = axis === 'x' ? { ...area, x: edge + jeu, width: available - first } : { ...area, y: edge + jeu, height: available - first }
        const left = build(a, aa), right = left && build(b, bb)
        if (left && right) return { kind: 'split', id: fresh(), axis, ratio: first / available, a: left, b: right }
      }
    }
    return null
  }
  return build(pieces, box)
}
export function mergePanels(tree: LayoutNode, ids: string[], width: number, height: number, jeu: number): { tree: LayoutNode; id: string } | { error: string } {
  const selected = panelRects(tree, width, height, jeu).filter(p => ids.includes(p.node.id))
  if (selected.length < 2) return { error: 'Sélectionnez au moins deux panneaux.' }
  if (selected.some(p => p.node.locked)) return { error: 'Déverrouillez les panneaux sélectionnés avant de les fusionner.' }
  const bounds = selectionBounds(tree, ids, width, height, jeu)!
  // Expanded half-gaps must tile the bounding rectangle, without any missing area.
  const expanded = selected.map(p => ({ x: Math.max(bounds.x, p.x - jeu / 2), y: Math.max(bounds.y, p.y - jeu / 2), right: Math.min(bounds.x + bounds.width, p.x + p.width + jeu / 2), bottom: Math.min(bounds.y + bounds.height, p.y + p.height + jeu / 2) }))
  const xs = [...new Set(expanded.flatMap(p => [p.x, p.right]))].sort((a, b) => a - b), ys = [...new Set(expanded.flatMap(p => [p.y, p.bottom]))].sort((a, b) => a - b)
  for (let i = 1; i < xs.length; i++) for (let j = 1; j < ys.length; j++) {
    const x = (xs[i - 1] + xs[i]) / 2, y = (ys[j - 1] + ys[j]) / 2
    if (!expanded.some(p => x >= p.x && x <= p.right && y >= p.y && y <= p.bottom)) return { error: 'La sélection doit former un rectangle complet, sans panneau manquant ni zone vide.' }
  }
  const panel: PanelNode = { ...selected[0].node, pattern: selected.some(p => p.node.pattern), locked: false }
  const container = selectionContainer(tree, ids)
  if (container && sameBox(placeLayout(tree, width, height, jeu).find(p => p.node.id === container.id)!, bounds)) return { tree: replaceNode(tree, container.id, panel), id: panel.id }
  const pieces = placeLayout(tree, width, height, jeu).filter(p => p.node.kind === 'panel' && !ids.includes(p.node.id)) as Piece[]
  pieces.push({ ...bounds, node: panel })
  const result = rebuild(pieces, { x: 0, y: 0, width, height }, jeu, new Set(placeLayout(tree, width, height, jeu).map(p => p.node.id)))
  if (!result || !sanitizeLayout(result) || !respectsLocks(tree, result, width, height, jeu)) return { error: 'Cette fusion ne permet pas de conserver les autres panneaux et leurs jeux. Sélectionnez un ensemble rectangulaire adjacent.' }
  return { tree: result, id: panel.id }
}
export function isolateSelection(tree: LayoutNode, ids: string[], width: number, height: number, jeu: number): { tree: LayoutNode; id: string } | null {
  const container = selectionContainer(tree, ids)
  // A container including vacancies must move them along with its panels.
  if (container) return { tree, id: container.id }
  const pieces = placeLayout(tree, width, height, jeu).filter(p => p.node.kind === 'panel') as Piece[]
  const result = rebuild(pieces, { x: 0, y: 0, width, height }, jeu, new Set(placeLayout(tree, width, height, jeu).map(p => p.node.id)), ids)
  const node = result && selectionContainer(result, ids)
  return node && result ? { tree: result, id: node.id } : null
}
// Disjoint groups can also move rigidly between matching sets of occupied/empty slots.
export function swapGroupAt(tree: LayoutNode, ids: string[], anchor: string, target: string, width: number, height: number, jeu: number): LayoutNode | null {
  const slots = placeLayout(tree, width, height, jeu).filter(p => p.node.kind === 'panel') as Piece[]
  const source = slots.filter(p => ids.includes(p.node.id)), a = slots.find(p => p.node.id === anchor), b = slots.find(p => p.node.id === target)
  if (!a || !b || source.some(p => p.node.locked) || ids.includes(target)) return null
  const dx = b.x - a.x, dy = b.y - a.y, pairs = source.map(p => ({ from: p, to: slots.find(q => !ids.includes(q.node.id) && !q.node.locked && sameBox(q, { ...p, x: p.x + dx, y: p.y + dy })) }))
  if (pairs.some(p => !p.to)) return null
  const map = new Map<string, PanelNode>()
  pairs.forEach(p => { map.set(p.from.node.id, p.to!.node); map.set(p.to!.node.id, p.from.node) })
  const swap = (n: LayoutNode): LayoutNode => n.kind === 'panel' ? map.get(n.id) ?? n : { ...n, a: swap(n.a), b: swap(n.b) }
  const result = swap(tree)
  return respectsLocks(tree, result, width, height, jeu) ? result : null
}
export function updateSelection(tree: LayoutNode, ids: string[], patch: { locked?: boolean; pattern?: boolean }): LayoutNode {
  return ids.reduce((out, id) => { const n = findNode(out, id); return n?.kind === 'panel' && !n.empty ? replaceNode(out, id, { ...n, ...patch }) : out }, tree)
}
export const selectionLocked = (tree: LayoutNode, ids: string[]) => ids.some(id => hasLocked(findNode(tree, id) ?? null))
