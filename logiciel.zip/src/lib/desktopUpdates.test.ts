import { createRequire } from 'node:module'
import { EventEmitter } from 'node:events'
import { describe, expect, it, vi } from 'vitest'
const { Updates, updateUrl } = createRequire(import.meta.url)('../../desktop/updates.cjs')

function fixture(over = {}) {
  const client = Object.assign(new EventEmitter(), {
    checkForUpdates: vi.fn(async () => { client.emit('update-available', { version: '1.8.0', releaseNotes: 'Contours améliorés' }) }),
    downloadUpdate: vi.fn(async () => { client.emit('download-progress', { percent: 50 }); client.emit('update-downloaded') }),
  })
  const saveConfig = vi.fn(async () => {})
  const checkpoint = vi.fn(async () => true)
  const install = vi.fn()
  const factory = vi.fn(() => client)
  const service = new Updates({ version: '1.7.0', portable: false, packaged: true, config: { url: 'https://updates.example.org/studio/' }, saveConfig, checkpoint, install, factory, ...over })
  return { service, client, saveConfig, checkpoint, install, factory }
}
describe('desktop update lifecycle', () => {
  it('stays offline until a service exists and disables portable/development installs', async () => {
    for (const over of [{ config: {} }, { portable: true }, { packaged: false }]) {
      const { service, factory, install } = fixture(over)
      await service.check(); await service.download(); await service.restart()
      expect(factory).not.toHaveBeenCalled(); expect(install).not.toHaveBeenCalled()
    }
  })
  it('requires a user download then a checkpoint before restart; never installs on quit', async () => {
    const { service, client, install, checkpoint } = fixture()
    await service.check()
    expect(service.snapshot().phase).toBe('available')
    expect(client).toMatchObject({ autoDownload: false, autoInstallOnAppQuit: false, allowDowngrade: false, allowPrerelease: false })
    expect(client.downloadUpdate).not.toHaveBeenCalled()
    await service.restart(); expect(install).not.toHaveBeenCalled()
    await service.download(); expect(service.snapshot().phase).toBe('downloaded')
    expect(install).not.toHaveBeenCalled()
    await service.restart()
    expect(checkpoint).toHaveBeenCalledOnce(); expect(install).toHaveBeenCalledOnce()
    expect(checkpoint.mock.invocationCallOrder[0]).toBeLessThan(install.mock.invocationCallOrder[0])
  })
  it('preserves the running version when download or connection fails', async () => {
    const { service, client, install } = fixture()
    client.checkForUpdates.mockRejectedValueOnce(Error('offline'))
    await service.check(); expect(service.snapshot().phase).toBe('error')
    await service.check(); expect(service.snapshot().phase).toBe('available')
    client.downloadUpdate.mockRejectedValueOnce(Error('bad digest'))
    await service.download(); expect(service.snapshot().phase).toBe('error')
    await service.restart(); expect(install).not.toHaveBeenCalled()
  })
  it('refuses restart if the session checkpoint fails and allows retry', async () => {
    const { service, checkpoint, install } = fixture()
    await service.check(); await service.download()
    checkpoint.mockResolvedValueOnce(false)
    await service.restart(); expect(install).not.toHaveBeenCalled()
    expect(service.snapshot().phase).toBe('downloaded')
    expect(service.snapshot().error).toMatch(/sauvegardée/)
    await service.restart(); expect(install).toHaveBeenCalledOnce()
  })
  it('only accepts HTTPS feeds without credentials; saves the source for future launches', async () => {
    for (const url of ['http://example.org/', 'file:///C:/test/', 'https://name:secret@example.org/', 'https://example.org/?token=secret', 'not a url']) expect(() => updateUrl(url)).toThrow()
    const { service, saveConfig } = fixture({ config: {} })
    await service.configure({ url: 'https://example.org/updates', startup: false })
    expect(saveConfig).toHaveBeenCalledWith({ url: 'https://example.org/updates/', startup: false })
    expect(service.snapshot()).toMatchObject({ phase: 'idle', startup: false })
  })
  it('ignores duplicate downloads and protects the source during active updates', async () => {
    const { service, client } = fixture()
    await service.check(); await service.download(); await service.download()
    expect(client.downloadUpdate).toHaveBeenCalledOnce()
    await expect(service.configure({ url: 'https://other.example.org/' })).rejects.toThrow()
  })
})
