import { sanitizeGroups } from './compositionEditing'
// All design settings in one flat object, with defaults and allowed ranges. Lengths are millimetres.
// Project files store this object, so new settings must get a default here.
import type { DensityMode } from '../voronoi/density'
import type { CellStyle } from '../voronoi/pattern'
import type { Shape } from '../voronoi/region'
import { sanitizeShape, type CustomShape } from '../voronoi/shape'
import { MAX_POINTS, type Placement, type SeedSettings } from '../voronoi/seeding'
import type { Units } from './units'
import { GOLDEN_IDS, fitGolden, type GoldenId, type DimensionAnchor } from './goldenRectangles'
import { COMPOSITION_DEFAULTS, sanitizeLayout, type CompositionSettings } from './composition'
import { SPATIAL_DEFAULTS, SPATIAL_RANGES, SPATIAL_CHOICES, spatialConfig, spatialDensityStrength, type SpatialSettings } from '../voronoi/spatial'

export type Settings = SpatialSettings & CompositionSettings & {
  // Sheet
  width: number; height: number; units: Units; dpi: number; shape: Shape; border: number; keepPoints: boolean
  customShape: CustomShape | null // the imported outline, kept when switching to another shape and back
  goldenEnabled: boolean; goldenForm: GoldenId; dimensionAnchor: DimensionAnchor
  panelContourColor: string
  // Points
  count: number; placement: Placement; autoSpacing: boolean; spacing: number; tries: number; jitter: number; seed: number
  density: DensityMode; densityStrength: number; densityAngle: number; densityInvert: boolean
  relaxSteps: number
  // Style
  cellStyle: CellStyle; web: number; cornerRadius: number; minHole: number
  organicEnabled: boolean; organicAmount: number
  lineWidth: number; lineColor: string; fill: boolean; fillColor: string; background: string
  showSites: boolean; showEdges: boolean; showDelaunay: boolean
  // Export
  transparentPng: boolean; sheetOutline: boolean
}

export const LEGACY_DEFAULTS: Settings = {
  ...SPATIAL_DEFAULTS,
  ...COMPOSITION_DEFAULTS,
  width: 200, height: 200, units: 'mm', dpi: 300, shape: 'rect', border: 5, keepPoints: true, customShape: null,
  goldenEnabled: false, goldenForm: 'I', dimensionAnchor: 'width',
  panelContourColor: '#0066cc',
  count: 300, placement: 'even', autoSpacing: true, spacing: 10, tries: 30, jitter: 0.3, seed: 1,
  density: 'none', densityStrength: 4, densityAngle: 0, densityInvert: false,
  relaxSteps: 3,
  cellStyle: 'lines', web: 2, cornerRadius: 1, minHole: 0.5,
  organicEnabled: false, organicAmount: 100,
  // The old Voronoi Lab's colours: dark MIT red edges on white.
  lineWidth: 0.3, lineColor: '#7a0f1f', fill: false, fillColor: '#f4d6da', background: '#ffffff',
  showSites: true, showEdges: true, showDelaunay: false,
  transparentPng: false, sheetOutline: true,
}

export const REFERENCE_STYLE: Pick<Settings, 'cellStyle' | 'web' | 'organicEnabled' | 'organicAmount' | 'lineWidth' | 'lineColor' | 'fill' | 'background' | 'showSites' | 'showEdges' | 'showDelaunay'> = {
  cellStyle: 'holes', web: 8, organicEnabled: true, organicAmount: 59,
  lineWidth: .3, lineColor: '#7a0f1f', fill: false, background: '#ffffff',
  showSites: false, showEdges: true, showDelaunay: true,
}
export const DEFAULTS: Settings = { ...LEGACY_DEFAULTS, ...REFERENCE_STYLE }

type NumericKey = { [K in keyof Settings]: Settings[K] extends number ? K : never }[keyof Settings]
export const RANGES: Record<NumericKey, [number, number]> = {
  ...SPATIAL_RANGES,
  width: [5, 5000], height: [5, 5000], dpi: [36, 1200], border: [0, 500],
  count: [2, 10_000], spacing: [0.05, 1000], tries: [1, 100], jitter: [0, 1], seed: [0, 999_999],
  densityStrength: [1, 20], densityAngle: [0, 360], relaxSteps: [0, 50],
  web: [0, 100], cornerRadius: [0, 100], minHole: [0, 200], lineWidth: [0.005, 20],
  organicAmount: [0, 100],
  compositionCount: [1, 24], compositionJeu: [0, 200], compositionMin: [1, 500], compositionSeed: [0, 999999],
}

const CHOICES = {
  ...SPATIAL_CHOICES,
  units: ['mm', 'in', 'px', 'pc'], shape: ['rect', 'ellipse', 'custom'], placement: ['random', 'even', 'hex', 'square'],
  density: ['none', 'linear', 'radial'], cellStyle: ['lines', 'holes'],
  goldenForm: GOLDEN_IDS, dimensionAnchor: ['width', 'height'],
} as const

// Settings that decide where points go. Changing one makes a new pattern (unless points were edited).
export const SEED_KEYS: (keyof Settings)[] = ['count', 'placement', 'autoSpacing', 'spacing', 'tries', 'jitter', 'seed',
  'density', 'densityStrength', 'densityAngle', 'densityInvert', 'relaxSteps']
// Settings that move the region points live in. With "Keep points" on, points follow the sheet instead.
export const SHEET_KEYS: (keyof Settings)[] = ['width', 'height', 'shape', 'border', 'customShape']

export function clampSetting<K extends NumericKey>(key: K, value: number): number {
  const [lo, hi] = RANGES[key]
  return Math.min(hi, Math.max(lo, value))
}

// Copy known settings from untrusted data, falling back to defaults for anything missing or out of range.
export function sanitizeSettings(raw: unknown, defaults: Settings = DEFAULTS): Settings {
  const source = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>
  const out: Record<string, unknown> = { ...defaults }
  for (const key of Object.keys(defaults) as (keyof Settings)[]) {
    const value = source[key], fallback = defaults[key]
    if (key === 'customShape') out[key] = sanitizeShape(value)
    else if (key === 'compositionTree') out[key] = sanitizeLayout(value)
    else if (key === 'compositionGroups') out[key] = value
    else if (typeof fallback === 'number') {
      if (typeof value === 'number' && Number.isFinite(value)) out[key] = clampSetting(key as NumericKey, value)
    } else if (typeof fallback === 'boolean') {
      if (typeof value === 'boolean') out[key] = value
    } else if (key in CHOICES) {
      if ((CHOICES[key as keyof typeof CHOICES] as readonly string[]).includes(value as string)) out[key] = value
    } else if (typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value)) out[key] = value.toLowerCase()
  }
  // A custom sheet without its outline can't be drawn, so it becomes a rectangle.
  if (out.shape === 'custom' && !out.customShape) out.shape = 'rect'
  if (out.spatialUnit === 'relative') {
    out.spatialMin = Math.min(100, out.spatialMin as number)
    out.spatialMax = Math.min(100, out.spatialMax as number)
  }
  if (out.shape !== 'rect') out.goldenEnabled = false
  out.compositionCount = Math.round(out.compositionCount as number)
  out.compositionSeed = Math.round(out.compositionSeed as number)
  if (out.shape !== 'rect') out.compositionEnabled = false
  if (out.compositionEnabled && out.panelContourColor === out.lineColor) out.panelContourColor = out.lineColor === '#0066cc' ? '#cc6600' : '#0066cc'
  out.compositionGroups = sanitizeGroups(out.compositionGroups, out.compositionTree as Settings['compositionTree'])
  return fitGolden(out as Settings)
}

export function seedSettings(s: Settings): SeedSettings {
  return {
    count: Math.min(MAX_POINTS, s.count), placement: s.placement, autoSpacing: s.autoSpacing, spacing: s.spacing,
    tries: s.tries, jitter: s.jitter, seed: s.seed,
    density: s.spatialEnabled && s.spatialDensity && (s.placement === 'random' || s.placement === 'even')
      ? { mode: 'linear', strength: spatialDensityStrength(s), angle: s.spatialAngle, invert: false, spatial: spatialConfig(s) }
      : { mode: s.density, strength: s.densityStrength, angle: s.densityAngle, invert: s.densityInvert },
  }
}

// Only changes that affect point placement regenerate the tessellation. In
// particular, thickness, aperture limits and target material never reseed it.
export function spatialDensitySignature(s: Settings): string {
  if (!s.spatialEnabled || !s.spatialDensity || (s.placement !== 'random' && s.placement !== 'even')) return ''
  const field = spatialConfig(s)
  const keys = ['spatialMode', 'spatialAngle', 'spatialProfile', 'spatialPower', 'spatialPosition', 'spatialWidth',
    'spatialCenterX', 'spatialCenterY', 'spatialRadius', 'spatialInvert', 'spatialNoise', 'spatialNoiseScale', 'spatialNoiseSeed',
    'spatialDensityMin', 'spatialDensityMax', 'spatialDensityIntensity', 'spatialDensityInvert', 'spatialDensityAngle',
    'spatialCoupling', 'spatialCouplingStrength'] as (keyof SpatialSettings)[]
  return JSON.stringify(keys.map(k => field[k]))
}
