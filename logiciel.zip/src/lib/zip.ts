// Small ZIP writer, stored UTF-8 entries. No remote service or dependency.
const encoder = new TextEncoder()
const table = Uint32Array.from({ length: 256 }, (_, n) => { for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1; return n >>> 0 })
function crc32(bytes: Uint8Array) { let crc = 0xffffffff; for (const b of bytes) crc = table[(crc ^ b) & 255] ^ (crc >>> 8); return (crc ^ 0xffffffff) >>> 0 }
function header(size: number, entries: [number, number, number][]) {
  const bytes = new Uint8Array(size), view = new DataView(bytes.buffer)
  entries.forEach(([at, value, bits]) => bits === 16 ? view.setUint16(at, value, true) : view.setUint32(at, value, true)); return bytes
}
export function zipFiles(files: { name: string; text: string }[]): Blob {
  const data: Uint8Array[] = [], central: Uint8Array[] = []; let offset = 0
  for (const file of files) {
    if (!file.name || file.name.startsWith('/') || file.name.includes('\\') || file.name.split('/').includes('..') || file.name.includes(':')) throw Error('Nom de fichier d’archive invalide.')
    const name = encoder.encode(file.name), bytes = encoder.encode(file.text), crc = crc32(bytes)
    const local = header(30, [[0, 0x04034b50, 32], [4, 20, 16], [6, 0x800, 16], [14, crc, 32], [18, bytes.length, 32], [22, bytes.length, 32], [26, name.length, 16]])
    const record = header(46, [[0, 0x02014b50, 32], [4, 20, 16], [6, 20, 16], [8, 0x800, 16], [16, crc, 32], [20, bytes.length, 32], [24, bytes.length, 32], [28, name.length, 16], [42, offset, 32]])
    data.push(local, name, bytes); central.push(record, name); offset += local.length + name.length + bytes.length
  }
  const length = central.reduce((sum, bytes) => sum + bytes.length, 0)
  const end = header(22, [[0, 0x06054b50, 32], [8, files.length, 16], [10, files.length, 16], [12, length, 32], [16, offset, 32]])
  return new Blob([...data, ...central, end] as BlobPart[], { type: 'application/zip' })
}
