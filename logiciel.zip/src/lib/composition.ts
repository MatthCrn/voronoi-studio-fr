import { GOLDEN_RECTANGLES } from './goldenRectangles'
import { createRng } from '../voronoi/random'

export type PanelNode = { kind: 'panel'; id: string; locked: boolean; pattern: boolean; empty?: true }
export type SplitNode = { kind: 'split'; id: string; axis: 'x' | 'y'; ratio: number; a: LayoutNode; b: LayoutNode }
export type LayoutNode = PanelNode | SplitNode
export type Box = { x: number; y: number; width: number; height: number }
export type PlacedNode = Box & { node: LayoutNode; parent: string | null }
export type CompositionSettings = { compositionEnabled: boolean; compositionTree: LayoutNode | null; compositionCount: number; compositionJeu: number; compositionMin: number; compositionSeed: number; compositionSnap: boolean; compositionShowPattern: boolean; compositionGroups: string[][] }
export const COMPOSITION_DEFAULTS: CompositionSettings = { compositionEnabled: false, compositionTree: null, compositionCount: 6, compositionJeu: 3, compositionMin: 20, compositionSeed: 1, compositionSnap: true, compositionShowPattern: true, compositionGroups: [] }
export const panelNodes = (tree: LayoutNode): PanelNode[] => tree.kind === 'panel' ? tree.empty ? [] : [tree] : [...panelNodes(tree.a), ...panelNodes(tree.b)]
export const hasLocked = (tree: LayoutNode | null): boolean => !!tree && panelNodes(tree).some(p => p.locked)
export const findNode = (tree: LayoutNode, id: string): LayoutNode | undefined => tree.id === id ? tree : tree.kind === 'split' ? findNode(tree.a, id) ?? findNode(tree.b, id) : undefined
export const replaceNode = (tree: LayoutNode, id: string, replacement: LayoutNode): LayoutNode => tree.id === id ? replacement : tree.kind === 'panel' ? tree : { ...tree, a: replaceNode(tree.a, id, replacement), b: replaceNode(tree.b, id, replacement) }
export function removeNode(tree: LayoutNode, id: string): LayoutNode | null {
  if (tree.id === id) return null
  if (tree.kind === 'panel') return tree
  const a = removeNode(tree.a, id), b = removeNode(tree.b, id)
  return !a ? b : !b ? a : { ...tree, a, b }
}
export function sanitizeLayout(raw: unknown): LayoutNode | null {
  const ids = new Set<string>(); let panels = 0, slots = 0
  function read(value: unknown, depth: number): LayoutNode | null {
    if (!value || typeof value !== 'object' || depth > 64) return null
    const n = value as Record<string, unknown>
    if (typeof n.id !== 'string' || !/^[a-zA-Z0-9_-]{1,40}$/.test(n.id) || ids.has(n.id)) return null
    ids.add(n.id)
    if (n.kind === 'panel') {
      if (++slots > 64 || (n.empty !== true && ++panels > 24)) return null
      if (n.empty === true) return { kind: 'panel', id: n.id, locked: false, pattern: false, empty: true }
      return { kind: 'panel', id: n.id, locked: n.locked === true, pattern: n.pattern === true }
    }
    if (n.kind !== 'split' || (n.axis !== 'x' && n.axis !== 'y') || typeof n.ratio !== 'number' || !Number.isFinite(n.ratio) || n.ratio <= 0 || n.ratio >= 1) return null
    const a = read(n.a, depth + 1), b = read(n.b, depth + 1)
    return a && b ? { kind: 'split', id: n.id, axis: n.axis, ratio: n.ratio, a, b } : null
  }
  return read(raw, 0)
}
export function placeLayout(tree: LayoutNode, width: number, height: number, jeu: number): PlacedNode[] {
  const nodes: PlacedNode[] = []
  function visit(node: LayoutNode, box: Box, parent: string | null) {
    nodes.push({ ...box, node, parent })
    if (node.kind === 'panel') return
    if (node.axis === 'x') {
      const size = box.width - jeu, first = size * node.ratio
      visit(node.a, { ...box, width: first }, node.id)
      visit(node.b, { ...box, x: box.x + first + jeu, width: size - first }, node.id)
    } else {
      const size = box.height - jeu, first = size * node.ratio
      visit(node.a, { ...box, height: first }, node.id)
      visit(node.b, { ...box, y: box.y + first + jeu, height: size - first }, node.id)
    }
  }
  visit(tree, { x: 0, y: 0, width, height }, null)
  return nodes
}
export const panelRects = (tree: LayoutNode, width: number, height: number, jeu: number) => placeLayout(tree, width, height, jeu).filter(n => n.node.kind === 'panel' && !n.node.empty) as (PlacedNode & { node: PanelNode })[]
export function minimumBox(tree: LayoutNode, minimum: number, jeu: number): { width: number; height: number } {
  if (tree.kind === 'panel') return { width: tree.empty ? .001 : minimum, height: tree.empty ? .001 : minimum }
  const a = minimumBox(tree.a, minimum, jeu), b = minimumBox(tree.b, minimum, jeu)
  return tree.axis === 'x' ? { width: a.width + b.width + jeu, height: Math.max(a.height, b.height) } : { width: Math.max(a.width, b.width), height: a.height + b.height + jeu }
}
export function layoutProblem(tree: LayoutNode | null, width: number, height: number, jeu: number, minimum: number): string | null {
  if (!tree) return 'Aucune composition disponible.'
  const size = minimumBox(tree, minimum, jeu)
  if (size.width > width + 1e-7 || size.height > height + 1e-7) return 'Le format, le jeu et la dimension minimale ne permettent pas cette composition. Agrandissez le format, réduisez le jeu ou proposez une autre répartition.'
  return null
}
export function respectsLocks(before: LayoutNode, after: LayoutNode, width: number, height: number, jeu: number): boolean {
  const a = panelRects(before, width, height, jeu), b = panelRects(after, width, height, jeu)
  return a.filter(p => p.node.locked).every(p => {
    const q = b.find(n => n.node.id === p.node.id)
    return q && ['x', 'y', 'width', 'height'].every(k => Math.abs(p[k as keyof Box] - q[k as keyof Box]) < 1e-6)
  })
}
export function proposal(tree: LayoutNode | null, count: number, width: number, height: number, jeu: number, minimum: number, seed: number): LayoutNode | null {
  if (tree && hasLocked(tree) && panelNodes(tree).length !== count) return null
  const rng = createRng(seed)
  const leaves = tree ? panelNodes(tree) : []
  const usedIds = new Set(tree ? placeLayout(tree, width, height, jeu).map(p => p.node.id) : [])
  let nextSplit = 0, budget = 15000
  const splitId = () => { let id: string; do { id = `s${seed}_${++nextSplit}` } while (usedIds.has(id)); usedIds.add(id); return id }
  function build(items: PanelNode[], box: Box): LayoutNode | null {
    if (--budget < 0) return null
    if (!items.length || box.width < minimum - 1e-7 || box.height < minimum - 1e-7) return null
    if (items.length === 1) return { ...items[0] }
    // Bounded search, including equal and golden divisions. Failed branches
    // backtrack instead of producing tiny or overlapping pieces.
    for (let attempt = 0; attempt < 48; attempt++) {
      if (budget <= 0) break
      const axis = rng() < box.width / (box.width + box.height) ? 'x' : 'y'
      const n = 1 + Math.floor(rng() * (items.length - 1))
      const choice = Math.floor(rng() * 4)
      const r = choice === 0 ? .5 : choice === 1 ? n / items.length : choice === 2 ? 1 / 1.618033988749895 : 1 - 1 / 1.618033988749895
      const available = (axis === 'x' ? box.width : box.height) - jeu
      const ba = axis === 'x' ? { ...box, width: available * r } : { ...box, height: available * r }
      const bb = axis === 'x' ? { ...box, x: box.x + available * r + jeu, width: available * (1 - r) } : { ...box, y: box.y + available * r + jeu, height: available * (1 - r) }
      const a = build(items.slice(0, n), ba), b = a && build(items.slice(n), bb)
      if (a && b) return { kind: 'split', id: splitId(), axis, ratio: r, a, b }
    }
    return null
  }
  function regenerate(node: LayoutNode, box: Box): LayoutNode | null {
    if (!panelNodes(node).length) return node
    if (!hasLocked(node)) return build(panelNodes(node), box)
    if (node.kind === 'panel') return node
    const placed = placeLayout(node, box.width, box.height, jeu)
    const aBox = placed.find(p => p.node.id === node.a.id)!, bBox = placed.find(p => p.node.id === node.b.id)!
    const a = regenerate(node.a, aBox), b = regenerate(node.b, bBox)
    return a && b ? { ...node, a, b } : null
  }
  const ids = new Set(leaves.map(p => p.id)); let serial = 1
  const items = leaves.slice(0, count).map(p => ({ ...p, locked: false }))
  while (items.length < count) {
    while (ids.has(`P${String(serial).padStart(2, '0')}`)) serial++
    const id = `P${String(serial++).padStart(2, '0')}`; ids.add(id)
    items.push({ kind: 'panel', id, locked: false, pattern: true })
  }
  const box = { x: 0, y: 0, width, height }
  const result = tree && hasLocked(tree) ? regenerate(tree, box) : build(items, box)
  return result && !layoutProblem(result, width, height, jeu, minimum) ? result : null
}
export function splitLimits(placed: PlacedNode, minimum: number, jeu: number): [number, number] {
  if (placed.node.kind !== 'split') return [.5, .5]
  const { node } = placed, a = minimumBox(node.a, minimum, jeu), b = minimumBox(node.b, minimum, jeu)
  const available = (node.axis === 'x' ? placed.width : placed.height) - jeu
  return [(node.axis === 'x' ? a.width : a.height) / available, 1 - (node.axis === 'x' ? b.width : b.height) / available]
}
export function moveSeparation(tree: LayoutNode, id: string, coordinate: number, width: number, height: number, jeu: number, minimum: number, snapDistance = 0): { tree: LayoutNode; guide: string } | null {
  const placed = placeLayout(tree, width, height, jeu).find(n => n.node.id === id)
  if (!placed || placed.node.kind !== 'split') return null
  const { node } = placed, available = (node.axis === 'x' ? placed.width : placed.height) - jeu
  const [lo, hi] = splitLimits(placed, minimum, jeu)
  if (!(available > 0) || lo > hi) return null
  let ratio = Math.max(lo, Math.min(hi, (coordinate - (node.axis === 'x' ? placed.x : placed.y) - jeu / 2) / available)), guide = ''
  const across = node.axis === 'x' ? placed.height : placed.width
  const candidates: { value: number; name: string }[] = GOLDEN_RECTANGLES.flatMap(r => [r.ratio, 1 / r.ratio].flatMap(aspect => {
    const size = node.axis === 'x' ? across * aspect : across / aspect
    return [{ value: size / available, name: r.id }, { value: 1 - size / available, name: r.id }]
  }))
  candidates.push({ value: .5, name: 'moitié' })
  const nearest = candidates.filter(c => c.value >= lo && c.value <= hi).sort((a, b) => Math.abs(a.value - ratio) - Math.abs(b.value - ratio))[0]
  if (nearest && Math.abs(nearest.value - ratio) * available <= snapDistance) { ratio = nearest.value; guide = nearest.name === 'moitié' ? 'Moitié' : `Rectangle ${nearest.name}` }
  const result = replaceNode(tree, id, { ...node, ratio })
  return !layoutProblem(result, width, height, jeu, minimum) && respectsLocks(tree, result, width, height, jeu) ? { tree: result, guide } : null
}
export type DropSide = 'centre' | 'left' | 'right' | 'top' | 'bottom'
export function moveElement(tree: LayoutNode, source: string, target: string, side: DropSide, width: number, height: number, jeu: number, minimum: number): LayoutNode | null {
  const a = findNode(tree, source), b = findNode(tree, target)
  if (!a || !b || hasLocked(a) || findNode(a, target) || findNode(b, source)) return null
  let result: LayoutNode
  if (side === 'centre') {
    // Replace in one traversal so neither inserted subtree is visited twice.
    const swap = (n: LayoutNode): LayoutNode => n.id === source ? b : n.id === target ? a : n.kind === 'panel' ? n : { ...n, a: swap(n.a), b: swap(n.b) }
    result = swap(tree)
  } else {
    const remainder = removeNode(tree, source)
    if (!remainder) return null
    const ids = new Set(placeLayout(tree, width, height, jeu).map(n => n.node.id)); let i = 1
    while (ids.has(`insert${i}`)) i++
    const first = side === 'left' || side === 'top'
    result = replaceNode(remainder, target, { kind: 'split', id: `insert${i}`, axis: side === 'left' || side === 'right' ? 'x' : 'y', ratio: .5, a: first ? a : b, b: first ? b : a })
  }
  return !layoutProblem(result, width, height, jeu, minimum) && respectsLocks(tree, result, width, height, jeu) ? result : null
}
export function parentOf(tree: LayoutNode, id: string): SplitNode | null {
  if (tree.kind === 'panel') return null
  if (tree.a.id === id || tree.b.id === id) return tree
  return parentOf(tree.a, id) ?? parentOf(tree.b, id)
}
export function resizeElement(tree: LayoutNode, id: string, axis: 'x' | 'y', size: number, width: number, height: number, jeu: number, minimum: number): LayoutNode | null {
  const node = findNode(tree, id)
  if (!node || hasLocked(node)) return null
  let parent = parentOf(tree, id)
  while (parent && parent.axis !== axis) parent = parentOf(tree, parent.id)
  if (!parent) return null
  const placed = placeLayout(tree, width, height, jeu).find(p => p.node.id === parent!.id)!
  const [lo, hi] = splitLimits(placed, minimum, jeu)
  if (lo > hi) return null
  const measure = (r: number) => {
    const p = placeLayout(replaceNode(tree, parent!.id, { ...parent!, ratio: r }), width, height, jeu).find(n => n.node.id === id)!
    return axis === 'x' ? p.width : p.height
  }
  const l = measure(lo), h = measure(hi)
  if (Math.abs(h - l) < 1e-8 || size < Math.min(l, h) - 1e-6 || size > Math.max(l, h) + 1e-6) return null
  const ratio = lo + (size - l) / (h - l) * (hi - lo)
  const result = replaceNode(tree, parent.id, { ...parent, ratio })
  return !layoutProblem(result, width, height, jeu, minimum) && respectsLocks(tree, result, width, height, jeu) ? result : null
}

// Equal physical panels: each subtree also contains its own internal gaps.
export function dividePanel(tree: LayoutNode, id: string, count: number, axis: 'x' | 'y', width: number, height: number, jeu: number, minimum: number): { tree: LayoutNode; groupId: string } | null {
  const placed = placeLayout(tree, width, height, jeu), original = placed.find(p => p.node.id === id)
  if (!original || original.node.kind !== 'panel' || original.node.empty || original.node.locked || !Number.isInteger(count) || count < 2 || panelNodes(tree).length - 1 + count > 24) return null
  const extent = axis === 'x' ? original.width : original.height
  const size = (extent - (count - 1) * jeu) / count
  if (size < minimum - 1e-7 || (axis === 'x' ? original.height : original.width) < minimum - 1e-7) return null
  const ids = new Set(placed.map(p => p.node.id))
  const fresh = (prefix: string) => { let i = 1; while (ids.has(`${prefix}${String(i).padStart(2, '0')}`)) i++; const id = `${prefix}${String(i).padStart(2, '0')}`; ids.add(id); return id }
  const panel = original.node
  const leaves = Array.from({ length: count }, (_, i): PanelNode => ({ ...panel, id: i ? fresh('P') : panel.id }))
  const build = (items: PanelNode[]): LayoutNode => {
    if (items.length === 1) return items[0]
    const n = Math.floor(items.length / 2)
    return { kind: 'split', id: fresh('divide'), axis,
      ratio: (n * size + (n - 1) * jeu) / (items.length * size + (items.length - 2) * jeu),
      a: build(items.slice(0, n)), b: build(items.slice(n)) }
  }
  const group = build(leaves), result = replaceNode(tree, id, group)
  if (!sanitizeLayout(result)) return null
  return !layoutProblem(result, width, height, jeu, minimum) && respectsLocks(tree, result, width, height, jeu) ? { tree: result, groupId: group.id } : null
}
