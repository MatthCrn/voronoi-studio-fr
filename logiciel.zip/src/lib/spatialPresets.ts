import type { Settings } from './settings'
import { SPATIAL_DEFAULTS } from '../voronoi/spatial'

const base: Partial<Settings> = {
  ...SPATIAL_DEFAULTS, spatialEnabled: true, cellStyle: 'holes', spatialUnit: 'relative',
  placement: 'even', fill: true, fillColor: '#ffffff', background: '#101010',
  lineColor: '#101010', showSites: false, showEdges: true, showDelaunay: false,
}
export const SPATIAL_PRESETS: { id: string; label: string; settings: Partial<Settings> }[] = [
  { id: 'organic-transition', label: 'Transition organique', settings: {
    ...base, spatialMin: 8, spatialMax: 88, spatialPower: 1.4, spatialPosition: 50,
    spatialDensity: true, spatialDensityIntensity: 35, spatialDensityMax: 8,
    spatialCoupling: 'coupled', spatialNoise: 15,
  } },
  { id: 'thickening', label: 'Épaississement progressif', settings: {
    ...base, spatialMin: 5, spatialMax: 75, spatialProfile: 'linear', spatialPower: 1,
  } },
  { id: 'dense-centre', label: 'Centre dense', settings: {
    ...base, spatialMode: 'radial', spatialRadius: 65, spatialMin: 8, spatialMax: 95,
    spatialDensity: true, spatialDensityIntensity: 60, spatialNoise: 5,
  } },
  { id: 'organic-network', label: 'Réseau organique', settings: {
    ...base, spatialMin: 10, spatialMax: 50, spatialWidth: 200, spatialNoise: 35, spatialNoiseScale: 25,
  } },
  { id: 'open-transition', label: 'Ajourage progressif', settings: {
    ...base, spatialMin: 4, spatialMax: 98, spatialPreserve: true, spatialAllowClosure: false, spatialOpening: 1,
  } },
]
