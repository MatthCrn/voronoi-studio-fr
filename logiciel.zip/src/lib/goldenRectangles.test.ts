import { describe, expect, it } from 'vitest'
import { GOLDEN_RECTANGLES, PHI, goldenRectangle, changeGoldenSheet } from './goldenRectangles'
import { DEFAULTS, sanitizeSettings } from './settings'
import { planChange, type Doc } from './changes'
import { parseProject, serializeProject } from './project'
import { emptyHistory, record, undo, redo } from './history'
import { buildGeometry } from '../voronoi/pattern'
import { laserSvg } from './svgExport'

const doc = (settings = DEFAULTS): Doc => ({ settings, points: Float64Array.from([20, 20, 150, 20, 50, 150, 140, 140]), handEdited: true, stale: false })
describe('Grosjean golden rectangles', () => {
  it('contains fifteen distinct shapes in the book’s order, with calculated ratios', () => {
    expect(GOLDEN_RECTANGLES.map(r => r.id)).toEqual(['VII', 'XV', 'II', 'V', 'III', 'I', 'XII', 'VI', 'VIII', 'IX', 'IV', 'XIII', 'X', 'XIV', 'XI'])
    expect(new Set(GOLDEN_RECTANGLES.map(r => r.id)).size).toBe(15)
    const approximations = [1.082, 1.1278, 1.272, 1.376, 1.5388, 1.618, 2.058, 2.164, 2.236, 2.618, 2.7528, 3.3302, 4.236, 5.388, 6.854]
    GOLDEN_RECTANGLES.forEach((r, i) => {
      expect(Math.abs(r.ratio - approximations[i])).toBeLessThan(.0005)
      if (i) expect(r.ratio).toBeGreaterThan(GOLDEN_RECTANGLES[i - 1].ratio)
    })
    const p = goldenRectangle('VI').ratio
    expect(Math.hypot(p, 1) / Math.hypot(p / 2, 1)).toBeCloseTo(PHI, 12)
    expect(goldenRectangle('VII').ratio * 2).toBe(p)
  })
  it('preserves the last entered side when enabling or comparing shapes', () => {
    let s = changeGoldenSheet(DEFAULTS, { width: 1500, height: 750 })
    s = changeGoldenSheet(s, { goldenEnabled: true })
    expect(s.width).toBe(1500); expect(s.height).toBeCloseTo(927.050983, 5)
    s = changeGoldenSheet(s, { height: 750 })
    expect(s.dimensionAnchor).toBe('height'); expect(s.width).toBeCloseTo(1213.525492, 5)
    s = changeGoldenSheet(s, { goldenForm: 'II' })
    expect(s.height).toBe(750); expect(s.width).toBeCloseTo(750 * Math.sqrt(PHI), 10)
    const off = changeGoldenSheet(s, { goldenEnabled: false })
    expect([off.width, off.height]).toEqual([s.width, s.height])
    expect(changeGoldenSheet(off, { width: 600 }).height).toBe(750)
  })
  it('keeps portrait orientation when one edited side crosses the previous other side', () => {
    let s = changeGoldenSheet({ ...DEFAULTS, width: 750, height: 1500 }, { goldenEnabled: true })
    expect(s.width).toBe(750); expect(s.height).toBeCloseTo(750 * PHI)
    s = changeGoldenSheet(s, { width: 1400 })
    expect(s.width).toBe(1400); expect(s.height).toBeCloseTo(1400 * PHI)
    const swapped = changeGoldenSheet(s, { width: s.height, height: s.width, dimensionAnchor: 'height' })
    expect(swapped.width).toBeCloseTo(s.height); expect(swapped.height).toBeCloseTo(s.width)
    expect(changeGoldenSheet(swapped, { goldenForm: 'VIII' }).height).toBe(swapped.height)
  })
  it('respects both size limits without breaking the selected ratio', () => {
    for (const r of GOLDEN_RECTANGLES) for (const portrait of [false, true]) for (const axis of ['width', 'height'] as const) for (const value of [5, 100, 5000]) {
      const previous = { ...DEFAULTS, goldenEnabled: true, goldenForm: r.id, width: portrait ? 100 : 200, height: portrait ? 200 : 100 }
      const s = changeGoldenSheet(previous, { [axis]: value })
      expect(Math.min(s.width, s.height)).toBeGreaterThanOrEqual(5 - 1e-10)
      expect(Math.max(s.width, s.height)).toBeLessThanOrEqual(5000 + 1e-10)
      expect(Math.max(s.width, s.height) / Math.min(s.width, s.height)).toBeCloseTo(r.ratio, 10)
    }
  })
  it('round-trips the lock and keeps old projects at their original dimensions', () => {
    const settings = changeGoldenSheet(DEFAULTS, { goldenEnabled: true, goldenForm: 'VI' })
    const back = parseProject(serializeProject(doc(settings)))
    expect(back.settings).toEqual(settings)
    const old = JSON.parse(serializeProject(doc({ ...DEFAULTS, width: 1500, height: 750 })))
    old.version = 4; delete old.settings.goldenEnabled; delete old.settings.goldenForm; delete old.settings.dimensionAnchor
    expect(parseProject(JSON.stringify(old)).settings).toMatchObject({ width: 1500, height: 750, goldenEnabled: false })
    expect(sanitizeSettings({ goldenForm: 'invalid', dimensionAnchor: 'bad' })).toMatchObject({ goldenForm: 'I', dimensionAnchor: 'width', goldenEnabled: false })
  })
  it('does not override imported outlines or ellipse dimensions', () => {
    const s = changeGoldenSheet(DEFAULTS, { goldenEnabled: true })
    expect(changeGoldenSheet(s, { shape: 'ellipse' }).goldenEnabled).toBe(false)
    const imported = changeGoldenSheet(s, { shape: 'custom', width: 500, height: 300 })
    expect(imported).toMatchObject({ width: 500, height: 300, goldenEnabled: false })
  })
  it('resizes edited points once and undoes/redoes dimensions and lock together', () => {
    const previous = doc()
    const { next, remake } = planChange(previous, { goldenEnabled: true, goldenForm: 'VIII' })
    expect(remake).toBe(false); expect(next.stale).toBe(false)
    expect(next.points.length).toBe(previous.points.length)
    expect(next.settings.height).toBeCloseTo(200 / Math.sqrt(5))
    const h = record(emptyHistory<Doc>(), previous, null)
    const undone = undo(h, next)!
    expect(undone.state).toBe(previous)
    expect(redo(undone.history, undone.state)!.state).toBe(next)
    const xml = laserSvg(buildGeometry(next.points, next.settings), next.points, next.settings)
    expect(xml).toContain('width="200mm"')
    expect(xml).toContain('height="89.443mm"')
  })
})
