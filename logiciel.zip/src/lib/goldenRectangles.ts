// Grosjean, Le Nombre d'Or (H. Vial), forms I–XV, ordered as in
// the classification on p. 50. Keep calculated ratios, not printed roundings.
export const PHI = (1 + Math.sqrt(5)) / 2
export const GOLDEN_IDS = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', 'XIII', 'XIV', 'XV'] as const
export type GoldenId = typeof GOLDEN_IDS[number]
export type DimensionAnchor = 'width' | 'height'
const parthenon = Math.sqrt(4 * PHI / (4 - PHI ** 2))
const cot36 = 1 / Math.tan(Math.PI / 5)
export const GOLDEN_RECTANGLES: { id: GoldenId; name: string; ratio: number; formula: string }[] = [
  { id: 'VII', name: 'Demi-Parthénon', ratio: parthenon / 2, formula: '√(φ / (4 − φ²))' },
  { id: 'XV', name: 'Racine quatrième de φ', ratio: PHI ** .25, formula: 'φ¼' },
  { id: 'II', name: 'Chéops', ratio: Math.sqrt(PHI), formula: '√φ' },
  { id: 'V', name: 'Forme V', ratio: cot36, formula: 'cot(36°)' },
  { id: 'III', name: 'Forme III', ratio: Math.sqrt(PHI ** 2 - .25), formula: '√(φ² − ¼)' },
  { id: 'I', name: 'Nombre d’or', ratio: PHI, formula: 'φ' },
  { id: 'XII', name: 'Forme XII', ratio: PHI ** 1.5, formula: 'φ³⁄²' },
  { id: 'VI', name: 'Parthénon', ratio: parthenon, formula: '√(4φ / (4 − φ²))' },
  { id: 'VIII', name: 'Racine de cinq', ratio: Math.sqrt(5), formula: '√5' },
  { id: 'IX', name: 'Nombre d’or au carré', ratio: PHI ** 2, formula: 'φ²' },
  { id: 'IV', name: 'Forme IV', ratio: 2 * cot36, formula: '2 cot(36°)' },
  { id: 'XIII', name: 'Forme XIII', ratio: PHI ** 2.5, formula: 'φ⁵⁄²' },
  { id: 'X', name: 'Nombre d’or au cube', ratio: PHI ** 3, formula: 'φ³' },
  { id: 'XIV', name: 'Forme XIV', ratio: PHI ** 3.5, formula: 'φ⁷⁄²' },
  { id: 'XI', name: 'Nombre d’or puissance quatre', ratio: PHI ** 4, formula: 'φ⁴' },
]
export const goldenRectangle = (id: GoldenId) => GOLDEN_RECTANGLES.find(r => r.id === id) ?? GOLDEN_RECTANGLES[5]
export const goldenLabel = (ratio: number) => ratio.toLocaleString('fr-FR', { minimumFractionDigits: 4, maximumFractionDigits: 4 })

export type GoldenSheet = {
  width: number; height: number; shape: string
  goldenEnabled: boolean; goldenForm: GoldenId; dimensionAnchor: DimensionAnchor
}
export function goldenLimits(s: GoldenSheet, anchor: DimensionAnchor, portrait = s.width < s.height): [number, number] {
  const aspect = portrait ? 1 / goldenRectangle(s.goldenForm).ratio : goldenRectangle(s.goldenForm).ratio
  const multiplier = anchor === 'width' ? aspect : 1 / aspect
  return [Math.max(5, 5 * multiplier), Math.min(5000, 5000 * multiplier)]
}
export function fitGolden<T extends GoldenSheet>(s: T, portrait = s.width < s.height): T {
  if (!s.goldenEnabled || s.shape !== 'rect') return s
  const aspect = portrait ? 1 / goldenRectangle(s.goldenForm).ratio : goldenRectangle(s.goldenForm).ratio
  const [lo, hi] = goldenLimits(s, s.dimensionAnchor, portrait)
  const value = Math.max(lo, Math.min(hi, s[s.dimensionAnchor]))
  return { ...s, ...(s.dimensionAnchor === 'width' ? { width: value, height: value / aspect } : { height: value, width: value * aspect }) }
}

// Called before point remapping: dimensions, ratio and undo history form a
// single change. Editing one side never flips the existing orientation.
export function changeGoldenSheet<T extends GoldenSheet>(previous: T, patch: Partial<T>): T {
  let next = { ...previous, ...patch }
  const widthOnly = patch.width !== undefined && patch.height === undefined
  const heightOnly = patch.height !== undefined && patch.width === undefined
  if (widthOnly) next.dimensionAnchor = 'width'
  if (heightOnly) next.dimensionAnchor = 'height'
  if (next.shape !== 'rect') next.goldenEnabled = false
  if (next.goldenEnabled && (patch.goldenEnabled === true || patch.goldenForm !== undefined || patch.width !== undefined || patch.height !== undefined)) {
    const bothDimensions = patch.width !== undefined && patch.height !== undefined
    next = fitGolden(next, bothDimensions ? next.width < next.height : previous.width < previous.height)
  }
  return next
}
