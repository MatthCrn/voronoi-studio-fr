import type { SaveResult } from './saveFile'

type Desktop = {
  saveFile: (filename: string, bytes: Uint8Array) => Promise<SaveResult>
  onBeforeUpdate?: (callback: () => { project: string; unsaved: boolean }) => () => void
}
export const desktop = () => (window as unknown as { voronoiDesktop?: Desktop }).voronoiDesktop
