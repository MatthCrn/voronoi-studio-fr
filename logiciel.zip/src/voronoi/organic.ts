// Whole-side smoothing, shared by preview and exports. At full strength the
// quadratic spline joins edge midpoints: no straight sides remain. Circular
// arc fitting keeps the existing SVG/DXF bulge representation (0.5 µm error).
import { convexHull, insetConvex, isConvex, minWidth, normalize, perimeter, signedArea, type Polygon, type Vec } from './geometry'
import { arcFromBulge, outlineLength, roundOutline, type Hole, type Outline } from './holes'
import { intersection, offset } from './shape'

export type OrganicSettings = { organicEnabled?: boolean; organicAmount?: number }
export const organicActive = (s: OrganicSettings) => !!s.organicEnabled && (s.organicAmount ?? 100) > 0
const mix = (a: Vec, b: Vec, t: number): Vec => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
const distance = (a: Vec, b: Vec) => Math.hypot(a[0] - b[0], a[1] - b[1])

function fit(a: Vec, c: Vec, b: Vec, out: Outline, depth = 0) {
  if (distance(a, b) < 1e-10) return
  const mid = mix(mix(a, c, .5), mix(c, b, .5), .5)
  // Work in chord-local coordinates to avoid cancellation on large sheets.
  const dx = b[0] - a[0], dy = b[1] - a[1], length = Math.hypot(dx, dy)
  const mx = mid[0] - a[0], my = mid[1] - a[1]
  const x = (mx * dx + my * dy) / length, y = (my * dx - mx * dy) / length
  let bulge = 0, error = 0
  if (Math.abs(y) > 1e-12) {
    const cy = (x * x + y * y - length * x) / (2 * y)
    const theta = 2 * Math.atan2(length / 2, cy)
    // Choose the minor arc whose midpoint lies on the same side as the curve.
    const sweep = theta > Math.PI ? theta - 2 * Math.PI : theta < -Math.PI ? theta + 2 * Math.PI : theta
    bulge = Math.tan(sweep / 4)
    const arc = arcFromBulge(a, b, bulge)
    for (const t of [.125, .25, .375, .625, .75, .875]) {
      const p = mix(mix(a, c, t), mix(c, b, t), t)
      error = Math.max(error, Math.abs(Math.hypot(p[0] - arc.cx, p[1] - arc.cy) - arc.r))
    }
  }
  if (depth < 14 && (error > .0005 || Math.abs(bulge) > .5)) {
    const ac = mix(a, c, .5), cb = mix(c, b, .5)
    fit(a, ac, mid, out, depth + 1); fit(mid, cb, b, out, depth + 1)
  } else { out.points.push(a); out.bulges.push(bulge) }
}

export function flattenOrganic(outline: Outline, tolerance = .002): Polygon {
  const points: Polygon = []
  outline.points.forEach((a, i) => {
    points.push(a)
    const bulge = outline.bulges[i]
    if (Math.abs(bulge) < 1e-12) return
    const arc = arcFromBulge(a, outline.points[(i + 1) % outline.points.length], bulge)
    const theta = 4 * Math.atan(bulge)
    const step = 2 * Math.acos(Math.max(-1, Math.min(1, 1 - tolerance / arc.r)))
    const count = Math.max(1, Math.min(4096, Math.ceil(Math.abs(theta) / Math.max(step, 1e-5))))
    for (let j = 1; j < count; j++) {
      const t = arc.start + theta * j / count
      points.push([arc.cx + arc.r * Math.cos(t), arc.cy + arc.r * Math.sin(t)])
    }
  })
  return points
}

// Dilate a convex curved contour by a disk. This adds r to every arc radius
// and tangent circular joins where needed, removing the near-cusps a midpoint
// spline alone leaves at short edges and acute corners. Eroding the input by
// the same r first keeps the complete result inside the original aperture.
function softenConvex(outline: Outline, r: number): Outline {
  const normals = outline.points.map((a, i) => {
    const b = outline.points[(i + 1) % outline.points.length]
    if (Math.abs(outline.bulges[i]) > 1e-12) {
      const arc = arcFromBulge(a, b, outline.bulges[i])
      return { start: [(a[0] - arc.cx) / arc.r, (a[1] - arc.cy) / arc.r] as Vec,
        end: [(b[0] - arc.cx) / arc.r, (b[1] - arc.cy) / arc.r] as Vec }
    }
    const length = distance(a, b)
    const normal: Vec = [(b[1] - a[1]) / length, -(b[0] - a[0]) / length]
    return { start: normal, end: normal }
  })
  const turns = normals.map((n, i) => {
    const p = normals[(i + normals.length - 1) % normals.length].end
    return Math.atan2(p[0] * n.start[1] - p[1] * n.start[0], p[0] * n.start[0] + p[1] * n.start[1])
  })
  // Arc fitting may introduce tiny inward tangent turns. A convex inscribed
  // polygon gives a safe, tangent-continuous fallback with the same radius floor.
  if (turns.some(t => t < -1e-8) || outline.bulges.some(b => b < 0)) {
    return roundOutline(convexHull(flattenOrganic(outline, .002)), r)
  }
  const result: Outline = { points: [], bulges: [] }
  outline.points.forEach((v, i) => {
    const before = normals[(i + normals.length - 1) % normals.length].end
    const after = normals[i].start
    if (turns[i] > 1e-8) {
      result.points.push([v[0] + before[0] * r, v[1] + before[1] * r])
      result.bulges.push(Math.tan(turns[i] / 4))
    }
    result.points.push([v[0] + after[0] * r, v[1] + after[1] * r])
    result.bulges.push(outline.bulges[i])
  })
  return result
}

export function organicHoles(holes: Hole[], amount: number, minimum: number): Hole[] {
  if (amount <= 0) return holes
  const strength = Math.min(1, amount / 100)
  return holes.flatMap(hole => {
    const original = normalize(hole.outline.points)
    const convex = isConvex(original)
    const softRadius = convex ? minWidth(original) * strength * .16 : 0
    // Keep fitted arcs away from the initial boundary, including zero-width webs.
    const pieces = convex ? [insetConvex(original, .003 + softRadius)] : offset([original], -.003, 'miter')
    return pieces.flatMap(poly => {
      if (poly.length < 3) return []
      let outline: Outline = { points: [], bulges: [] }
      poly.forEach((v, i) => {
        const start = mix(v, poly[(i + poly.length - 1) % poly.length], strength / 2)
        const end = mix(v, poly[(i + 1) % poly.length], strength / 2)
        fit(start, v, end, outline)
        const next = mix(poly[(i + 1) % poly.length], v, strength / 2)
        if (distance(end, next) > 1e-9) { outline.points.push(end); outline.bulges.push(0) }
      })
      if (convex) outline = softenConvex(outline, softRadius)
      const sampled = flattenOrganic(outline)
      if (!convex) {
        // Imported concavities need clipping to preserve bridges and boundaries.
        return intersection([sampled], [poly]).filter(p => signedArea(p) > 0)
          .filter(p => !minimum || offset([p], -minimum / 2 + 1e-6, 'miter').length > 0)
          .map(p => ({ cell: hole.cell, outline: { points: p, bulges: p.map(() => 0) },
            width: minWidth(convexHull(p)), area: signedArea(p), length: perimeter(p) }))
      }
      const width = minWidth(convexHull(sampled))
      if (width < minimum || outline.points.length < 3) return []
      let area = signedArea(outline.points)
      outline.points.forEach((p, i) => {
        const bulge = outline.bulges[i]
        if (Math.abs(bulge) < 1e-12) return
        const arc = arcFromBulge(p, outline.points[(i + 1) % outline.points.length], bulge)
        const theta = 4 * Math.atan(bulge)
        area += arc.r * arc.r * (theta - Math.sin(theta)) / 2
      })
      return [{ cell: hole.cell, outline, width, area, length: outlineLength(outline) }]
    })
  })
}
