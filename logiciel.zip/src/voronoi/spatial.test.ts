import { describe, expect, it } from 'vitest'
import { readFileSync } from 'node:fs'
import { DEFAULTS, sanitizeSettings, seedSettings, type Settings } from '../lib/settings'
import { planChange } from '../lib/changes'
import { parseProject, serializeProject } from '../lib/project'
import { laserSvg, artworkSvg } from '../lib/svgExport'
import { cutDxf } from '../lib/dxfExport'
import { SPATIAL_PRESETS } from '../lib/presets'
import { buildGeometry, patternRegion } from './pattern'
import { area, isConvex, signedArea } from './geometry'
import { seedPoints } from './seeding'
import { contains } from './region'
import { densityField } from './density'
import { flattenOutline } from './spatialHoles'
import { SPATIAL_DEFAULTS, axisPosition, spatialField } from './spatial'
import { readSvgOutlines } from '../lib/svgShape'
import { shapeFromOutlines } from './shape'

const settings = (patch: Partial<Settings> = {}): Settings => ({ ...DEFAULTS, count: 80, cellStyle: 'holes', cornerRadius: 0.2,
  spatialEnabled: true, spatialMin: 0.5, spatialMax: 10, spatialProfile: 'linear', spatialPower: 1, ...patch })
const pointsFor = (s: Settings) => seedPoints(seedSettings(s), patternRegion(s)).points
const fixture = (s: Settings) => { const points = pointsFor(s); return { points, geometry: buildGeometry(points, s) } }

describe('continuous spatial field', () => {
  const region = patternRegion(settings())
  it('covers the physical box at all four orientations and wraps through 360 degrees', () => {
    for (const angle of [0, 45, 90, 180, 270, 360]) {
      const values = [[region.x0, region.y0], [region.x1, region.y0], [region.x1, region.y1], [region.x0, region.y1]].map(([x, y]) => axisPosition(x, y, region, angle))
      expect(Math.min(...values)).toBeCloseTo(0); expect(Math.max(...values)).toBeCloseTo(1)
    }
    expect(axisPosition(60, 40, region, 0)).toBeCloseTo(axisPosition(60, 40, region, 360))
    expect(axisPosition(region.x0, region.y0, region, 90)).toBeCloseTo(1)
  })
  it('moves and inverts a circular radial field', () => {
    const s = settings({ spatialMode: 'radial', spatialCenterX: 25, spatialCenterY: 75, spatialRadius: 25 })
    const x = region.x0 + (region.x1 - region.x0) * .25, y = region.y0 + (region.y1 - region.y0) * .75
    expect(spatialField(s, region)(x, y)).toBe(1)
    expect(spatialField({ ...s, spatialInvert: true }, region)(x, y)).toBe(0)
    expect(spatialField(s, region)(x + 100, y)).toBe(0)
  })
  it.each(['linear', 'easeIn', 'easeOut', 'smooth', 'accent'] as const)('keeps %s profiles bounded and monotonic', spatialProfile => {
    const field = spatialField(settings({ spatialProfile, spatialPower: 1.7 }), region)
    const values = Array.from({ length: 101 }, (_, i) => field(region.x0 + (region.x1 - region.x0) * i / 100, 100))
    expect(values[0]).toBeCloseTo(0); expect(values[100]).toBeCloseTo(1)
    values.forEach((v, i) => { expect(v).toBeGreaterThanOrEqual(0); expect(v).toBeLessThanOrEqual(1); if (i) expect(v).toBeGreaterThanOrEqual(values[i - 1]) })
  })
  it('localises a transition and produces continuous seeded noise', () => {
    const s = settings({ spatialPosition: 70, spatialWidth: 20, spatialNoise: 15 })
    const a = spatialField(s, region), b = spatialField(s, region), c = spatialField({ ...s, spatialNoiseSeed: 9 }, region)
    expect(a(20, 50)).toBeLessThan(.15); expect(a(180, 50)).toBeGreaterThan(.85)
    expect(a(130, 100)).toBe(b(130, 100)); expect(a(130, 100)).not.toBe(c(130, 100))
    expect(Math.abs(a(130, 100) - a(130.0001, 100))).toBeLessThan(1e-4)
  })
})

describe('real apertures and material', () => {
  it('makes smaller right-hand openings while keeping all contours valid', () => {
    const s = settings(), { geometry: g } = fixture(s)
    const left = g.holes.filter(h => h.outline.points[0][0] < 65), right = g.holes.filter(h => h.outline.points[0][0] > 135)
    expect(left.length).toBeGreaterThan(0); expect(right.length).toBeGreaterThan(0)
    expect(left.reduce((a, h) => a + h.area, 0) / left.length).toBeGreaterThan(right.reduce((a, h) => a + h.area, 0) / right.length)
    for (const hole of g.holes) {
      expect(hole.area).toBeGreaterThan(0); expect(hole.width).toBeGreaterThanOrEqual(s.spatialOpening)
      expect(hole.outline.points.length).toBe(hole.outline.bulges.length)
      expect(signedArea(hole.outline.points)).toBeGreaterThan(0)
      expect(isConvex(hole.outline.points)).toBe(true)
      hole.outline.points.forEach(([x, y]) => { expect(Number.isFinite(x + y)).toBe(true); expect(contains(g.region, x, y)).toBe(true) })
      expect(area(flattenOutline(hole.outline, .001))).toBeCloseTo(hole.area, 1)
    }
  })
  it('closes cells without leaving cut paths, and preserves openings when feasible', () => {
    const s = settings({ spatialMax: 100, spatialUnit: 'relative', spatialMin: 5 })
    const { points, geometry: closed } = fixture(s)
    expect(closed.metrics.spatial!.closed).toBeGreaterThan(0)
    const preserved = buildGeometry(points, { ...s, spatialPreserve: true })
    expect(preserved.holes.length).toBeGreaterThan(closed.holes.length)
    expect(preserved.metrics.spatial!.limited).toBeGreaterThan(0)
    expect(preserved.holes.every(h => h.width >= s.spatialOpening)).toBe(true)
    const full = buildGeometry(points, { ...s, spatialUnit: 'absolute', spatialMin: 500, spatialMax: 500 })
    expect(full.holes).toHaveLength(0); expect(full.metrics.spatial!.material).toBe(100)
    expect(laserSvg(full, points, { ...s, showSites: false })).not.toContain(' A')
  })
  it('measures real area and solves reachable targets without violating thickness bounds', () => {
    const s = settings({ spatialMin: .3, spatialMax: 20, spatialOpening: 0 })
    const points = pointsFor(s), g = buildGeometry(points, s)
    expect(g.metrics.spatial!.material).toBeCloseTo(100 * (1 - g.holes.reduce((a, h) => a + h.area, 0) / (s.width * s.height)))
    const target = buildGeometry(points, { ...s, spatialRatioMode: 'target', spatialRatio: 60 })
    expect(target.metrics.spatial!.material).toBeCloseTo(60, 0)
    expect(target.metrics.spatial!.reachable).toBe(true)
    expect(target.metrics.spatial!.rangeMin).toBeGreaterThanOrEqual(.3)
    expect(target.metrics.spatial!.rangeMax).toBeLessThanOrEqual(20)
    const unreachable = buildGeometry(points, { ...s, spatialMin: 0, spatialMax: 0, spatialRatioMode: 'target', spatialRatio: 100 })
    expect(unreachable.metrics.spatial!.reachable).toBe(false)
  })
  it('applies fabrication constraints and analyses continuity', () => {
    const s = settings({ spatialFabrication: true, spatialMinWeb: 2, spatialTool: 3, spatialCheckIslands: true })
    const { geometry: g } = fixture(s)
    expect(g.metrics.spatial!.rangeMin).toBeGreaterThanOrEqual(2)
    expect(g.metrics.spatial!.toolWarnings).toBe(0)
    expect(g.metrics.spatial!.islands).toBe(0)
    expect(g.holes.every(h => h.width >= 3)).toBe(true)
  })
  it('handles concave imported supports with internal openings', () => {
    const raw = readSvgOutlines('<svg width="200mm" height="120mm" viewBox="0 0 200 120"><path d="M0 0H200V120H110V60H90V120H0Z"/><circle cx="40" cy="45" r="12"/></svg>')
    const s = settings({ shape: 'custom', width: 200, height: 120, customShape: shapeFromOutlines(raw.rings, 'forme.svg', raw.units), spatialCheckIslands: true })
    const { geometry: g } = fixture(s)
    expect(g.holes.length).toBeGreaterThan(0)
    expect(g.holes.every(h => h.area > 0 && h.outline.points.every(([x, y]) => Number.isFinite(x + y)))).toBe(true)
    expect(g.metrics.spatial!.material).toBeGreaterThan(0)
    expect(g.metrics.spatial!.islands).toBe(0)
  })
})

describe('density, history and compatibility', () => {
  it('weights point sampling, inverts coupling, and repeats exactly', () => {
    const s = settings({ count: 500, spatialDensity: true, spatialDensityMax: 10, spatialDensityIntensity: 100, spatialNoise: 0 })
    const a = pointsFor(s), b = pointsFor(s)
    expect(a).toEqual(b)
    const average = (p: Float64Array) => Array.from(p).filter((_, i) => i % 2 === 0).reduce((a, b) => a + b, 0) / (p.length / 2)
    expect(average(a)).toBeGreaterThan(115)
    expect(average(pointsFor({ ...s, spatialCoupling: 'inverse' }))).toBeLessThan(85)
    const independent = { ...s, spatialCoupling: 'independent' as const, spatialDensityAngle: 180 }
    expect(densityField(seedSettings(independent).density, patternRegion(independent))(10, 100)).toBeGreaterThan(densityField(seedSettings(independent).density, patternRegion(independent))(190, 100))
  })
  it('keeps points and tessellation for thickness changes; density changes protect hand edits', () => {
    const s = settings({ spatialDensity: true }), points = pointsFor(s), doc = { settings: s, points, handEdited: false, stale: false }
    const thickness = planChange(doc, { spatialMax: 14 })
    expect(thickness.remake).toBe(false); expect(thickness.next.points).toBe(points)
    expect(buildGeometry(points, s).cells).toBe(buildGeometry(points, thickness.next.settings).cells)
    expect(planChange(doc, { spatialDensityIntensity: 90 }).remake).toBe(true)
    const hand = planChange({ ...doc, handEdited: true }, { spatialDensityIntensity: 90 })
    expect(hand.remake).toBe(false); expect(hand.next.stale).toBe(true)
  })
  it('completely ignores disabled spatial parameters in geometry and every vector export', () => {
    const s = settings({ spatialEnabled: false }), { points, geometry: g } = fixture(s)
    const modified = { ...s, spatialMin: 500, spatialMax: 500, spatialDensity: true, spatialNoise: 99, spatialRatioMode: 'target' as const, spatialRatio: 100 }
    expect(pointsFor(modified)).toEqual(points)
    const other = buildGeometry(points, modified)
    expect(other).toEqual(g)
    expect(laserSvg(other, points, modified)).toBe(laserSvg(g, points, s))
    expect(artworkSvg(other, points, modified)).toBe(artworkSvg(g, points, s))
    expect(cutDxf(other, points, modified)).toBe(cutDxf(g, points, s))
  })
  it('opens legacy settings disabled and round-trips every new field and hand edit', () => {
    expect(sanitizeSettings({}).spatialEnabled).toBe(false)
    const old = JSON.parse(readFileSync('test-fixtures/minimal-v1.voronoi.json', 'utf8'))
    expect(parseProject(JSON.stringify(old)).settings.spatialEnabled).toBe(false)
    expect(parseProject(JSON.stringify({ ...old, version: 2 })).settings.spatialEnabled).toBe(false)
    const s = settings({ ...SPATIAL_PRESETS[0].settings }), points = pointsFor(s)
    const saved = parseProject(serializeProject({ settings: s, points, handEdited: true }))
    for (const key of Object.keys(SPATIAL_DEFAULTS) as (keyof typeof SPATIAL_DEFAULTS)[]) expect(saved.settings[key]).toEqual(s[key])
    expect(saved.handEdited).toBe(true)
    const malformed = sanitizeSettings({ spatialEnabled: true, spatialAngle: Infinity, spatialPower: -12, spatialMode: 'unsafe', spatialUnit: 'relative', spatialMax: 900 })
    expect(malformed.spatialAngle).toBe(0); expect(malformed.spatialPower).toBe(.1); expect(malformed.spatialMode).toBe('linear'); expect(malformed.spatialMax).toBe(100)
  })
  it.each(SPATIAL_PRESETS)('generates valid editable preset $label', preset => {
    const s = settings(preset.settings), { geometry: g } = fixture(s)
    expect(g.metrics.spatial!.material).toBeGreaterThan(0)
    expect(g.holes.every(h => h.area > 0 && Number.isFinite(h.length))).toBe(true)
  })
  it('exports every spatial aperture as closed geometry with matching millimetre dimensions', () => {
    const s = settings({ ...SPATIAL_PRESETS[0].settings, cornerRadius: 0 }), { points, geometry: g } = fixture(s)
    const svg = laserSvg(g, points, s), dxf = cutDxf(g, points, s)
    expect(svg).toContain('width="200mm"'); expect(svg).toContain('height="200mm"')
    const inner = svg.split('id="cut-inner"')[1].split('</g>')[0]
    const paths = [...inner.matchAll(/<path[^>]*d="([^"]+)"/g)].map(m => m[1])
    expect(paths).toHaveLength(g.holes.length)
    expect(paths.every(p => p.endsWith('Z'))).toBe(true)
    expect(new Set(paths).size).toBe(paths.length)
    expect(dxf.match(/\nPOLYLINE\n/g)?.length).toBe(g.holes.length + 1)
    expect(dxf).toContain('CUT_INNER'); expect(dxf).toContain('CUT_OUTER')
  })
})
