import type { Cells } from './diagram'
import { area, clipHalfPlane, insetConvex, isConvex, minWidth, normalize, type Polygon, type Vec } from './geometry'
import { arcFromBulge, makeHoles, solidPieces, type Hole, type Outline } from './holes'
import { regionArea, regionPolygon, type Region } from './region'
import { difference, groupRings, offset } from './shape'
import { clamp01, spatialField, type SpatialSettings } from './spatial'
import { organicActive, organicHoles, type OrganicSettings } from './organic'

export type SpatialMetrics = {
  material: number; requested: number | null; reachable: boolean; closed: number
  limited: number; islands: number | null; toolWarnings: number
  rangeMin: number; rangeMax: number
}
type Options = SpatialSettings & OrganicSettings & { cornerRadius: number }

// Polygonise true arcs only for optional material-connectivity checks. Rendering
// and SVG/DXF exports retain their original shared bulge representation.
export function flattenOutline(outline: Outline, tolerance: number): Polygon {
  const out: Polygon = []
  outline.points.forEach((a, i) => {
    out.push(a)
    const bulge = outline.bulges[i]
    if (Math.abs(bulge) < 1e-12) return
    const b = outline.points[(i + 1) % outline.points.length]
    const arc = arcFromBulge(a, b, bulge), theta = 4 * Math.atan(bulge)
    const step = Math.max(1e-4, 2 * Math.acos(Math.max(-1, Math.min(1, 1 - tolerance / arc.r))))
    const count = Math.max(1, Math.min(2048, Math.ceil(Math.abs(theta) / step)))
    for (let j = 1; j < count; j++) {
      const t = arc.start + theta * j / count
      out.push([arc.cx + arc.r * Math.cos(t), arc.cy + arc.r * Math.sin(t)])
    }
  })
  return out
}

// A shared continuous field shifts the ends of each edge inward. Intersections
// of the shifted half-planes stay convex and inside the original cell, even for
// large gradients. Both sides of an edge sample the same physical coordinates.
function variableInset(poly: Polygon, distance: (p: Vec) => number, safetyInset: number): Polygon[] {
  const p = normalize(poly)
  if (isConvex(p)) {
    // Intersect with a uniform safety erosion: steep fields must never reduce
    // the physical minimum below the manufacturing floor at a slanted edge.
    let result = insetConvex(p, safetyInset)
    for (let i = 0; i < p.length && result.length; i++) {
      const a = p[i], b = p[(i + 1) % p.length]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1])
      if (length < 1e-8) continue
      const nx = -(b[1] - a[1]) / length, ny = (b[0] - a[0]) / length
      const da = distance(a), db = distance(b)
      const ax = a[0] + nx * da, ay = a[1] + ny * da
      const bx = b[0] + nx * db, by = b[1] + ny * db
      const u = -(by - ay), v = bx - ax
      result = clipHalfPlane(result, u, v, u * ax + v * ay)
    }
    result = normalize(result)
    return result.length >= 3 && area(result) > 1e-8 ? [result] : []
  }
  // Concave, imported contours: subtract inward boundary strips with Clipper2.
  const strips: Polygon[] = []
  p.forEach((a, i) => {
    const b = p[(i + 1) % p.length], length = Math.hypot(b[0] - a[0], b[1] - a[1])
    if (length < 1e-8) return
    const nx = -(b[1] - a[1]) / length, ny = (b[0] - a[0]) / length
    const da = distance(a), db = distance(b)
    strips.push(normalize([a, b, [b[0] + nx * db, b[1] + ny * db], [a[0] + nx * da, a[1] + ny * da]]))
  })
  return difference(offset([p], -safetyInset, 'miter'), strips)
}

export function makeSpatialHoles(cells: Cells, s: Options, region: Region, sheet: Region): { holes: Hole[]; metrics: SpatialMetrics } {
  const field = spatialField(s, region)
  const minimum = Math.min(s.spatialMin, s.spatialMax), maximum = Math.max(s.spatialMin, s.spatialMax)
  const floor = s.spatialFabrication ? Math.max(0.005, s.spatialMinWeb) : 0.005
  const opening = Math.max(s.spatialOpening, s.spatialRemoveMicro ? s.spatialMicro : 0, s.spatialFabrication ? s.spatialTool : 0, 0.005)
  const requestedRadius = Math.max(s.cornerRadius, s.spatialFabrication ? s.spatialTool / 2 : 0)
  const radius = requestedRadius < 0.005 ? 0 : requestedRadius
  const pieces = cells.flatMap((cell, index) => cell ? solidPieces(cell).map(poly => ({ poly, index, width: minWidth(poly) })) : [])
  const sheetArea = Math.max(1e-12, regionArea(sheet))
  function generate(shift: number) {
    const holes: Hole[] = []
    let limited = 0, actualMin = Infinity, actualMax = 0
    for (const { poly, index, width } of pieces) {
      const unit = s.spatialUnit === 'relative' ? width / 100 : 1
      function make(factor: number) {
        const distance = (p: Vec) => {
          const value = Math.max(floor, (minimum + (maximum - minimum) * clamp01(field(...p) + shift) * factor) * unit)
          return value / 2
        }
        const inset = variableInset(poly, distance, floor / 2)
        const organic = organicActive(s)
        const raw = inset.length ? makeHoles(inset, index, { web: 0, radius: organic ? 0 : radius, minHole: opening }) : []
        return organic ? organicHoles(raw, s.organicAmount ?? 100, opening) : raw
      }
      let result = make(1), factor = 1
      if (!result.length && (s.spatialPreserve || !s.spatialAllowClosure)) {
        const smallest = make(0)
        if (smallest.length) {
          let lo = 0, hi = 1
          result = smallest
          for (let j = 0; j < 10; j++) {
            const mid = (lo + hi) / 2, trial = make(mid)
            if (trial.length) { lo = mid; result = trial } else hi = mid
          }
          factor = lo; limited++
        } else limited++
      }
      for (const p of poly) {
        const web = Math.max(floor, (minimum + (maximum - minimum) * clamp01(field(...p) + shift) * factor) * unit)
        actualMin = Math.min(actualMin, web); actualMax = Math.max(actualMax, web)
      }
      holes.push(...result)
    }
    const ratio = 100 * clamp01(1 - holes.reduce((sum, hole) => sum + hole.area, 0) / sheetArea)
    return { holes, ratio, limited, actualMin: Number.isFinite(actualMin) ? actualMin : 0, actualMax }
  }
  let result = generate(0)
  if (s.spatialRatioMode === 'target') {
    let lo = -1, hi = 1
    const low = generate(lo), high = generate(hi)
    result = Math.abs(low.ratio - s.spatialRatio) < Math.abs(high.ratio - s.spatialRatio) ? low : high
    if (s.spatialRatio >= low.ratio && s.spatialRatio <= high.ratio) {
      for (let i = 0; i < 10; i++) {
        const mid = (lo + hi) / 2, trial = generate(mid)
        if (Math.abs(trial.ratio - s.spatialRatio) < Math.abs(result.ratio - s.spatialRatio)) result = trial
        if (trial.ratio < s.spatialRatio) lo = mid; else hi = mid
        if (Math.abs(result.ratio - s.spatialRatio) < 0.2) break
      }
    }
  }
  let islands: number | null = null
  if (s.spatialCheckIslands) {
    const material = difference(sheet.shape === 'custom' ? sheet.rings ?? [] : [regionPolygon(sheet)], result.holes.map(h => flattenOutline(h.outline, s.spatialTolerance)))
    islands = Math.max(0, groupRings(material).length - 1)
  }
  const kept = new Set(result.holes.map(h => h.cell))
  return { holes: result.holes, metrics: {
    material: result.ratio, requested: s.spatialRatioMode === 'target' ? s.spatialRatio : null,
    reachable: s.spatialRatioMode !== 'target' || s.spatialRatio === 0
      || (s.spatialRatio === 100 ? result.holes.length === 0 : Math.abs(result.ratio - s.spatialRatio) <= 1),
    closed: cells.filter(Boolean).length - kept.size, limited: result.limited, islands,
    toolWarnings: s.spatialFabrication ? result.holes.filter(h => h.width + 1e-6 < s.spatialTool).length : 0,
    rangeMin: result.actualMin, rangeMax: result.actualMax,
  } }
}
