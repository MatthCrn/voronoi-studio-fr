// Everything drawn or exported for one design, built from the points and the settings in one place, so the
// preview, the PNG, the SVGs and the DXF always agree.
import { buildDiagram, cellArea, delaunayEdges, type Cells } from './diagram'
import { segmentLength, type Segment } from './geometry'
import { makeHoles, type Hole } from './holes'
import { organicActive, organicHoles, type OrganicSettings } from './organic'
import { insetRegion, regionPerimeter, sheetRegion, type Region, type Shape } from './region'
import type { CustomShape } from './shape'
import { spatialConfig, type SpatialSettings } from './spatial'
import { makeSpatialHoles, type SpatialMetrics } from './spatialHoles'

export type CellStyle = 'lines' | 'holes'
export type PatternSettings = Partial<SpatialSettings> & OrganicSettings & {
  width: number; height: number; shape: Shape; customShape: CustomShape | null; border: number
  cellStyle: CellStyle; web: number; cornerRadius: number; minHole: number
  showDelaunay: boolean
}
export type Metrics = {
  cells: number; holes: number; dropped: number // dropped: cells too small for a hole
  meanSize: number // diameter of a circle with the mean cell area, mm
  evenness: number // coefficient of variation of cell areas, 0–1
  narrowest: number // narrowest kept hole, mm (holes style)
  shortestEdge: number // shortest inner edge, mm (lines style)
  cutLength: number // all cut lines including the sheet outline, mm
  spatial?: SpatialMetrics
}
export type Geometry = {
  sheet: Region
  region: Region
  cells: Cells
  edges: { internal: Segment[] }
  holes: Hole[]
  delaunay: Segment[]
  metrics: Metrics
}

// The region cells fill. In Holes style the region reaches half a web past the border, so after the holes
// shrink by half a web the solid frame is exactly the border.
export function patternRegion(s: Pick<PatternSettings, 'width' | 'height' | 'shape' | 'customShape' | 'border' | 'cellStyle' | 'web' | 'spatialEnabled'>): Region {
  const inset = s.cellStyle === 'holes' && !s.spatialEnabled ? Math.max(0, s.border - s.web / 2) : s.border
  return insetRegion(sheetRegion(s.width, s.height, s.shape, s.customShape), inset)
}

const diagrams = new WeakMap<Float64Array, { key: string; custom: CustomShape | null; diagram: ReturnType<typeof buildDiagram> }>()
function cachedDiagram(points: Float64Array, region: Region, custom: CustomShape | null) {
  const key = [region.shape, region.x0, region.y0, region.x1, region.y1].join(':')
  const cached = diagrams.get(points)
  if (cached?.key === key && cached.custom === custom) return cached.diagram
  const diagram = buildDiagram(points, region)
  diagrams.set(points, { key, custom, diagram })
  return diagram
}

export function buildGeometry(points: Float64Array, s: PatternSettings): Geometry {
  const sheet = sheetRegion(s.width, s.height, s.shape, s.customShape)
  const region = patternRegion(s)
  const { cells, internal } = cachedDiagram(points, region, s.customShape)
  const edges = { internal }
  const holes: Hole[] = []
  let dropped = 0
  let spatial: SpatialMetrics | undefined
  if (s.cellStyle === 'holes' && s.spatialEnabled) {
    const result = makeSpatialHoles(cells, { ...spatialConfig(s), cornerRadius: s.cornerRadius, organicEnabled: s.organicEnabled, organicAmount: s.organicAmount }, region, sheet)
    holes.push(...result.holes); spatial = result.metrics; dropped = spatial.closed
  } else if (s.cellStyle === 'holes') {
    const organic = organicActive(s)
    const settings = { web: s.web, radius: organic ? 0 : s.cornerRadius, minHole: s.minHole }
    cells.forEach((cell, i) => {
      if (!cell) return
      const raw = makeHoles(cell, i, settings)
      const made = organic ? organicHoles(raw, s.organicAmount ?? 100, s.minHole) : raw
      if (made.length) holes.push(...made)
      else dropped++
    })
  }
  const delaunay = s.showDelaunay ? delaunayEdges(points, region) : []
  const metrics = measure(cells, edges, holes, dropped, sheet, region, s)
  if (spatial) metrics.spatial = spatial
  return { sheet, region, cells, edges, holes, delaunay, metrics }
}

function measure(cells: Cells, edges: Geometry['edges'], holes: Hole[], dropped: number, sheet: Region, region: Region, s: PatternSettings): Metrics {
  const areas = cells.flatMap(cell => (cell ? [cellArea(cell)] : []))
  const mean = areas.length ? areas.reduce((a, b) => a + b, 0) / areas.length : 0
  const sd = areas.length ? Math.sqrt(areas.reduce((a, b) => a + (b - mean) ** 2, 0) / areas.length) : 0
  let cutLength = regionPerimeter(sheet)
  let shortestEdge = 0, narrowest = 0
  if (s.cellStyle === 'holes') {
    for (const hole of holes) cutLength += hole.length
    narrowest = holes.reduce((m, h) => Math.min(m, h.width), holes.length ? Infinity : 0)
  } else {
    let shortest = Infinity
    for (const e of edges.internal) { const l = segmentLength(e); cutLength += l; shortest = Math.min(shortest, l) }
    // The pattern's own outline is a cut too, unless it sits right on the sheet edge.
    if (s.border > 1e-9) cutLength += regionPerimeter(region)
    shortestEdge = Number.isFinite(shortest) ? shortest : 0
  }
  return {
    cells: areas.length, holes: holes.length, dropped,
    meanSize: 2 * Math.sqrt(mean / Math.PI),
    evenness: mean > 0 ? sd / mean : 0,
    narrowest, shortestEdge, cutLength,
  }
}
