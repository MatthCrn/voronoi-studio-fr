import { describe, expect, it } from 'vitest'
import { LEGACY_DEFAULTS as DEFAULTS, sanitizeSettings, seedSettings } from '../lib/settings'
import { parseProject, serializeProject } from '../lib/project'
import { artworkSvg, laserSvg } from '../lib/svgExport'
import { cutDxf } from '../lib/dxfExport'
import { area, clipConvex, isConvex, minWidth, signedArea, type Polygon } from './geometry'
import { arcFromBulge, makeHole } from './holes'
import { flattenOrganic, organicHoles } from './organic'
import { buildGeometry, patternRegion } from './pattern'
import { seedPoints } from './seeding'
import { difference } from './shape'

const square: Polygon = [[0, 0], [20, 0], [20, 20], [0, 20]]
const raw = makeHole(square, 0, { web: 0, radius: 0, minHole: 0 })!

describe('organic whole-contour smoothing', () => {
  it('curves every side at full strength and measures the actual curved area', () => {
    const hole = organicHoles([raw], 100, 0)[0]
    expect(hole.outline.bulges.some(b => b > 0)).toBe(true)
    const poly = flattenOrganic(hole.outline, .00002)
    expect(isConvex(poly)).toBe(true)
    expect(hole.area).toBeCloseTo(area(poly), 2)
    expect(hole.area).toBeLessThan(raw.area)
    expect(hole.length).toBeLessThan(raw.length)
    expect(area(clipConvex(poly, square))).toBeCloseTo(area(poly), 5)
  })

  it.each([
    [[0, 0], [200, 15], [0, 30]],
    [[0, 0], [200, 0], [200, 100], [199.8, 100.2], [0, 100]],
    [[0, 0], [50, 0], [50.001, .001], [80, 90], [0, 100]],
  ].map(points => ({ points: points as Polygon })))('removes spikes from acute corners and tiny edges: $points', ({ points }) => {
    for (const strength of [40, 80, 100]) {
      const rawHole = makeHole(points, 0, { web: 0, radius: 0, minHole: 0 })!
      const h = organicHoles([rawHole], strength, .01)[0]
      const radiusFloor = minWidth(points) * strength / 100 * .16
      h.outline.points.forEach((a, i) => {
        const b = h.outline.bulges[i]
        if (Math.abs(b) < 1e-12) return
        expect(arcFromBulge(a, h.outline.points[(i + 1) % h.outline.points.length], b).r).toBeGreaterThanOrEqual(radiusFloor - 1e-6)
      })
      const sampled = flattenOrganic(h.outline, .001)
      expect(isConvex(sampled)).toBe(true)
      expect(area(clipConvex(sampled, points))).toBeCloseTo(area(sampled), 4)
    }
  })

  it('keeps intermediate shapes and the disabled path deterministic', () => {
    expect(organicHoles([raw], 0, 0)[0]).toBe(raw)
    const half = organicHoles([raw], 50, 0)[0]
    expect(half.outline.bulges.some(b => b === 0)).toBe(true)
    expect(half.outline.bulges.some(b => b !== 0)).toBe(true)
    expect(half.area).toBeGreaterThan(organicHoles([raw], 100, 0)[0].area)
    expect(organicHoles([raw], 50, 0)).toEqual([half])
    expect(organicHoles([raw], 100, 21)).toEqual([])
  })

  it('clips concave imported holes inside their original boundaries', () => {
    const points: Polygon = [[0, 0], [30, 0], [30, 10], [10, 10], [10, 30], [0, 30]]
    const holes = organicHoles([{ ...raw, outline: { points, bulges: points.map(() => 0) } }], 100, .5)
    expect(holes.length).toBeGreaterThan(0)
    for (const h of holes) {
      expect(signedArea(h.outline.points)).toBeGreaterThan(0)
      expect(difference([h.outline.points], [points]).reduce((sum, p) => sum + area(p), 0)).toBeLessThan(.001)
      expect(h.area).toBeLessThan(area(points))
    }
  })

  it.each([false, true])('shares curved geometry across preview, SVG and DXF (gradient=%s)', spatialEnabled => {
    const s = { ...DEFAULTS, count: 60, cellStyle: 'holes' as const, organicEnabled: true,
      organicAmount: 100, showSites: false, spatialEnabled, spatialMax: 5 }
    const points = seedPoints(seedSettings(s), patternRegion(s)).points
    const g = buildGeometry(points, s)
    expect(g.holes.length).toBeGreaterThan(40)
    for (const h of g.holes) {
      const p = flattenOrganic(h.outline)
      expect(isConvex(p)).toBe(true)
      expect(h.area).toBeGreaterThan(0)
      expect(h.area).toBeCloseTo(area(p), 0)
      expect(h.outline.bulges.some(b => b > 0)).toBe(true)
      const cell = g.cells[h.cell]![0]
      expect(area(clipConvex(p, cell))).toBeCloseTo(area(p), 4)
    }
    expect(laserSvg(g, points, s)).toMatch(/A\d/)
    expect(artworkSvg(g, points, s)).toMatch(/A\d/)
    expect(cutDxf(g, points, s)).toMatch(/\n42\n(?!0\n)/)
    const reopened = parseProject(serializeProject({ settings: s, points, handEdited: false }))
    expect(reopened.settings.organicEnabled).toBe(true)
    expect(reopened.settings.organicAmount).toBe(100)
    expect(buildGeometry(reopened.points, reopened.settings).metrics.cutLength).toBeCloseTo(g.metrics.cutLength, 1)
  })

  it('opens old projects without changing their contours and clamps new settings', () => {
    const s = { ...DEFAULTS, count: 10, cellStyle: 'holes' as const }
    const points = seedPoints(seedSettings(s), patternRegion(s)).points
    const old = JSON.parse(serializeProject({ settings: s, points, handEdited: false }))
    old.version = 3; delete old.settings.organicEnabled; delete old.settings.organicAmount
    const back = parseProject(JSON.stringify(old))
    expect(back.settings.organicEnabled).toBe(false)
    expect(buildGeometry(points, { ...s, organicEnabled: true, organicAmount: 0 })).toEqual(buildGeometry(points, s))
    expect(sanitizeSettings({ organicAmount: 150 }).organicAmount).toBe(100)
  })
})
