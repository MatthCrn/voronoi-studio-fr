import type { Region } from './region'

// A pure field shared by geometry and point sampling. Additional influence sources
// can be composed here without changing the Voronoi or file-export engines.
export type SpatialSettings = {
  spatialEnabled: boolean; spatialMode: 'linear' | 'radial'; spatialAngle: number
  spatialUnit: 'absolute' | 'relative'; spatialMin: number; spatialMax: number
  spatialProfile: 'linear' | 'easeIn' | 'easeOut' | 'smooth' | 'accent'
  spatialPower: number; spatialPosition: number; spatialWidth: number
  spatialCenterX: number; spatialCenterY: number; spatialRadius: number; spatialInvert: boolean
  spatialNoise: number; spatialNoiseScale: number; spatialNoiseSeed: number
  spatialDensity: boolean; spatialDensityMin: number; spatialDensityMax: number
  spatialDensityIntensity: number; spatialDensityInvert: boolean; spatialDensityAngle: number
  spatialCoupling: 'independent' | 'coupled' | 'inverse'; spatialCouplingStrength: number
  spatialRatioMode: 'manual' | 'target'; spatialRatio: number
  spatialOpening: number; spatialAllowClosure: boolean; spatialPreserve: boolean
  spatialRemoveMicro: boolean; spatialMicro: number
  spatialFabrication: boolean; spatialMinWeb: number; spatialTool: number; spatialTolerance: number
  spatialCheckIslands: boolean
}

export const SPATIAL_DEFAULTS: SpatialSettings = {
  spatialEnabled: false, spatialMode: 'linear', spatialAngle: 0,
  spatialUnit: 'absolute', spatialMin: 0.5, spatialMax: 8,
  spatialProfile: 'smooth', spatialPower: 1.4, spatialPosition: 50, spatialWidth: 100,
  spatialCenterX: 50, spatialCenterY: 50, spatialRadius: 70.71, spatialInvert: false,
  spatialNoise: 0, spatialNoiseScale: 15, spatialNoiseSeed: 1,
  spatialDensity: false, spatialDensityMin: 1, spatialDensityMax: 4,
  spatialDensityIntensity: 35, spatialDensityInvert: false, spatialDensityAngle: 0,
  spatialCoupling: 'coupled', spatialCouplingStrength: 100,
  spatialRatioMode: 'manual', spatialRatio: 50,
  spatialOpening: 0.5, spatialAllowClosure: true, spatialPreserve: false,
  spatialRemoveMicro: true, spatialMicro: 0.15,
  spatialFabrication: false, spatialMinWeb: 0.5, spatialTool: 0, spatialTolerance: 0.02,
  spatialCheckIslands: false,
}

type NumberKey = { [K in keyof SpatialSettings]: SpatialSettings[K] extends number ? K : never }[keyof SpatialSettings]
export const SPATIAL_RANGES: Record<NumberKey, [number, number]> = {
  spatialAngle: [0, 360], spatialMin: [0, 500], spatialMax: [0, 500],
  spatialPower: [0.1, 8], spatialPosition: [0, 100], spatialWidth: [1, 200],
  spatialCenterX: [0, 100], spatialCenterY: [0, 100], spatialRadius: [1, 200],
  spatialNoise: [0, 100], spatialNoiseScale: [1, 100], spatialNoiseSeed: [0, 999999],
  spatialDensityMin: [0.1, 10], spatialDensityMax: [0.1, 10], spatialDensityIntensity: [0, 100],
  spatialDensityAngle: [0, 360], spatialCouplingStrength: [0, 100], spatialRatio: [0, 100],
  spatialOpening: [0, 200], spatialMicro: [0, 20], spatialMinWeb: [0, 100],
  spatialTool: [0, 100], spatialTolerance: [0.001, 0.1],
}
export const SPATIAL_CHOICES = {
  spatialMode: ['linear', 'radial'], spatialUnit: ['absolute', 'relative'],
  spatialProfile: ['linear', 'easeIn', 'easeOut', 'smooth', 'accent'],
  spatialCoupling: ['independent', 'coupled', 'inverse'], spatialRatioMode: ['manual', 'target'],
} as const
export const SPATIAL_KEYS = Object.keys(SPATIAL_DEFAULTS) as (keyof SpatialSettings)[]
export function spatialConfig(s: Partial<SpatialSettings>): SpatialSettings {
  return Object.fromEntries(SPATIAL_KEYS.map(k => [k, s[k] ?? SPATIAL_DEFAULTS[k]])) as SpatialSettings
}
export const clamp01 = (t: number) => Math.min(1, Math.max(0, t))
const smooth = (t: number) => t * t * (3 - 2 * t)

export function axisPosition(x: number, y: number, region: Region, angle: number): number {
  return axisField(region, angle)(x, y)
}
function axisField(region: Region, angle: number): (x: number, y: number) => number {
  const rad = angle * Math.PI / 180, ux = Math.cos(rad), uy = -Math.sin(rad)
  const projections = [[region.x0, region.y0], [region.x1, region.y0], [region.x0, region.y1], [region.x1, region.y1]].map(([a, b]) => a * ux + b * uy)
  const lo = Math.min(...projections), hi = Math.max(...projections)
  const span = Math.max(1e-9, hi - lo)
  return (x, y) => clamp01((x * ux + y * uy - lo) / span)
}

// Smooth seeded value noise: identical coordinates always receive the same value,
// including when they belong to two neighbouring cells.
function noise(x: number, y: number, seed: number): number {
  const hash = (a: number, b: number) => {
    let h = Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)
    h = Math.imul(h ^ h >>> 13, 1274126177)
    return ((h ^ h >>> 16) >>> 0) / 4294967295
  }
  const a = Math.floor(x), b = Math.floor(y), u = smooth(x - a), v = smooth(y - b)
  return ((1 - u) * hash(a, b) + u * hash(a + 1, b)) * (1 - v) + ((1 - u) * hash(a, b + 1) + u * hash(a + 1, b + 1)) * v
}

export function spatialField(s: SpatialSettings, region: Region): (x: number, y: number) => number {
  const axis = axisField(region, s.spatialAngle)
  const w = region.x1 - region.x0, h = region.y1 - region.y0
  const cx = region.x0 + w * s.spatialCenterX / 100, cy = region.y0 + h * s.spatialCenterY / 100
  const radius = Math.max(1e-6, Math.max(w, h) * s.spatialRadius / 100)
  const scale = Math.max(1e-6, Math.max(w, h) * s.spatialNoiseScale / 100)
  return (x, y) => {
    let t = s.spatialMode === 'radial' ? 1 - clamp01(Math.hypot(x - cx, y - cy) / radius) : axis(x, y)
    if (s.spatialInvert) t = 1 - t
    t = clamp01((t - (s.spatialPosition / 100 - s.spatialWidth / 200)) / (s.spatialWidth / 100))
    const p = s.spatialPower
    switch (s.spatialProfile) {
      case 'easeIn': t = t ** p; break
      case 'easeOut': t = 1 - (1 - t) ** p; break
      case 'smooth': t = smooth(t) ** p; break
      case 'accent': { const a = t ** (2 * p), b = (1 - t) ** (2 * p); t = a / Math.max(1e-12, a + b); break }
      default: t = t ** p
    }
    return s.spatialNoise > 0 ? clamp01(t + (noise(x / scale, y / scale, s.spatialNoiseSeed) - 0.5) * 2 * s.spatialNoise / 100) : t
  }
}

export function spatialDensityStrength(s: SpatialSettings): number {
  const lo = Math.min(s.spatialDensityMin, s.spatialDensityMax), hi = Math.max(s.spatialDensityMin, s.spatialDensityMax)
  return 1 + (hi / Math.max(0.1, lo) - 1) * s.spatialDensityIntensity / 100
}
export function spatialDensityField(s: SpatialSettings, region: Region): (x: number, y: number) => number {
  const field = spatialField(s, region), strength = spatialDensityStrength(s)
  const axis = axisField(region, s.spatialDensityAngle)
  return (x, y) => {
    const independent = axis(x, y)
    const coupled = s.spatialCoupling === 'inverse' ? 1 - field(x, y) : field(x, y)
    const k = s.spatialCoupling === 'independent' ? 0 : s.spatialCouplingStrength / 100
    let t = independent * (1 - k) + coupled * k
    if (s.spatialDensityInvert) t = 1 - t
    return strength ** t
  }
}
