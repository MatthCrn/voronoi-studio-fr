import { useEffect, useMemo, useRef, useState } from 'react'
import { buildGeometry, type Geometry, type PatternSettings } from './voronoi/pattern'

type Request = { points: Float64Array; settings: PatternSettings }
type Completed = Request & { geometry: Geometry; error?: string }

// Only one expensive calculation is in flight. Intermediate slider values are
// replaced by the latest one, and stale results never become exportable.
export function useGeometry(points: Float64Array, settings: PatternSettings) {
  const active = (!!settings.spatialEnabled || (!!settings.organicEnabled && (settings.organicAmount ?? 100) > 0)) && settings.cellStyle === 'holes'
  const { width, height, shape, customShape, border, cellStyle, web, cornerRadius, minHole, showDelaunay } = settings
  const legacySettings = useMemo(() => ({ width, height, shape, customShape, border, cellStyle: active ? 'lines' as const : cellStyle,
    web, cornerRadius, minHole, showDelaunay }), [width, height, shape, customShape, border, cellStyle, web, cornerRadius, minHole, showDelaunay, active])
  const legacy = useMemo(() => buildGeometry(points, legacySettings), [points, legacySettings])
  const [completed, setCompleted] = useState<Completed | null>(null)
  const state = useRef<{ worker: Worker | null; sentPoints: Float64Array | null; latest: Request | null; running: Request | null; timer: number; disposed: boolean }>({
    worker: null, sentPoints: null, latest: null, running: null, timer: 0, disposed: false,
  })
  const pump = useRef<() => void>(() => {})
  useEffect(() => {
    const current = state.current
    current.disposed = false
    const finish = (geometry: Geometry, error?: string) => {
      const request = current.running
      current.running = null
      if (current.disposed) return
      // Show completed intermediate frames during dragging/auto-relax. The
      // identity check in `busy` still prevents exporting a stale frame.
      if (request) setCompleted({ ...request, geometry, error })
      if (request === current.latest) current.latest = null
      pump.current()
    }
    pump.current = () => {
      if (current.disposed || current.running || !current.latest) return
      const request = current.latest
      current.running = request
      if (current.worker) {
        current.worker.postMessage({ id: 1, points: current.sentPoints === request.points ? undefined : request.points, settings: request.settings })
        current.sentPoints = request.points
      } else {
        current.timer = window.setTimeout(() => {
          try { finish(buildGeometry(request.points, request.settings)) }
          catch (error) { finish(buildGeometry(request.points, { ...request.settings, spatialEnabled: false }), error instanceof Error ? error.message : String(error)) }
        }, 30)
      }
    }
    try {
      current.worker = new Worker(new URL('./worker/geometry.worker.ts', import.meta.url), { type: 'module' })
      current.worker.onmessage = (event: MessageEvent<{ geometry?: Geometry; error?: string }>) => {
        const request = current.running
        if (!request) return
        if (event.data.geometry) finish(event.data.geometry)
        else finish(buildGeometry(request.points, { ...request.settings, spatialEnabled: false }), event.data.error || 'Le calcul géométrique a échoué.')
      }
      current.worker.onerror = () => {
        current.worker?.terminate(); current.worker = null; current.sentPoints = null
        current.running = null; pump.current()
      }
    } catch { current.worker = null }
    return () => {
      current.disposed = true; current.worker?.terminate(); current.worker = null
      current.running = null; current.sentPoints = null; window.clearTimeout(current.timer)
    }
  }, [])
  useEffect(() => {
    const current = state.current
    current.latest = active ? { points, settings } : null
    if (!active) return
    const timer = window.setTimeout(() => pump.current(), 35)
    return () => window.clearTimeout(timer)
  }, [points, settings, active])
  return {
    geometry: active ? completed?.geometry ?? legacy : legacy,
    busy: active && (completed?.points !== points || completed?.settings !== settings),
    error: active && completed?.points === points && completed.settings === settings ? completed.error : undefined,
  }
}
