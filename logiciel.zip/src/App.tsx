import { selectionContainer } from './lib/compositionEditing'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Dock, Inspector, ViewBar } from './components/Bars'
import { FilePanel, type ExportKind } from './components/FilePanel'
import { ConfirmDialog, HelpDialog, QuickStart, type Pending } from './components/Help'
import { PatternPanel } from './components/PatternPanel'
import { SheetPanel } from './components/SheetPanel'
import { Stage, type StageControls, type Tool } from './components/Stage'
import { StylePanel } from './components/StylePanel'
import { TabPanel, Tabs } from './components/Tabs'
import { TooltipLayer } from './components/Tooltip'
import { CompositionPanel } from './components/CompositionPanel'
import { CompositionStage } from './components/CompositionStage'
import { CompositionFiles, type CompositionExport } from './components/CompositionFiles'
import { Button, Segmented } from './components/Controls'
import { findNode, layoutProblem, panelNodes, panelRects } from './lib/composition'
import { buildPanelGeometries, compositionCsv, compositionDxf, compositionPng, compositionSvg, panelArtwork, panelDxf, panelLaser } from './lib/compositionExport'
import { zipFiles } from './lib/zip'
import { cutDxf } from './lib/dxfExport'
import { desktop } from './lib/desktop'
import { EXTENSION, parseProject, ProjectError, serializeProject } from './lib/project'
import { pngProblem, renderPng } from './lib/render'
import { saveFile } from './lib/saveFile'
import { DEFAULTS, seedSettings, type Settings } from './lib/settings'
import { artworkSvg, laserSvg } from './lib/svgExport'
import { readSvgOutlines, SvgShapeError } from './lib/svgShape'
import { pixelSize, trimZeros, toUnits, UNIT_LABEL } from './lib/units'
import { freshDoc, spacingOf, useDesign, type Doc, type Status } from './useDesign'
import { integrateDensity, densityField } from './voronoi/density'
import { patternRegion } from './voronoi/pattern'
import { spatialConfig, type SpatialSettings } from './voronoi/spatial'
import { useGeometry } from './useGeometry'
import { randomSeed } from './voronoi/random'
import { contains, regionArea } from './voronoi/region'
import { shapeFromOutlines, ShapeError } from './voronoi/shape'

type TabId = 'pattern' | 'sheet' | 'style' | 'file' | 'composition'
const SESSION_KEY = 'voronoi-studio:session'
const SESSION_UNSAVED_KEY = 'voronoi-studio:session-unsaved'
const QUICK_START_KEY = 'voronoi-studio:quick-start-dismissed'

const storage = {
  get: (key: string) => { try { return localStorage.getItem(key) } catch { return null } },
  set: (key: string, value: string) => { try { localStorage.setItem(key, value) } catch { /* private mode or full: skip */ } },
}

// The last session comes back after a reload or a closed tab, so work is never lost to an accident.
function initialDesign(): { doc: Doc; saved: boolean; restored: boolean } {
  const text = storage.get(SESSION_KEY)
  if (text) {
    try {
      const design = parseProject(text)
      return { doc: { ...design, stale: false }, saved: storage.get(SESSION_UNSAVED_KEY) !== '1', restored: true }
    } catch { /* an unreadable session starts fresh */ }
  }
  return { doc: freshDoc(DEFAULTS), saved: true, restored: false }
}

// The spacing Auto spacing would use, shown in the Spacing field while it is on.
function autoSpacingFor(s: Settings): number {
  const region = patternRegion(s)
  const count = Math.max(2, s.count)
  if (s.placement === 'hex') return Math.sqrt((2 * regionArea(region)) / (Math.sqrt(3) * count))
  if (s.placement === 'square') return Math.sqrt(regionArea(region) / count)
  const mass = integrateDensity(densityField(seedSettings(s).density, region), region, (x, y) => contains(region, x, y), 32)
  return Math.sqrt((0.62 * 2 / Math.sqrt(3)) * mass / count)
}

const baseName = (s: Settings) => {
  const unit = s.units === 'px' ? 'px' : s.units === 'in' ? 'in' : 'mm'
  const v = (mm: number) => trimZeros(toUnits(mm, unit, s.dpi).toFixed(unit === 'in' ? 2 : unit === 'px' ? 0 : 1))
  return `voronoi-${v(s.width)}x${v(s.height)}${UNIT_LABEL[unit]}`
}

export function App() {
  const [first] = useState(initialDesign)
  const [status, setStatus] = useState<Status>(() => (first.restored ? { text: "Dernière session restaurée." } : null))
  // Warnings stay until something else happens; Auto-relax's step messages don't count.
  const designStatus = useCallback((next: Status) => setStatus(prev => (next?.quiet && prev?.warning ? prev : next)), [])
  const design = useDesign(() => first, designStatus)
  const { doc } = design
  const s = doc.settings
  const [tab, setTab] = useState<TabId>(s.compositionEnabled ? 'composition' : 'pattern')
  const [selectedPanels, setSelectedPanels] = useState<string[]>([])
  const selectedPanel = selectedPanels.length === 1 ? selectedPanels[0] : s.compositionTree ? selectionContainer(s.compositionTree, selectedPanels)?.id ?? null : null
  const setSelectedPanel = useCallback((id: string | null) => {
    const node = id && s.compositionTree ? findNode(s.compositionTree, id) : null
    setSelectedPanels(node ? panelNodes(node).map(p => p.id) : [])
  }, [s.compositionTree])
  const [compositionExportBusy, setCompositionExportBusy] = useState(false)
  const compositionNotice = useCallback((text: string) => setStatus({ text }), [])
  useEffect(() => {
    if (s.compositionEnabled && tab === 'pattern') setTab('composition')
    if (!s.compositionEnabled && tab === 'composition') setTab('pattern')
  }, [s.compositionEnabled, tab])
  useEffect(() => {
    const valid = new Set(s.compositionTree ? panelNodes(s.compositionTree).map(p => p.id) : [])
    setSelectedPanels(previous => previous.every(id => valid.has(id)) ? previous : previous.filter(id => valid.has(id)))
  }, [s.compositionTree])
  const [tool, setTool] = useState<Tool>('move')
  const [zoom, setZoom] = useState(1)
  const [showHelp, setShowHelp] = useState(false)
  const [showQuickStart, setShowQuickStart] = useState(() => storage.get(QUICK_START_KEY) !== '1')
  const [pending, setPending] = useState<Pending | null>(null)
  const [openError, setOpenError] = useState('')
  const frameRef = useRef<HTMLDivElement>(null)
  const stageRef = useRef<StageControls | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const shapeInput = useRef<HTMLInputElement>(null)

  // Routine messages fade back to the cell count; warnings stay until something else happens.
  useEffect(() => {
    if (!status || status.warning) return
    const timer = window.setTimeout(() => setStatus(null), 5000)
    return () => window.clearTimeout(timer)
  }, [status])

  // Geometry depends on a few settings only, so colour and visibility changes don't rebuild it.
  const { width, height, shape, customShape, border, cellStyle, web, cornerRadius, minHole, showDelaunay, organicEnabled, organicAmount } = s
  const spatialKey = JSON.stringify(spatialConfig(s))
  const spatialValues = useMemo(() => JSON.parse(spatialKey) as SpatialSettings, [spatialKey])
  const compositionEnabled = s.compositionEnabled
  const patternSettings = useMemo(() => ({ width, height, shape, customShape, border: compositionEnabled ? 0 : border, cellStyle, web, cornerRadius, minHole, showDelaunay, organicEnabled, organicAmount, ...spatialValues }),
    [width, height, shape, customShape, border, cellStyle, web, cornerRadius, minHole, showDelaunay, organicEnabled, organicAmount, spatialValues, compositionEnabled])
  const { geometry, busy: geometryBusy, error: geometryError } = useGeometry(doc.points, patternSettings)
  const compositionProblem = s.compositionEnabled ? layoutProblem(s.compositionTree, s.width, s.height, s.compositionJeu, s.compositionMin) : null
  const compositionPanels = useMemo(() => s.compositionEnabled && !compositionProblem ? buildPanelGeometries(geometry, s) : [], [geometry, s, compositionProblem])
  const compositionArtwork = useMemo(() => new Map(compositionPanels.filter(p => p.panel.node.pattern).map(p => [p.panel.node.id, panelArtwork(p)])), [compositionPanels])
  const exactSpacing = useCallback(() => spacingOf(s), [s])
  const count = doc.points.length / 2

  // Keep a copy of the session, a moment after the last change.
  useEffect(() => {
    const timer = window.setTimeout(() => {
      storage.set(SESSION_KEY, serializeProject(doc))
      storage.set(SESSION_UNSAVED_KEY, design.unsaved ? '1' : '0')
    }, 600)
    return () => window.clearTimeout(timer)
  }, [doc, design.unsaved])

  // The updater waits for this immediate checkpoint, rather than relying on
  // the normal 600 ms autosave debounce. Failed writes cancel the restart.
  useEffect(() => desktop()?.onBeforeUpdate?.(() => {
    design.stopAuto()
    const project = serializeProject(doc)
    localStorage.setItem(SESSION_KEY, project)
    localStorage.setItem(SESSION_UNSAVED_KEY, design.unsaved ? '1' : '0')
    return { project, unsaved: design.unsaved }
  }), [doc, design.unsaved, design.stopAuto])

  // Asks before discarding unsaved work, in an in-app dialog (embedded browsers can block confirm()).
  const guard = useCallback((when: boolean, p: Pending) => { if (when) setPending(p); else p.run() }, [])

  const generateNew = useCallback(() => guard(doc.handEdited, {
    title: "Remplacer vos points retouchés ?", confirm: "Générer un nouveau motif",
    body: "Un nouveau motif remplace les points déplacés, ajoutés ou effacés. Annuler permet de les retrouver.",
    run: () => design.generate(randomSeed()),
  }), [guard, doc.handEdited, design])

  const applySettings = () => guard(true, {
    title: "Appliquer les nouveaux réglages ?", confirm: "Appliquer les réglages",
    body: "Vos points retouchés seront remplacés par un nouveau motif issu des réglages actuels. Annuler permet de les retrouver.",
    run: () => design.generate(),
  })

  const newDesign = () => guard(design.unsaved, {
    title: "Créer un nouveau dessin ?", confirm: "Abandonner et créer",
    body: "Les modifications non enregistrées du dessin seront perdues. Annuler permet encore de les retrouver pendant cette session.",
    run: () => { design.replace(freshDoc({ ...DEFAULTS, seed: randomSeed() }), true); setStatus({ text: "Nouveau dessin." }) },
  })

  const openProject = () => guard(design.unsaved, {
    title: "Ouvrir un autre projet ?", confirm: "Abandonner et ouvrir",
    body: "Les modifications non enregistrées du dessin seront perdues. Annuler permet encore de les retrouver pendant cette session.",
    run: () => fileInput.current?.click(),
  })

  const readProject = async (file: File) => {
    try {
      const opened = parseProject(await file.text())
      design.replace({ ...opened, stale: false }, true)
      setOpenError('')
      setStatus({ text: `${file.name} ouvert.` })
    } catch (error) {
      // The current design stays as it was.
      setOpenError(error instanceof ProjectError ? error.message : `Impossible de lire ${file.name}.`)
      setTab('file')
    }
  }

  // An SVG outline becomes the sheet. A new shape means a new pattern, so hand edits are confirmed first.
  const replaceEdits = (run: () => void) => guard(doc.handEdited, {
    title: "Remplacer vos points retouchés ?", confirm: "Utiliser la nouvelle forme",
    body: "Une nouvelle forme de support crée un nouveau motif qui remplace les points retouchés. Annuler permet de les retrouver.",
    run,
  })
  const importShape = () => replaceEdits(() => shapeInput.current?.click())

  const readShape = async (file: File) => {
    try {
      const outlines = readSvgOutlines(await file.text())
      const shape = shapeFromOutlines(outlines.rings, file.name, outlines.units)
      const edited = design.doc.handEdited
      design.change({ shape: 'custom', customShape: shape, width: shape.width, height: shape.height }, 'customShape')
      if (edited) design.generate() // already confirmed: start fresh in the new shape
      setTab('sheet')
      const skipped = outlines.open ? ` ${outlines.open} ${outlines.open === 1 ? 'ligne ouverte ignorée' : 'lignes ouvertes ignorées'}.` : ''
      const using = outlines.fromClip ? `${file.name} est une image : le contour de son masque d’écrêtage sert de support.` : `${file.name} utilisé comme support.`
      setStatus({ text: `${using}${skipped}`, warning: Boolean(outlines.open) || outlines.fromClip })
    } catch (error) {
      const known = error instanceof SvgShapeError || error instanceof ShapeError
      setStatus({ text: known ? error.message : `Impossible de lire ${file.name} comme forme.`, warning: true })
    }
  }

  // Files dropped on the window: SVGs become the sheet shape, project files open.
  useEffect(() => {
    const over = (event: DragEvent) => { if (event.dataTransfer?.types.includes('Files')) event.preventDefault() }
    const drop = (event: DragEvent) => {
      const file = event.dataTransfer?.files[0]
      if (!file) return
      event.preventDefault()
      if (/\.svg$/i.test(file.name) || file.type === 'image/svg+xml') replaceEdits(() => void readShape(file))
      else if (/\.json$/i.test(file.name)) guard(design.unsaved, {
        title: "Ouvrir un autre projet ?", confirm: "Abandonner et ouvrir",
        body: "Les modifications non enregistrées du dessin seront perdues. Annuler permet encore de les retrouver pendant cette session.",
        run: () => void readProject(file),
      })
      else setStatus({ text: `${file.name} n’est ni une forme SVG ni un projet Voronoi Studio.`, warning: true })
    }
    window.addEventListener('dragover', over)
    window.addEventListener('drop', drop)
    return () => { window.removeEventListener('dragover', over); window.removeEventListener('drop', drop) }
  })

  const report = (name: string, result: Awaited<ReturnType<typeof saveFile>>) => {
    if (result === 'saved' || result === 'downloaded') setStatus({ text: `${result === 'saved' ? "Enregistré" : "Téléchargé"} ${name}.` })
    else if (result === 'failed') setStatus({ text: `Impossible d’enregistrer ${name}.`, warning: true })
    return result === 'saved' || result === 'downloaded'
  }

  const saveProject = async () => {
    const snapshot = doc
    const name = `${baseName(s)}${EXTENSION}`
    if (report(name, await saveFile(name, serializeProject(snapshot), 'application/json', "Projet Voronoi Studio"))) design.markSaved(snapshot)
  }

  const exportFile = async (kind: ExportKind) => {
    if (geometryBusy || geometryError) { setStatus({ text: geometryError || 'Attendez la fin du calcul des contours.', warning: true }); return }
    const base = baseName(s)
    if (kind === 'svg') report(`${base}.svg`, await saveFile(`${base}.svg`, artworkSvg(geometry, doc.points, s), 'image/svg+xml', "Image SVG"))
    if (kind === 'laser') report(`${base}-cut.svg`, await saveFile(`${base}-cut.svg`, laserSvg(geometry, doc.points, s), 'image/svg+xml', "Fichier de découpe SVG"))
    if (kind === 'dxf') report(`${base}.dxf`, await saveFile(`${base}.dxf`, cutDxf(geometry, doc.points, s), 'application/dxf', "Dessin DXF"))
    if (kind === 'png') {
      const [w, h] = pixelSize(s.width, s.height, s.dpi)
      const problem = pngProblem(w, h)
      if (problem) { setStatus({ text: problem, warning: true }); return }
      setStatus({ text: `Création d’un PNG de ${w.toLocaleString('fr-FR')} × ${h.toLocaleString('fr-FR')} px…` })
      const blob = await renderPng(geometry, doc.points, s, w, h)
      if (!blob) { setStatus({ text: "Le navigateur ne peut pas créer un PNG aussi grand. Réduisez la résolution en pixels par pouce.", warning: true }); return }
      report(`${base}.png`, await saveFile(`${base}.png`, blob, 'image/png', "Image PNG"))
    }
  }

  const exportComposition = async (kind: CompositionExport) => {
    if (geometryBusy || geometryError || compositionProblem || compositionExportBusy || !compositionPanels.length) { setStatus({ text: compositionProblem || geometryError || (!compositionPanels.length ? 'Aucun panneau à exporter.' : '') || 'Attendez la fin du calcul de la composition.', warning: true }); return }
    const panels = compositionPanels, settings = s, snapshot = doc
    const selected = panels.find(p => p.panel.node.id === selectedPanel)
    const base = `composition-${trimZeros(s.width.toFixed(2))}x${trimZeros(s.height.toFixed(2))}mm`
    setCompositionExportBusy(true)
    try {
      if (kind === 'plan-svg') report(`${base}-plan.svg`, await saveFile(`${base}-plan.svg`, compositionSvg(panels, settings), 'image/svg+xml', 'Plan de composition'))
      if (kind === 'plan-dxf') report(`${base}-plan.dxf`, await saveFile(`${base}-plan.dxf`, compositionDxf(panels), 'application/dxf', 'Plan DXF'))
      if (kind === 'csv') report(`${base}-dimensions.csv`, await saveFile(`${base}-dimensions.csv`, compositionCsv(panels, settings), 'text/csv', 'Dimensions des panneaux'))
      if (kind === 'panel-svg' && selected) report(`${selected.panel.node.id}-laser.svg`, await saveFile(`${selected.panel.node.id}-laser.svg`, panelLaser(selected), 'image/svg+xml', 'Panneau SVG laser'))
      if (kind === 'panel-dxf' && selected) report(`${selected.panel.node.id}.dxf`, await saveFile(`${selected.panel.node.id}.dxf`, panelDxf(selected), 'application/dxf', 'Panneau DXF'))
      if (kind === 'png') {
        const [w, h] = pixelSize(settings.width, settings.height, settings.dpi), problem = pngProblem(w, h)
        if (problem) { setStatus({ text: problem, warning: true }); return }
        const blob = await compositionPng(compositionSvg(panels, settings), w, h)
        if (!blob) throw Error('Impossible de créer le PNG. Réduisez la résolution dans Support.')
        report(`${base}.png`, await saveFile(`${base}.png`, blob, 'image/png', 'Image de composition'))
      }
      if (kind === 'zip') {
        setStatus({ text: 'Préparation des panneaux et du plan…' })
        const files = [
          { name: 'plan.svg', text: compositionSvg(panels, settings) }, { name: 'plan.dxf', text: compositionDxf(panels) },
          { name: 'dimensions.csv', text: compositionCsv(panels, settings) }, { name: `composition${EXTENSION}`, text: serializeProject(snapshot) },
        ]
        for (const p of panels) {
          files.push({ name: `panneaux/${p.panel.node.id}-laser.svg`, text: panelLaser(p) }, { name: `panneaux/${p.panel.node.id}.dxf`, text: panelDxf(p) })
        }
        if (files.reduce((sum, file) => sum + file.text.length, 0) > 128 * 1024 * 1024) throw Error('Archive trop volumineuse. Réduisez le nombre de cellules ou exportez les panneaux séparément.')
        report(`${base}.zip`, await saveFile(`${base}.zip`, zipFiles(files), 'application/zip', 'Panneaux et plan'))
      }
    } catch (error) { setStatus({ text: error instanceof Error ? error.message : 'Export de composition impossible.', warning: true }) }
    finally { setCompositionExportBusy(false) }
  }

  const relaxBlocked = count < 3 && "La relaxation nécessite au moins 3 points."
  const toggle = (key: 'showSites' | 'showEdges' | 'showDelaunay') => design.change({ [key]: !s[key] }, key)
  const closeQuickStart = () => { setShowQuickStart(false); storage.set(QUICK_START_KEY, '1') }

  // Keyboard shortcuts, ignored while typing. Re-registered each render so handlers see current state.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target instanceof Element ? event.target : null
      const typing = Boolean(target?.closest('input, select, textarea'))
      const mod = event.metaKey || event.ctrlKey
      const key = event.key.toLowerCase()
      if (event.key === 'Escape') { setShowHelp(false); setPending(null); if (!typing) setTool('move'); return }
      if (pending || showHelp) return
      if (mod && key === 's') { event.preventDefault(); void saveProject(); return }
      if (mod && key === 'o') { event.preventDefault(); openProject(); return }
      if (typing) return
      if (mod && key === 'z') { event.preventDefault(); if (event.shiftKey) design.redo(); else design.undo(); return }
      if (mod && key === 'y') { event.preventDefault(); design.redo(); return }
      if (mod || event.altKey) return
      if (s.compositionEnabled) {
        if (key === 'f' || key === '0') stageRef.current?.fit()
        else if (key === '+' || key === '=') stageRef.current?.zoomBy(1.25)
        else if (key === '-' || key === '_') stageRef.current?.zoomBy(1 / 1.25)
        return
      }
      if (key === 'g') generateNew()
      else if (key === 'r') { if (!relaxBlocked) design.relaxOnce() }
      else if (key === 'p') { if (!relaxBlocked) design.toggleAuto() }
      else if (key === 'v') setTool('move')
      else if (key === 'a') setTool('add')
      else if (key === 'e') setTool('erase')
      else if (key === 'h') setTool('pan')
      else if (key === '1') toggle('showSites')
      else if (key === '2') toggle('showEdges')
      else if (key === '3') toggle('showDelaunay')
      else if (key === 'f' || key === '0') stageRef.current?.fit()
      else if (key === '+' || key === '=') stageRef.current?.zoomBy(1.25)
      else if (key === '-' || key === '_') stageRef.current?.zoomBy(1 / 1.25)
      else if (event.key === '?') setShowHelp(true)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  // At 1280 px the status line holds about 220 px, so it keeps to the count and one or two short notes. While
  // Auto-relax runs the seed no longer describes the points, and the panel notes held-back settings.
  const notes = design.auto ? ["Relaxation auto activée"] : [`graine ${s.seed}`, doc.handEdited ? "retouché" : '']
  const statusText = geometryBusy ? 'Mise à jour des contours…' : geometryError ? `Calcul impossible : ${geometryError}` : status?.text ?? (design.busy ? "Mise à jour du motif…"
    : [`${count.toLocaleString('fr-FR')} cellules`, ...notes].filter(Boolean).join(' · '))

  return <main className="studio">
    <TooltipLayer />
    <div className="stage">
      {s.compositionEnabled ? <CompositionStage s={s} frameRef={frameRef} controlRef={stageRef} selected={selectedPanel} selection={selectedPanels} setSelection={setSelectedPanels} select={setSelectedPanel} change={design.change} onZoom={setZoom} notice={compositionNotice} artwork={compositionArtwork} /> : <Stage geometry={geometry} points={doc.points} settings={s} tool={tool} frameRef={frameRef} controlRef={stageRef}
        onBeginEdit={() => { design.beginEdit(); setStatus(null) }} onPoints={design.editPoints} onRelease={design.releasePoint} onZoom={setZoom}
        onNotice={text => setStatus({ text })} />}
    </div>

    <header className="brand glass">
      <div><p className="app-kicker">{s.compositionEnabled ? 'Composer des panneaux pour fabriquer' : 'Des motifs de Voronoi pour fabriquer'}</p><h1>Voronoi Studio</h1></div>
      <button type="button" className="icon-button" aria-label="Raccourcis clavier et aide" data-tip="Raccourcis clavier et prise en main." data-key="?" onClick={() => setShowHelp(true)}>?</button>
    </header>

    <aside className="sidebar side-panel glass" aria-label="Réglages du dessin">
      <div className="composition-mode"><Segmented label="Mode de travail" hideLabel value={s.compositionEnabled ? 'composition' : 'motif'} options={[
        { value: 'motif', label: 'Motif', tip: 'Créer et retoucher un motif de Voronoi.' },
        { value: 'composition', label: 'Composition', tip: 'Répartir plusieurs panneaux dans un format global rectangulaire et les manipuler à la souris.' },
      ]} onChange={mode => { design.stopAuto(); design.change({ compositionEnabled: mode === 'composition', ...(mode === 'composition' ? { shape: 'rect' as const } : {}) }, 'compositionMode'); setTab(mode === 'composition' ? 'composition' : 'pattern') }} /></div>
      <Tabs label="Réglages du dessin" idBase="design" value={tab} onChange={setTab} tabs={s.compositionEnabled ? [
        { id: 'composition', label: 'Panneaux', title: 'Proposer et ajuster des compositions de panneaux.' },
        { id: 'sheet', label: 'Support', title: 'Format global et proportions.' },
        { id: 'style', label: 'Habillage', title: 'Motif et style des panneaux ajourés.' },
        { id: 'file', label: 'Fichier', title: 'Projet, plan et fichiers de panneaux.', badge: design.unsaved ? 'modifications non enregistrées' : undefined },
      ] : [
        { id: 'pattern', label: "Motif", title: "Nombre de cellules, répartition des points, gradients et relaxation.", badge: doc.stale ? "réglages non appliqués" : undefined },
        { id: 'sheet', label: "Support", title: "Dimensions, forme, unités et bordure du support." },
        { id: 'style', label: 'Style', title: "Lignes ou ajours, largeur de matière, arrondis et couleurs." },
        { id: 'file', label: "Fichier", title: "Enregistrer ou ouvrir un projet ; exporter en SVG laser, DXF, SVG ou PNG.", badge: design.unsaved ? "modifications non enregistrées" : undefined },
      ]} />
      <TabPanel idBase="design" id="composition" value={tab}><CompositionPanel s={s} change={design.change} selected={selectedPanel} selection={selectedPanels} setSelection={setSelectedPanels} select={setSelectedPanel} notice={compositionNotice} /></TabPanel>
      <TabPanel idBase="design" id="pattern" value={tab}>
        <PatternPanel s={s} change={design.change} stale={doc.stale} onApply={applySettings} actualCount={count}
          autoSpacingValue={design.spacing || autoSpacingFor(s)} exactSpacing={exactSpacing} capped={design.capped} onShuffle={generateNew} spatialMetrics={geometry.metrics.spatial} />
      </TabPanel>
      <TabPanel idBase="design" id="sheet" value={tab}><SheetPanel s={s} change={design.change} onImportShape={importShape} /></TabPanel>
      <TabPanel idBase="design" id="style" value={tab}><StylePanel s={s} change={design.change} holes={geometry.metrics.holes} dropped={geometry.metrics.dropped} />
        {s.compositionEnabled && <details className="more"><summary>Réglages du motif global</summary><PatternPanel s={s} change={design.change} stale={doc.stale} onApply={applySettings} actualCount={count} autoSpacingValue={design.spacing || autoSpacingFor(s)} exactSpacing={exactSpacing} capped={design.capped} onShuffle={generateNew} spatialMetrics={geometry.metrics.spatial} /></details>}
      </TabPanel>
      <TabPanel idBase="design" id="file" value={tab}>
        <FilePanel s={s} change={design.change} unsaved={design.unsaved} busy={design.busy || geometryBusy || !!geometryError} openError={openError}
          onNew={newDesign} onOpen={openProject} onSave={() => void saveProject()} onExport={kind => void exportFile(kind)}
          exportSection={s.compositionEnabled ? <CompositionFiles selectedPanel={compositionPanels.find(p => p.panel.node.id === selectedPanel)?.panel.node.id ?? null} blocked={compositionProblem || geometryError || (!compositionPanels.length && 'Aucun panneau à exporter.') || ((geometryBusy || compositionExportBusy) && 'Calcul ou export en cours…')} exportFile={kind => void exportComposition(kind)} /> : undefined} />
      </TabPanel>
      <input ref={fileInput} type="file" accept=".json,application/json" hidden aria-label="Choisir un fichier de projet" onChange={event => {
        const file = event.currentTarget.files?.[0]
        event.currentTarget.value = ''
        if (file) void readProject(file)
      }} />
      <input ref={shapeInput} type="file" accept=".svg,image/svg+xml" hidden aria-label="Choisir une forme SVG" onChange={event => {
        const file = event.currentTarget.files?.[0]
        event.currentTarget.value = ''
        if (file) void readShape(file)
      }} />
    </aside>

    <div className="center">
      {s.compositionEnabled ? <div className="viewport-bars"><div className="floating-bar glass" role="toolbar" aria-label="Vue de composition">
        <Button tip="Réduire le zoom." label="Zoom arrière" onClick={() => stageRef.current?.zoomBy(1 / 1.25)}>−</Button>
        <Button tip="Ajuster le format global à la fenêtre." onClick={() => stageRef.current?.fit()}>{Math.round(zoom * 100)} %</Button>
        <Button tip="Augmenter le zoom." label="Zoom avant" onClick={() => stageRef.current?.zoomBy(1.25)}>+</Button>
        <span className="bar-divider" /><span className="composition-toolbar-caption">Glisser les panneaux et les séparations</span>
      </div><p className="view-caption">Ctrl + clic : sélection multiple · Maj + clic : groupe · Alt : sans accrochage · Échap : annuler le déplacement · Fond : déplacer la vue</p></div> : <ViewBar tool={tool} setTool={setTool} s={s} toggle={toggle} zoom={zoom} onFit={() => stageRef.current?.fit()} onZoom={f => stageRef.current?.zoomBy(f)} />}
      <div className="sheet-frame" ref={frameRef}>
        {showQuickStart && !s.compositionEnabled && <QuickStart onClose={closeQuickStart} />}
      </div>
      {s.compositionEnabled ? <div className="dock"><div className="timeline glass"><span className="timeline-status" role="status" data-warning={!!compositionProblem}>{compositionProblem || status?.text || `${compositionPanels.length} panneaux · jeu ${s.compositionJeu.toLocaleString('fr-FR')} mm`}</span><div className="transport">
        <Button label="Annuler" tip="Annuler la dernière modification de composition." unavailable={!design.canUndo && 'Aucune action à annuler.'} onClick={design.undo}>↶</Button>
        <Button label="Rétablir" tip="Rétablir la dernière modification annulée." unavailable={!design.canRedo && 'Aucune action à rétablir.'} onClick={design.redo}>↷</Button>
      </div></div></div> : <Dock relaxSteps={s.relaxSteps} auto={design.auto} busy={design.busy || geometryBusy} canRelax={relaxBlocked}
        onGenerate={generateNew} onRelax={design.relaxOnce} onAuto={design.toggleAuto}
        status={statusText} warning={Boolean(status?.warning)}
        canUndo={design.canUndo} canRedo={design.canRedo} onUndo={design.undo} onRedo={design.redo} />}
    </div>

    <aside className="inspector side-panel glass" aria-label="Mesures">
      {s.compositionEnabled ? <section className="measurements"><h2>Composition</h2><p>{s.width.toLocaleString('fr-FR', { maximumFractionDigits: 2 })} × {s.height.toLocaleString('fr-FR', { maximumFractionDigits: 2 })} mm</p><p>{compositionPanels.length} panneaux · Jeu : {s.compositionJeu.toLocaleString('fr-FR')} mm</p>
        <div className="composition-panel-list">{s.compositionTree && panelRects(s.compositionTree, s.width, s.height, s.compositionJeu).map(p => <button key={p.node.id} aria-pressed={selectedPanels.includes(p.node.id)} onClick={() => { setSelectedPanel(p.node.id); setTab('composition') }}><b>{p.node.id}{p.node.locked ? ' 🔒' : ''}</b><span>{p.width.toLocaleString('fr-FR', { maximumFractionDigits: 1 })} × {p.height.toLocaleString('fr-FR', { maximumFractionDigits: 1 })} mm</span></button>)}</div>
        <p className="hint">Sélectionnez un panneau ou un groupe pour modifier ses dimensions, son verrouillage et son habillage.</p>
      </section> : <Inspector m={geometry.metrics} s={s} count={count} />}
    </aside>

    {pending && <ConfirmDialog pending={pending} onCancel={() => setPending(null)} />}
    {showHelp && <HelpDialog onClose={() => setShowHelp(false)} onQuickStart={() => { setShowHelp(false); setShowQuickStart(true) }} />}
  </main>
}
