import { SelectionActions } from './SelectionActions'
import { sameIds, updateSelection } from '../lib/compositionEditing'
import { useState } from 'react'
import { Button, ColorField, LengthField, NumberField, Section, SwitchField } from './Controls'
import type { Change } from './PatternPanel'
import type { Settings } from '../lib/settings'
import { findNode, hasLocked, layoutProblem, panelNodes, panelRects, parentOf, placeLayout, proposal, resizeElement, type LayoutNode } from '../lib/composition'
import { goldenLabel, GOLDEN_RECTANGLES } from '../lib/goldenRectangles'
import { formatLength } from '../lib/units'

export function CompositionPanel({ s, change, selected, selection, setSelection, select, notice }: { s: Settings; change: Change; selected: string | null; selection: string[]; setSelection: (ids: string[]) => void; select: (id: string | null) => void; notice: (text: string) => void }) {
  const [choices, setChoices] = useState<LayoutNode[]>([])
  const tree = s.compositionTree
  const placed = tree ? placeLayout(tree, s.width, s.height, s.compositionJeu) : []
  const item = placed.find(p => p.node.id === selected)
  const problem = layoutProblem(tree, s.width, s.height, s.compositionJeu, s.compositionMin)
  const locked = hasLocked(tree)
  const sizeFixed = (axis: 'x' | 'y') => {
    let parent = tree && item ? parentOf(tree, item.node.id) : null
    while (parent && parent.axis !== axis) parent = parentOf(tree!, parent.id)
    return !parent && 'Dimension fixée par le format global.'
  }
  const length = { units: s.units, dpi: s.dpi, small: true }
  const propose = () => {
    if (tree && panelNodes(tree).length > 0 && panelNodes(tree).every(p => p.locked)) { notice('Déverrouillez au moins un panneau pour obtenir de nouvelles propositions.'); return }
    const results: LayoutNode[] = [], signatures = new Set<string>()
    const signature = (n: LayoutNode): string => n.kind === 'panel' ? 'p' : `${n.axis}${n.ratio.toFixed(5)}(${signature(n.a)},${signature(n.b)})`
    const seed = (s.compositionSeed + 1) % 999999
    for (let i = 0; i < 12 && results.length < 3; i++) {
      const candidate = proposal(tree, s.compositionCount, s.width, s.height, s.compositionJeu, s.compositionMin, seed + i * 7919)
      if (candidate && !signatures.has(signature(candidate))) { signatures.add(signature(candidate)); results.push(candidate) }
    }
    setChoices(results)
    change({ compositionSeed: seed }, 'compositionSeed')
    notice(results.length ? 'Choisissez une proposition, puis ajustez-la directement à la souris.' : 'Aucune proposition réalisable avec ce format, ce jeu, ces verrouillages et cette dimension minimale.')
  }
  const patchSelected = (patch: { locked?: boolean; pattern?: boolean }) => {
    if (!tree || !selection.length) return
    change({ compositionTree: updateSelection(tree, selection, patch) }, 'compositionSelection')
  }
  return <>
    <Section title="Composition">
      <SwitchField label="Afficher le motif" checked={s.compositionShowPattern} tip="Montrer ou masquer le motif sur les panneaux dans la vue. Les exports conservent le motif appliqué à chaque panneau." onChange={compositionShowPattern => change({ compositionShowPattern }, 'compositionShowPattern')} />
      {tree && panelNodes(tree).some(p => !p.pattern) && <Button tip="Appliquer le motif global à tous les panneaux. La visibilité peut ensuite être désactivée sans modifier les exports." onClick={() => {
        const all = (n: LayoutNode): LayoutNode => n.kind === 'panel' ? n.empty ? n : { ...n, pattern: true } : { ...n, a: all(n.a), b: all(n.b) }
        change({ compositionTree: all(tree), compositionShowPattern: true }, 'patternAll')
      }}>Appliquer le motif à tous les panneaux</Button>}
      <NumberField label="Panneaux à proposer" value={s.compositionCount} min={1} max={24} tip="Nombre de panneaux souhaité pour les prochaines propositions."
        unavailable={locked && 'Déverrouillez les panneaux avant de changer leur nombre.'} onChange={v => { setChoices([]); change({ compositionCount: Math.round(v) }, 'compositionCount') }} />
      <LengthField label="Jeu" mm={s.compositionJeu} min={0} max={200} {...length} unavailable={locked && 'Déverrouillez les panneaux pour modifier le jeu.'}
        tip="Espacement réel entre les panneaux. Le jeu est inclus dans le format global ; aucun jeu périphérique n’est ajouté."
        onChange={compositionJeu => { setChoices([]); change({ compositionJeu }, 'compositionJeu') }} />
      <Button className="primary wide" tip="Chercher plusieurs répartitions, guidées par les proportions d’or. Les panneaux verrouillés restent en place." onClick={propose}>Proposer des compositions</Button>
      <details className="more"><summary>Couleurs des lignes</summary>
        <ColorField label="Contours des panneaux" value={s.panelContourColor} tip="Couleur des contours fermés des panneaux, dans l’aperçu, le SVG et le DXF." onChange={panelContourColor => change({ panelContourColor }, 'panelContourColor')} />
        <ColorField label="Lignes intérieures" value={s.lineColor} tip="Couleur des arêtes et des ajours sur les panneaux habillés." onChange={lineColor => change({ lineColor }, 'lineColor')} />
        <p className="hint">Le DXF utilise les couleurs normalisées les plus proches, en gardant deux couleurs distinctes. Les contours et les tracés intérieurs restent sur des calques séparés.</p>
      </details>
      {!!choices.length && <div className="composition-choices">{choices.map((candidate, i) => <button type="button" key={i} aria-label={`Appliquer la proposition ${i + 1}`}
        onClick={() => {
          const metadata = new Map(tree ? panelNodes(tree).map(p => [p.id, p]) : [])
          const hydrate = (n: LayoutNode): LayoutNode => n.kind === 'panel' ? { ...n, locked: metadata.get(n.id)?.locked ?? n.locked, pattern: metadata.get(n.id)?.pattern ?? n.pattern } : { ...n, a: hydrate(n.a), b: hydrate(n.b) }
          const currentCandidate = hydrate(candidate)
          // Reject stale thumbnails if the format or locks changed meanwhile.
          const currentLocks = tree ? panelRects(tree, s.width, s.height, s.compositionJeu).filter(p => p.node.locked) : []
          const candidates = panelRects(currentCandidate, s.width, s.height, s.compositionJeu)
          if (layoutProblem(currentCandidate, s.width, s.height, s.compositionJeu, s.compositionMin) || currentLocks.some(p => !candidates.some(q => q.node.id === p.node.id && q.node.locked && ['x', 'y', 'width', 'height'].every(k => Math.abs(p[k as 'x'] - q[k as 'x']) < 1e-6)))) { notice('Les réglages ont changé. Demandez de nouvelles propositions.'); setChoices([]); return }
          change({ compositionTree: currentCandidate }, `compositionProposal:${s.compositionSeed}:${i}`); select(null)
        }}>
        <svg viewBox={`0 0 ${s.width} ${s.height}`} aria-hidden="true">{panelRects(candidate, s.width, s.height, s.compositionJeu).map(p => <rect key={p.node.id} x={p.x} y={p.y} width={p.width} height={p.height} fill={p.node.locked ? '#bac9da' : '#f8fbff'} stroke="#627a94" strokeWidth={s.width / 180} />)}</svg>
        <span>Proposition {i + 1}</span>
      </button>)}</div>}
      {problem && <p className="hint error" role="alert">{problem}</p>}
      <p className="hint">Ctrl + clic : ajouter ou retirer des panneaux. Maj + clic : sélectionner un groupe. Double-clic : panneau individuel. Clic droit : grouper, fusionner, supprimer ou diviser.</p>
    </Section>
    {tree && selection.length > 0 && <Section title={s.compositionGroups.some(g => sameIds(g, selection)) ? `Groupe · ${selection.length} panneaux` : `Sélection · ${selection.length} panneau${selection.length > 1 ? 'x' : ''}`}><SelectionActions s={s} ids={selection} change={change} setSelection={setSelection} /><SwitchField label="Verrouiller la sélection" checked={panelNodes(tree).filter(p => selection.includes(p.id)).every(p => p.locked)} tip="Conserver les positions et dimensions de tous les panneaux sélectionnés." onChange={locked => patchSelected({ locked })} /><SwitchField label="Appliquer le motif Voronoi" checked={panelNodes(tree).filter(p => selection.includes(p.id)).every(p => p.pattern)} tip="Appliquer le motif continu à tous les panneaux sélectionnés." onChange={pattern => patchSelected({ pattern })} /></Section>}
    {item && <Section title={item.node.kind === 'panel' ? item.node.id : 'Dimensions de la sélection'}>
      <LengthField label="Largeur de la sélection" mm={item.width} min={s.compositionMin} max={s.width} {...length}
        unavailable={hasLocked(item.node) ? 'La sélection contient un panneau verrouillé.' : sizeFixed('x')}
        tip="Ajuster une séparation pour donner cette largeur à la sélection. Les éléments voisins s’adaptent."
        onChange={value => { const result = resizeElement(tree!, item.node.id, 'x', value, s.width, s.height, s.compositionJeu, s.compositionMin); if (result) change({ compositionTree: result }, `resize:${item.node.id}:x`); else notice('Cette largeur est incompatible avec les limites ou les panneaux verrouillés.') }} />
      <LengthField label="Hauteur de la sélection" mm={item.height} min={s.compositionMin} max={s.height} {...length}
        unavailable={hasLocked(item.node) ? 'La sélection contient un panneau verrouillé.' : sizeFixed('y')}
        tip="Ajuster une séparation pour donner cette hauteur à la sélection."
        onChange={value => { const result = resizeElement(tree!, item.node.id, 'y', value, s.width, s.height, s.compositionJeu, s.compositionMin); if (result) change({ compositionTree: result }, `resize:${item.node.id}:y`); else notice('Cette hauteur est incompatible avec les limites ou les panneaux verrouillés.') }} />
      {parentOf(tree!, item.node.id) && <Button tip="Sélectionner l’ensemble de panneaux contenant cette sélection pour le déplacer en groupe." onClick={() => select(parentOf(tree!, item.node.id)!.id)}>Sélectionner le groupe</Button>}
      <p className="hint">Position : {formatLength(item.x, s.units, s.dpi)} ; {formatLength(item.y, s.units, s.dpi)}.
        {' '}Proportion : {goldenLabel(Math.max(item.width, item.height) / Math.min(item.width, item.height))}.
        {(() => { const ratio = Math.max(item.width, item.height) / Math.min(item.width, item.height); const near = GOLDEN_RECTANGLES.find(r => Math.abs(r.ratio - ratio) / r.ratio < .003); return near ? ` Proche du rectangle ${near.id}.` : '' })()}</p>
    </Section>}
    <details className="more"><summary>Réglages de composition</summary>
      <LengthField label="Dimension minimale des panneaux" mm={s.compositionMin} min={1} max={500} {...length} tip="Minimum autorisé pour chaque côté. Les propositions et manipulations doivent le respecter." onChange={compositionMin => { setChoices([]); change({ compositionMin }, 'compositionMin') }} />
      <SwitchField label="Accrochage aux proportions d’or" checked={s.compositionSnap} tip="Les séparations s’aimantent aux proportions des quinze rectangles et à la moitié. Alt permet de s’en affranchir pendant le glissement." onChange={compositionSnap => change({ compositionSnap }, 'compositionSnap')} />
    </details>
  </>
}
