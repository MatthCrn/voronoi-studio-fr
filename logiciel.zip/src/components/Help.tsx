import { Modal } from './Modal'

// The quick start card and the ? dialog with every shortcut.

export function QuickStart({ onClose }: { onClose: () => void }) {
  return <section className="quick-start glass" aria-labelledby="quick-start-title">
    <h2 id="quick-start-title">Prise en main</h2>
    <ol>
      <li><b>Support :</b> choisissez les dimensions et la forme, par exemple un carreau de 200 mm ou un dessous de verre, ou importez un contour SVG.</li>
      <li><b>Motif :</b> réglez le nombre et la répartition des cellules, puis déplacez, ajoutez ou effacez des cellules sur le support.</li>
      <li><b>Style</b> et <b>Fichier :</b> choisissez Lignes ou Ajours, puis exportez un SVG laser ou un DXF à l’échelle réelle.</li>
    </ol>
    <p>Survolez une commande pour découvrir son rôle.</p>
    <button type="button" className="primary" data-tip="Masquer ce guide. Le bouton ? permet de le rouvrir." onClick={onClose}>Compris</button>
  </section>
}

const SHORTCUTS: [string, string][] = [
  ['G', "Générer un nouveau motif"],
  ['R', "Relaxer"],
  ['P', "Activer ou arrêter la relaxation automatique"],
  ['V  A  E  H', "Outils Déplacer, Ajouter, Effacer et Déplacer la vue"],
  ["Espace + glisser", "Déplacer la vue avec tout outil"],
  ["Alt + clic", "Ajouter une cellule"],
  ["Maj + clic", "Effacer une cellule"],
  ["Molette, pincement", 'Zoom'],
  ['+  −  F', "Zoom avant, arrière, ajustement"],
  ['1  2  3', "Points, arêtes, Delaunay"],
  ['⌘Z  ⇧⌘Z', "Annuler, rétablir"],
  ['⌘S  ⌘O', "Enregistrer, ouvrir un projet"],
  ["Échap", "Fermer ou revenir à Déplacer"],
  ['?', "Cette liste"],
]

export function HelpDialog({ onClose, onQuickStart }: { onClose: () => void; onQuickStart: () => void }) {
  return <Modal labelledBy="help-title" onClose={onClose}>
    <h2 id="help-title">Raccourcis clavier</h2>
    <dl>{SHORTCUTS.map(([keys, action]) => <div key={keys}><dt><kbd>{keys}</kbd></dt><dd>{action}</dd></div>)}</dl>
    <p className="hint">Sur écran tactile, un doigt utilise l’outil actif ; deux doigts déplacent la vue et zooment. Sous Windows, utilisez Ctrl à la place de ⌘.</p>
    <div className="confirm-actions">
      <button type="button" data-tip="Afficher à nouveau le guide en trois étapes." onClick={onQuickStart}>Afficher la prise en main</button>
      <button type="button" className="primary" data-autofocus onClick={onClose}>Fermer</button>
    </div>
  </Modal>
}

export type Pending = { title: string; body: string; confirm: string; run: () => void }

export function ConfirmDialog({ pending, onCancel }: { pending: Pending; onCancel: () => void }) {
  return <Modal role="alertdialog" labelledBy="confirm-title" describedBy="confirm-body" onClose={onCancel}>
    <h2 id="confirm-title">{pending.title}</h2>
    <p id="confirm-body" className="hint">{pending.body}</p>
    <div className="confirm-actions">
      <button type="button" data-autofocus data-tip="Conserver le dessin actuel." onClick={onCancel}>Annuler</button>
      <button type="button" className="primary" data-tip="Continuer. Annuler permet de retrouver les points actuels." onClick={() => { onCancel(); pending.run() }}>{pending.confirm}</button>
    </div>
  </Modal>
}
