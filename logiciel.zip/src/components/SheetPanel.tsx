import { memo } from 'react'
import { GOLDEN_RECTANGLES, goldenRectangle, goldenLabel, goldenLimits } from '../lib/goldenRectangles'
import { hasLocked } from '../lib/composition'
import { RANGES, type Settings } from '../lib/settings'
import { formatLength, pixelSize, type Units } from '../lib/units'
import type { Shape } from '../voronoi/region'
import { holeCount } from '../voronoi/shape'
import { Button, LengthField, NumberField, Section, Segmented, SwitchField, type Option } from './Controls'
import { Icon } from './Icon'
import type { Change } from './PatternPanel'

const UNITS: Option<Units>[] = [
  { value: 'mm', label: 'mm', tip: "Afficher les longueurs en millimètres." },
  { value: 'in', label: 'in', tip: "Afficher les longueurs en pouces. Les fichiers SVG et DXF utilisent aussi les pouces." },
  { value: 'px', label: 'px', tip: "Afficher les longueurs en pixels selon la résolution ci-dessous, pour les images à l’écran." },
  { value: 'pc', label: 'pica', tip: "Afficher les longueurs en picas (6 par pouce), pour la mise en page imprimée." },
]
const shapes = (imported: boolean): Option<Shape>[] => [
  { value: 'rect', label: 'Rectangle', tip: "Un support rectangulaire." },
  { value: 'ellipse', label: 'Ellipse', tip: "Un support rond ou ovale inscrit dans les dimensions choisies, par exemple un dessous de verre." },
  { value: 'custom', label: "Importée", tip: "Le contour importé depuis un SVG, avec ses ouvertures.", unavailable: !imported && "Importez d’abord une forme SVG avec le bouton ci-dessous." },
]
const ASSUMED = {
  css: "Le fichier n’indique pas ses dimensions : il a été lu à 96 unités par pouce, la norme du Web. Vérifiez la largeur et la hauteur.",
  illustrator: "Le fichier n’indique pas ses dimensions et semble provenir d’Illustrator : il a été lu à 72 unités par pouce. Vérifiez la largeur et la hauteur.",
}

// Memoised: the panel only re-renders when its own props change, not on every relax step.
export const SheetPanel = memo(function SheetPanel({ s, change, onImportShape }: { s: Settings; change: Change; onImportShape: () => void }) {
  const selected = goldenRectangle(s.goldenForm)
  const locked = s.compositionEnabled && hasLocked(s.compositionTree) && 'Déverrouillez les panneaux pour modifier le format global.'
  const widthRange = s.goldenEnabled ? goldenLimits(s, 'width') : RANGES.width
  const heightRange = s.goldenEnabled ? goldenLimits(s, 'height') : RANGES.height
  const [pw, ph] = pixelSize(s.width, s.height, s.dpi)
  const maxBorder = Math.min(s.width, s.height) / 3
  const custom = s.shape === 'custom' ? s.customShape : null
  // An imported shape keeps its proportions, so width and height move together.
  const aspect = custom ? custom.width / custom.height : null
  const holes = s.customShape ? holeCount(s.customShape) : 0
  return <>
    <Section title="Dimensions">
      <div className="pair">
        <LengthField label="Largeur" mm={s.width} min={widthRange[0]} max={widthRange[1]} units={s.units} dpi={s.dpi} compact
          unavailable={locked}
          tip={aspect ? "Largeur du support. La hauteur s’adapte pour conserver les proportions de la forme importée." : "Largeur du support. Le changement d’unités convertit cette valeur sans modifier les dimensions réelles."}
          onChange={width => change(aspect ? { width, height: width / aspect, dimensionAnchor: 'width' } : { width }, 'width')} />
        <Button className="icon-button swap" label="Permuter largeur et hauteur" tip="Permuter largeur et hauteur pour changer l’orientation du support."
          unavailable={locked || (Boolean(aspect) && "La permutation déformerait la forme importée. Faites-la pivoter dans votre logiciel de dessin.")}
          onClick={() => change({ width: s.height, height: s.width, dimensionAnchor: s.dimensionAnchor === 'width' ? 'height' : 'width' }, 'swap')}><Icon name="swap" /></Button>
        <LengthField label="Hauteur" mm={s.height} min={heightRange[0]} max={heightRange[1]} units={s.units} dpi={s.dpi} compact
          unavailable={locked}
          tip={aspect ? "Hauteur du support. La largeur s’adapte pour conserver les proportions de la forme importée." : "Hauteur du support."}
          onChange={height => change(aspect ? { height, width: height * aspect, dimensionAnchor: 'height' } : { height }, 'height')} />
      </div>
      <SwitchField label="Rectangles d’or" checked={s.goldenEnabled}
        unavailable={locked || (s.shape !== 'rect' && 'Choisissez un support rectangulaire pour utiliser les rectangles d’or.')}
        tip="Lier les dimensions selon l’une des quinze proportions de Grosjean. La dernière dimension saisie reste fixe."
        onChange={goldenEnabled => change({ goldenEnabled }, 'goldenEnabled')} />
      {s.goldenEnabled && <>
        <details className="more golden-gallery">
          <summary>{selected.id} · {selected.name} · {goldenLabel(selected.ratio)}</summary>
          <p className="hint">15 proportions de Grosjean, du plus compact au plus allongé.</p>
          <div className="golden-options" role="group" aria-label="Choisir un rectangle d’or">
            {GOLDEN_RECTANGLES.map(rectangle => {
              const w = Math.min(64, 34 * rectangle.ratio), h = w / rectangle.ratio
              return <button type="button" key={rectangle.id} aria-pressed={rectangle.id === s.goldenForm}
                disabled={Boolean(locked)}
                aria-label={`Forme ${rectangle.id} — ${rectangle.name} — Rapport ${goldenLabel(rectangle.ratio)}`}
                data-tip={`${rectangle.name} · ${rectangle.formula} ≈ ${goldenLabel(rectangle.ratio)}. Conserve la ${s.dimensionAnchor === 'width' ? 'largeur' : 'hauteur'} saisie.`}
                onClick={() => change({ goldenForm: rectangle.id }, 'goldenForm')}>
                <svg viewBox="0 0 72 42" aria-hidden="true"><rect x={(72 - w) / 2} y={(42 - h) / 2} width={w} height={h} rx="1" /></svg>
                <span>{rectangle.id}</span><small>{goldenLabel(rectangle.ratio)}</small>
              </button>
            })}
          </div>
        </details>
        <p className="hint" role="status">{s.dimensionAnchor === 'width' ? 'Largeur conservée ; hauteur calculée.' : 'Hauteur conservée ; largeur calculée.'} Rapport grand côté / petit côté : {goldenLabel(selected.ratio)}.</p>
      </>}
    </Section>

    <Section title="Bordure">
      <LengthField label="Bordure" mm={Math.min(s.border, maxBorder)} min={0} max={maxBorder} units={s.units} dpi={s.dpi} small
        tip={s.cellStyle === 'holes' ? "Largeur du cadre plein entre le bord du support et les ajours." : "Distance entre le bord du support et le motif."}
        onChange={border => change({ border }, 'border')} />
    </Section>

    <details className="more"><summary>Unités et forme du support</summary>
      <Segmented label="Unités" options={UNITS} value={s.units} onChange={units => change({ units }, 'units')} />
      <Segmented label="Forme" options={shapes(Boolean(s.customShape)).map(option => s.compositionEnabled && option.value !== 'rect' ? { ...option, unavailable: 'Le format global d’une composition est rectangulaire.' } : option)} value={s.shape} onChange={shape => {
        // Back to the imported shape at the current width, with the height that keeps it from stretching.
        if (shape === 'custom' && s.customShape) change({ shape, height: s.width * (s.customShape.height / s.customShape.width) }, 'shape')
        else change({ shape }, 'shape')
      }} />
      <Button className="wide" tip="Utiliser un contour fermé SVG comme support, issu d’Illustrator, Inkscape, Figma ou d’un fichier de découpe. Les contours intérieurs deviennent des ouvertures. Vous pouvez aussi déposer un SVG sur la fenêtre."
        unavailable={s.compositionEnabled && 'Revenez au mode Motif pour utiliser un support SVG importé.'}
        onClick={onImportShape}><Icon name="import" />Importer une forme SVG…</Button>
      {s.customShape && <p className="hint">
        <b>{s.customShape.name}</b>: {formatLength(s.customShape.width, s.units, s.dpi)} × {formatLength(s.customShape.height, s.units, s.dpi)} à l’import
        {holes ? `, ${holes} ${holes === 1 ? 'ouverture' : 'ouvertures'}` : ''}.{custom ? '' : ' Choisissez Importée pour l’utiliser.'}
      </p>}
      {custom && custom.sized !== 'file' && <div className="notice" role="status"><p>{ASSUMED[custom.sized]}</p></div>}
    </details>

    <details className="more"><summary>Réglages du support</summary>
      <NumberField label="Pixels par pouce" value={s.dpi} min={RANGES.dpi[0]} max={RANGES.dpi[1]} suffix="ppi"
        unavailable={s.units === 'px' && locked}
        tip="Résolution pour les dimensions en pixels et l’export PNG. 300 convient à l’impression ; 72 à 144 aux écrans." onChange={dpi => change({ dpi: Math.round(dpi) }, 'dpi')} />
      <SwitchField label="Conserver les points si le support change" checked={s.keepPoints}
        tip="Activé : les points s’adaptent aux nouvelles dimensions ou à la nouvelle forme. Désactivé : un nouveau motif est créé, sauf en cas de retouches manuelles."
        onChange={keepPoints => change({ keepPoints }, 'keepPoints')} />
      <p className="hint">{pw.toLocaleString('fr-FR')} × {ph.toLocaleString('fr-FR')} px à {s.dpi} pixels par pouce.</p>
    </details>
  </>
})
