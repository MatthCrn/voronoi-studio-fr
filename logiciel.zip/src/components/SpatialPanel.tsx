import type { Settings } from '../lib/settings'
import { SPATIAL_DEFAULTS } from '../voronoi/spatial'
import type { SpatialMetrics } from '../voronoi/spatialHoles'
import { Button, LengthField, NumberField, Section, Segmented, SliderField, SwitchField } from './Controls'
import type { Change } from './PatternPanel'

export function SpatialPanel({ s, change, metrics }: { s: Settings; change: Change; metrics?: SpatialMetrics }) {
  const set = <K extends keyof Settings>(key: K, value: Settings[K]) => change({ [key]: value }, key)
  const advanced = ['spatialProfile', 'spatialPower', 'spatialPosition', 'spatialWidth', 'spatialCenterX', 'spatialCenterY',
    'spatialRadius', 'spatialNoise', 'spatialRatioMode', 'spatialOpening', 'spatialPreserve', 'spatialAllowClosure',
    'spatialRemoveMicro', 'spatialMicro', 'spatialFabrication', 'spatialCheckIslands'] as const
  const legacy = advanced.some(k => s[k] !== SPATIAL_DEFAULTS[k])
  return <Section title="Épaisseur des parois">
    <Segmented label="Variation d’épaisseur" hideLabel value={!s.spatialEnabled ? 'uniform' : s.spatialMode} onChange={v =>
      change({ spatialEnabled: v !== 'uniform', ...(v !== 'uniform' ? { spatialMode: v, cellStyle: 'holes' } : {}) }, 'spatialMode')}
      options={[
        { value: 'uniform', label: 'Uniforme', tip: 'Même épaisseur de départ pour toutes les parois.' },
        { value: 'linear', label: 'Dégradé', tip: 'Épaissir progressivement les parois dans une direction.' },
        { value: 'radial', label: 'Radial', tip: 'Faire varier les parois du centre vers les bords.' },
      ]} />
    {s.spatialEnabled && <>
      {s.spatialUnit === 'relative' ? <>
        <NumberField label="Épaisseur minimale" value={s.spatialMin} min={0} max={100} suffix="%" digits={1} tip="Épaisseur relative conservée depuis ce projet." onChange={v => set('spatialMin', v)} />
        <NumberField label="Épaisseur maximale" value={s.spatialMax} min={0} max={100} suffix="%" digits={1} tip="Épaisseur relative conservée depuis ce projet." onChange={v => set('spatialMax', v)} />
      </> : <>
        <LengthField label="Épaisseur minimale" mm={s.spatialMin} min={0} max={500} units={s.units} dpi={s.dpi} small tip="Parois les plus fines du motif." onChange={v => set('spatialMin', v)} />
        <LengthField label="Épaisseur maximale" mm={s.spatialMax} min={0} max={500} units={s.units} dpi={s.dpi} small tip="Parois les plus épaisses du motif." onChange={v => set('spatialMax', v)} />
      </>}
      {s.spatialMode === 'linear'
        ? <SliderField label="Direction" value={s.spatialAngle} min={0} max={360} format={v => `${v}°`} tip="0° vers la droite ; 90° vers le haut." onChange={v => set('spatialAngle', v)} />
        : <Segmented label="Parois épaisses au" value={s.spatialInvert ? 'edge' : 'centre'} onChange={v => set('spatialInvert', v === 'edge')} options={[
          { value: 'centre', label: 'Centre', tip: 'Parois épaisses au centre.' }, { value: 'edge', label: 'Bord', tip: 'Parois épaisses vers les bords.' },
        ]} />}
      <SwitchField label="Petites cellules dans les zones épaisses" checked={s.spatialDensity}
        tip="Lie simplement la taille des cellules à la variation des parois."
        onChange={v => change({ spatialDensity: v, spatialCoupling: 'coupled', spatialCouplingStrength: 100,
          spatialDensityMin: 1, spatialDensityMax: 4, spatialDensityIntensity: 35, spatialDensityInvert: false,
          ...(v && (s.placement === 'hex' || s.placement === 'square') ? { placement: 'even' } : {}) }, 'spatialDensity')} />
      {metrics && <p className="hint" role="status">Matière : {metrics.material.toLocaleString('fr-FR', { maximumFractionDigits: 1 })} % · {metrics.closed} cellule(s) pleine(s).</p>}
      {legacy && <div className="notice"><p>Les réglages détaillés de ce projet sont conservés.</p>
        <Button tip="Revenir aux réglages simples en gardant les épaisseurs et la direction. Cette action peut être annulée."
          onClick={() => change({ ...SPATIAL_DEFAULTS, spatialEnabled: true, spatialMode: s.spatialMode,
            spatialUnit: s.spatialUnit, spatialMin: s.spatialMin, spatialMax: s.spatialMax, spatialAngle: s.spatialAngle,
            spatialInvert: s.spatialInvert, spatialDensity: s.spatialDensity }, 'simplifySpatial')}>Revenir aux réglages simples</Button>
      </div>}
    </>}
  </Section>
}
