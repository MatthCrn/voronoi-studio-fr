import type { ReactNode } from 'react'
import type { Settings } from '../lib/settings'
import { formatLength, formatLong, formatSmall } from '../lib/units'
import type { Metrics } from '../voronoi/pattern'
import { Button } from './Controls'
import { Icon, type IconName } from './Icon'
import type { Tool } from './Stage'

// The floating bars around the sheet: tools and visibility on top, the main actions and status below,
// and the measurements panel.

const TOOLS: { id: Tool; label: string; icon: IconName; key: string; tip: string }[] = [
  { id: 'move', label: "Déplacer", icon: 'move', key: 'V', tip: "Faites glisser un point pour déplacer sa cellule. Alt + clic ajoute, Maj + clic efface ; faites glisser une zone vide pour déplacer la vue." },
  { id: 'add', label: "Ajouter", icon: 'add', key: 'A', tip: "Cliquez pour ajouter une cellule ; maintenez le bouton pour la positionner." },
  { id: 'erase', label: "Effacer", icon: 'erase', key: 'E', tip: "Cliquez sur une cellule pour l’effacer, ou faites glisser pour en effacer plusieurs." },
  { id: 'pan', label: "Déplacer la vue", icon: 'pan', key: 'H', tip: "Faites glisser pour déplacer la vue. Maintenez Espace pour le faire avec tout outil." },
]

const TOOL_CAPTION: Record<Tool, string> = {
  move: "Glisser un point pour le déplacer · Alt + clic : ajouter · Maj + clic : effacer · Espace + glisser : déplacer la vue · Molette : zoom",
  add: "Cliquez à l’intérieur de la bordure pour ajouter une cellule · Échap : Déplacer",
  erase: "Cliquez ou faites glisser sur les cellules pour les effacer · Échap : Déplacer",
  pan: "Glisser pour déplacer la vue · Molette ou pincement : zoom · Échap : Déplacer",
}

export function ViewBar({ tool, setTool, s, toggle, zoom, onFit, onZoom }: {
  tool: Tool; setTool: (tool: Tool) => void; s: Settings
  toggle: (key: 'showSites' | 'showEdges' | 'showDelaunay') => void; zoom: number; onFit: () => void; onZoom: (factor: number) => void
}) {
  const edgeName = s.cellStyle === 'holes' ? "Ajours" : "Arêtes"
  return <div className="viewport-bars">
    <div className="viewport-bar-row">
      <div className="floating-bar glass" role="toolbar" aria-label="Outils">
        {TOOLS.map(t => <Button key={t.id} pressed={tool === t.id} tip={t.tip} shortcut={t.key} label={t.label} onClick={() => setTool(t.id)}>
          <Icon name={t.icon} /><span className="compact-label">{t.label}</span></Button>)}
      </div>
      <div className="floating-bar glass" role="toolbar" aria-label="Affichage">
        <Button pressed={s.showSites} shortcut="1" tip="Afficher ou masquer les points générateurs des cellules." onClick={() => toggle('showSites')}>Points</Button>
        <Button pressed={s.showEdges} shortcut="2" tip={`Afficher ou masquer les ${edgeName.toLowerCase()} des cellules.`} onClick={() => toggle('showEdges')}>{edgeName}</Button>
        <Button pressed={s.showDelaunay} shortcut="3" tip="Afficher ou masquer la triangulation de Delaunay, qui relie les points voisins." onClick={() => toggle('showDelaunay')}>Delaunay</Button>
        <span className="bar-divider" aria-hidden="true" />
        <Button className="icon-button zoom-step" label="Zoom arrière" shortcut="−" tip="Réduire le zoom." onClick={() => onZoom(1 / 1.25)}><Icon name="minus" /></Button>
        <Button className="zoom-readout" shortcut="F" tip="Ajuster le support entier à la fenêtre." label={`Zoom ${Math.round(zoom * 100)} pour cent. Ajuster à la fenêtre`} onClick={onFit}>{Math.round(zoom * 100)}%</Button>
        <Button className="icon-button zoom-step" label="Zoom avant" shortcut="+" tip="Augmenter le zoom." onClick={() => onZoom(1.25)}><Icon name="plus" /></Button>
      </div>
    </div>
    <p className="view-caption"><span>{TOOL_CAPTION[tool]}</span></p>
  </div>
}

export function Dock({ relaxSteps, auto, busy, canRelax, onGenerate, onRelax, onAuto, status, warning, canUndo, canRedo, onUndo, onRedo }: {
  relaxSteps: number; auto: boolean; busy: boolean; canRelax: string | false
  onGenerate: () => void; onRelax: () => void; onAuto: () => void
  status: ReactNode; warning: boolean; canUndo: boolean; canRedo: boolean; onUndo: () => void; onRedo: () => void
}) {
  const steps = Math.max(1, relaxSteps)
  return <div className="dock">
    <div className="timeline glass">
      <div className="transport" role="group" aria-label="Actions sur le motif">
        <Button className="primary" shortcut="G" tip="Créer un nouveau motif avec une nouvelle graine aléatoire et les réglages actuels." onClick={onGenerate}>
          <Icon name="dice" />Générer</Button>
        <Button shortcut="R" unavailable={canRelax || (auto && "La relaxation automatique est active. Arrêtez-la pour avancer par itérations.") || (busy && "Attendez la fin de la mise à jour en cours.")}
          tip={`Effectuer ${steps} ${steps === 1 ? 'itération' : 'itérations'} de relaxation de Lloyd : les points se déplacent au centre de leur cellule pour homogénéiser les tailles.`}
          onClick={onRelax}><Icon name="relax" /><span className="compact-label">Relaxer ×{steps}</span></Button>
        <Button shortcut="P" pressed={auto} unavailable={canRelax || (!auto && busy && "Attendez la fin de la mise à jour en cours.")} tip={auto ? "Arrêter la relaxation." : "Poursuivre la relaxation jusqu’à votre arrêt, même pendant les réglages ou le déplacement des points."}
          onClick={onAuto}><Icon name={auto ? 'pause' : 'play'} /><span className="compact-label">Relaxation auto</span></Button>
      </div>
      <span className="timeline-status" role="status" data-warning={warning}>{status}</span>
      <div className="transport" role="group" aria-label="Historique">
        <Button className="icon-button" label="Annuler" shortcut="⌘Z" unavailable={!canUndo && "Aucune action à annuler."} tip="Annuler la dernière modification." onClick={onUndo}><Icon name="undo" /></Button>
        <Button className="icon-button" label="Rétablir" shortcut="⇧⌘Z" unavailable={!canRedo && "Aucune action à rétablir."} tip="Rétablir la modification annulée." onClick={onRedo}><Icon name="redo" /></Button>
      </div>
    </div>
  </div>
}

export function Inspector({ m, s, count }: { m: Metrics; s: Settings; count: number }) {
  const L = (mm: number) => formatSmall(mm, s.units, s.dpi)
  const holes = s.cellStyle === 'holes'
  const rows: [string, string, string][] = [
    ["Support", `${formatLength(s.width, s.units, s.dpi)} × ${formatLength(s.height, s.units, s.dpi)}`, s.shape === 'ellipse' ? "Une ellipse inscrite dans ces dimensions."
      : s.shape === 'custom' ? `La forme importée${s.customShape ? `, ${s.customShape.name},` : ''} à ces dimensions.` : "Largeur × hauteur du support."],
    ["Cellules", count.toLocaleString('fr-FR'), "Nombre de points, à raison d’un par cellule."],
    ...(holes ? [["Ajours", `${m.holes.toLocaleString('fr-FR')}${m.dropped ? ` · ${m.dropped.toLocaleString('fr-FR')} pleines` : ''}`,
      "Nombre d’ajours. Les cellules trop petites ou refermées par la largeur de matière restent pleines."] as [string, string, string]] : []),
    ["Cellule moyenne", `${L(m.meanSize)} de diamètre`, "Diamètre d’un cercle de même surface que la cellule moyenne."],
    ["Variation des tailles", `${(m.evenness * 100).toLocaleString('fr-FR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} %`, "Dispersion des surfaces des cellules (coefficient de variation). 0 % signifie des tailles identiques ; des points aléatoires donnent environ 50 %."],
    holes
      ? ["Ajour le plus étroit", m.holes ? L(m.narrowest) : '—', "La plus petite largeur des ajours. Comparez-la au trait de coupe laser ou au diamètre de la fraise."]
      : ["Arête la plus courte", L(m.shortestEdge), "Les arêtes très courtes produisent de petits détails fragiles. La relaxation les allonge."],
    ["Longueur de découpe", formatLong(m.cutLength, s.units), "Longueur totale des lignes de découpe, contour du support compris, pour estimer le temps de travail."],
    ...(m.spatial ? [
      ['Matière obtenue', `${m.spatial.material.toLocaleString('fr-FR', { maximumFractionDigits: 1 })} %`, 'Surface de matière divisée par la surface utile du support, calculée sur les vrais ajours.'],
      ['Cellules fermées', String(m.spatial.closed), 'Cellules devenues pleines, sans contour intérieur parasite.'],
      ...(m.spatial.requested !== null ? [['Matière demandée', `${m.spatial.requested} %${m.spatial.reachable ? '' : ' · inaccessible'}`, 'La recherche respecte les bornes d’épaisseur et les contraintes d’ouverture.']] : []),
    ] as [string, string, string][] : []),
  ]
  return <section className="measurements" aria-labelledby="measure-title">
    <h2 id="measure-title">Mesures</h2>
    <dl>{rows.map(([term, value, tip]) => <div key={term}><dt data-tip={tip} tabIndex={0}>{term}</dt><dd>{value}</dd></div>)}</dl>
  </section>
}
