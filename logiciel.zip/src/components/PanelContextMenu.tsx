import { SelectionActions } from './SelectionActions'
import { sanitizeGroups } from '../lib/compositionEditing'
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { dividePanel, panelNodes, placeLayout, replaceNode } from '../lib/composition'
import type { Settings } from '../lib/settings'
import { formatLength } from '../lib/units'
import type { Change } from './PatternPanel'

export function PanelContextMenu({ s, panelId, x, y, close, change, selection, setSelection }: {
  s: Settings; panelId: string; x: number; y: number; close: () => void; change: Change; selection: string[]; setSelection: (ids: string[]) => void
}) {
  const menu = useRef<HTMLDivElement>(null), dialog = useRef<HTMLDialogElement>(null)
  const [editing, setEditing] = useState(false), [count, setCount] = useState('2'), [axis, setAxis] = useState<'x' | 'y'>('x')
  const tree = s.compositionTree!
  const panel = placeLayout(tree, s.width, s.height, s.compositionJeu).find(p => p.node.kind === 'panel' && p.node.id === panelId)
  const maximum = 25 - panelNodes(tree).length
  const n = Number(count)
  const result = dividePanel(tree, panelId, n, axis, s.width, s.height, s.compositionJeu, s.compositionMin)
  const locked = (panel?.node.kind === 'panel' && panel.node.locked) || maximum < 2
  useEffect(() => {
    if (editing) { dialog.current?.showModal(); return }
    menu.current?.querySelector('button')?.focus()
    const outside = (event: PointerEvent) => { if (!menu.current?.contains(event.target as Node)) close() }
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') close() }
    window.addEventListener('pointerdown', outside); window.addEventListener('keydown', escape)
    return () => { window.removeEventListener('pointerdown', outside); window.removeEventListener('keydown', escape) }
  }, [editing, close])
  if (!panel || panel.node.kind !== 'panel') return null
  const size = ((axis === 'x' ? panel.width : panel.height) - (n - 1) * s.compositionJeu) / n
  return createPortal(editing ? <dialog ref={dialog} className="panel-divide-dialog" aria-labelledby="divide-title" onCancel={close}>
    <form onSubmit={event => {
      event.preventDefault()
      if (!result) return
      const children = panelNodes(result.tree).filter(p => !panelNodes(tree).some(old => old.id !== panelId && old.id === p.id)).map(p => p.id)
      const groups = s.compositionGroups.map(g => g.flatMap(id => id === panelId ? children : [id]))
      change({ compositionTree: result.tree, compositionCount: panelNodes(result.tree).length, compositionGroups: sanitizeGroups(groups, result.tree) }, `divide:${Date.now()}`)
      setSelection(children); close()
    }}>
      <h2 id="divide-title">Diviser {panelId} en n</h2>
      <label className="field">Nombre de panneaux<input autoFocus type="number" min="2" max={maximum} step="1" value={count} onChange={e => setCount(e.target.value)} /></label>
      <label className="field">Sens de division<select value={axis} onChange={e => setAxis(e.target.value as 'x' | 'y')}>
        <option value="x">Côte à côte (colonnes)</option><option value="y">Superposés (lignes)</option>
      </select></label>
      {result ? <p>{n} panneaux de {formatLength(axis === 'x' ? size : panel.width, s.units, s.dpi)} × {formatLength(axis === 'y' ? size : panel.height, s.units, s.dpi)}.</p>
        : <p role="alert">Choisissez de 2 à {maximum} panneaux, avec au moins {formatLength(s.compositionMin, s.units, s.dpi)} de chaque côté.</p>}
      <p className="hint">Jeu conservé : {formatLength(s.compositionJeu, s.units, s.dpi)}. Le motif du panneau est conservé.</p>
      <div className="button-row"><button type="button" onClick={close}>Annuler</button><button type="submit" className="primary" disabled={!result}>Diviser</button></div>
    </form>
  </dialog> : <div ref={menu} className="panel-context-menu" role="menu" aria-label={`Actions du panneau ${panelId}`} style={{ left: Math.max(8, Math.min(x, window.innerWidth - 240)), top: Math.max(8, Math.min(y, window.innerHeight - 360)) }}>
    {panel.node.empty ? <><button type="button" role="menuitem" disabled={panelNodes(tree).length >= 24 || Math.min(panel.width, panel.height) < s.compositionMin} onClick={() => {
      const result = replaceNode(tree, panelId, { kind: 'panel', id: panelId, locked: false, pattern: true })
      change({ compositionTree: result, compositionCount: panelNodes(result).length }, `restore:${Date.now()}`); setSelection([panelId]); close()
    }}>Créer un panneau ici</button><p className="hint">L’emplacement reprend un panneau aux mêmes dimensions.</p></> : <>
    {selection.length === 1 && <button type="button" role="menuitem" disabled={!!locked} onClick={() => { setAxis(panel.width >= panel.height ? 'x' : 'y'); setEditing(true) }}>Diviser en n…</button>}
    {selection.length === 1 && locked && <p className="hint">{panel.node.locked ? 'Déverrouillez ce panneau pour le diviser.' : 'La composition atteint la limite de 24 panneaux.'}</p>}
    <SelectionActions s={s} ids={selection} change={change} setSelection={setSelection} close={close} menu />
    <p className="hint">Supprimer laisse un emplacement vide. Annuler permet de le retrouver.</p></>}
  </div>, document.body)
}
