import { memo } from 'react'
import { RANGES, REFERENCE_STYLE, type Settings } from '../lib/settings'
import type { CellStyle } from '../voronoi/pattern'
import { Button, ColorField, LengthField, Section, Segmented, SliderField, SwitchField, type Option } from './Controls'
import type { Change } from './PatternPanel'

const STYLES: Option<CellStyle>[] = [
  { value: 'lines', label: "Lignes", tip: "Arêtes des cellules en traits uniques, pour la gravure, le traçage, l’impression ou la découpe séparée des cellules." },
  { value: 'holes', label: "Ajours", tip: "Chaque cellule devient un ajour aux coins arrondis, en conservant de la matière entre les ouvertures." },
]

// Memoised: the panel only re-renders when its own props change, not on every relax step.
export const StylePanel = memo(function StylePanel({ s, change, holes, dropped }: { s: Settings; change: Change; holes: number; dropped: number }) {
  const len = { units: s.units, dpi: s.dpi, small: true }
  return <>
    <Section title="Cellules">
      <Button tip="Appliquer les ajours organiques à 59 %, traits bordeaux de 0,3 mm sur fond blanc, sans changer les dimensions ni les graines." onClick={() => change(REFERENCE_STYLE, 'referenceStyle')}>Appliquer le style par défaut</Button>
      <Segmented label="Style des cellules" options={STYLES} value={s.cellStyle} onChange={cellStyle => change({ cellStyle }, 'cellStyle')} />
      <p className="hint">{s.cellStyle === 'holes'
        ? "Ajours : des ouvertures séparées par un réseau de matière, pour les panneaux de Voronoi découpés au laser ou imprimés en 3D."
        : "Lignes : chaque arête est tracée une seule fois, sans double passage de l’outil."}</p>
      {s.cellStyle === 'holes' && <>
        <Segmented label="Contours" value={s.organicEnabled ? 'organic' : 'geometric'} onChange={v => change({ organicEnabled: v === 'organic' }, 'organicEnabled')}
          options={[
            { value: 'geometric', label: 'Géométriques', tip: 'Côtés droits avec arrondi des angles facultatif.' },
            { value: 'organic', label: 'Organiques', tip: 'Courber les côtés pour créer des cellules en forme de galets et des parois qui se renflent.' },
          ]} />
        {s.organicEnabled && <>
          <SliderField label="Souplesse" value={s.organicAmount} min={0} max={100} format={v => `${v} %`}
            tip="À 100 %, tout le contour est courbe. Les ouvertures se resserrent et les parois s’épaississent près des jonctions."
            onChange={organicAmount => change({ organicAmount }, 'organicAmount')} />
          <p className="hint">Des ajours en forme de galets, avec des parois d’épaisseur variable. Ces courbes sont aussi utilisées pour la découpe.</p>
        </>}
        <LengthField label="Largeur de matière" mm={s.web} min={RANGES.web[0]} max={RANGES.web[1]} {...len}
          unavailable={s.spatialEnabled && 'L’épaisseur est pilotée par Variation spatiale dans Motif.'}
          tip="Largeur de matière conservée entre les ajours voisins." onChange={web => change({ web }, 'web')} />
        {!s.organicEnabled && <LengthField label="Arrondi des angles" mm={s.cornerRadius} min={RANGES.cornerRadius[0]} max={RANGES.cornerRadius[1]} {...len}
          tip="Arrondit seulement les angles des ajours géométriques." onChange={cornerRadius => change({ cornerRadius }, 'cornerRadius')} />}
        <details className="more"><summary>Limite des petits ajours</summary>
        <LengthField label="Largeur minimale des ajours" mm={s.minHole} min={RANGES.minHole[0]} max={RANGES.minHole[1]} {...len}
          unavailable={s.spatialEnabled && 'Utilisez Ouverture minimale dans Variation spatiale.'}
          tip="Les cellules plus étroites que cette valeur restent pleines pour éviter les détails qui brûlent ou se cassent." onChange={minHole => change({ minHole }, 'minHole')} />
        </details>
        {holes === 0 && dropped > 0
          ? <div className="notice" role="status"><p>{s.spatialEnabled
            ? 'Toutes les cellules sont pleines avec les réglages de variation spatiale actuels. Ajustez les épaisseurs ou les contraintes d’ouverture dans Motif.'
            : 'Aucun ajour possible : la matière ou la largeur minimale dépasse la taille des cellules. Réduisez ces valeurs ou le nombre de cellules.'}</p></div>
          : dropped > 0 && <p className="hint">{dropped.toLocaleString('fr-FR')} {s.spatialEnabled
            ? 'cellule(s) fermée(s) par la variation spatiale et les contraintes d’ouverture.'
            : `${dropped === 1 ? 'cellule reste pleine car elle est plus étroite' : 'cellules restent pleines car elles sont plus étroites'} que la largeur minimale des ajours.`}</p>}
      </>}
    </Section>

    <details className="more"><summary>Couleurs et affichage</summary>
    <Section title="Couleur et trait">
      <LengthField label="Épaisseur du trait" mm={s.lineWidth} min={RANGES.lineWidth[0]} max={RANGES.lineWidth[1]} {...len}
        tip="Épaisseur du trait dans l’aperçu, le PNG et le SVG graphique. Les fichiers laser utilisent toujours des traits fins." onChange={lineWidth => change({ lineWidth }, 'lineWidth')} />
      <ColorField label="Couleur du trait" value={s.lineColor} tip="Couleur des arêtes des cellules." onChange={lineColor => change({ lineColor }, 'lineColor')} />
      <SwitchField label={s.cellStyle === 'holes' ? "Remplir les ajours" : "Remplir les cellules"} checked={s.fill}
        tip={s.cellStyle === 'holes' ? "Colorer l’intérieur des ajours." : "Colorer la zone à l’intérieur du motif."} onChange={fill => change({ fill }, 'fill')} />
      {s.fill && <ColorField label="Couleur de remplissage" value={s.fillColor} tip="Couleur à l’intérieur des cellules." onChange={fillColor => change({ fillColor }, 'fillColor')} />}
      <ColorField label={s.cellStyle === 'holes' ? "Couleur du matériau" : "Fond"} value={s.background}
        tip="Couleur du support derrière le motif." onChange={background => change({ background }, 'background')} />
      <p className="hint">La barre au-dessus du support active ou masque les points, les arêtes et les lignes de Delaunay dans l’aperçu et tous les exports.</p>
    </Section>
    </details>
  </>
})
