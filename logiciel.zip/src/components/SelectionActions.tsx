import { useMemo } from 'react'
import { deletePanels, groupSelection, mergePanels, sameIds, sanitizeGroups, selectionLocked } from '../lib/compositionEditing'
import { panelNodes } from '../lib/composition'
import type { Settings } from '../lib/settings'
import type { Change } from './PatternPanel'

export function SelectionActions({ s, ids, change, setSelection, close, menu = false }: {
  s: Settings; ids: string[]; change: Change; setSelection: (ids: string[]) => void; close?: () => void; menu?: boolean
}) {
  const tree = s.compositionTree!
  const fusion = useMemo(() => mergePanels(tree, ids, s.width, s.height, s.compositionJeu), [tree, ids, s.width, s.height, s.compositionJeu])
  const grouped = s.compositionGroups.some(g => sameIds(g, ids))
  const containsGroup = s.compositionGroups.some(g => g.some(id => ids.includes(id)))
  const locked = selectionLocked(tree, ids)
  const finish = () => close?.()
  return <div className={menu ? 'selection-menu-actions' : 'selection-actions'}>
    <button type="button" role={menu ? 'menuitem' : undefined} disabled={ids.length < 2 || grouped}
      onClick={() => { change({ compositionGroups: groupSelection(s.compositionGroups, ids) }, `group:${Date.now()}`); finish() }}>Grouper</button>
    <button type="button" role={menu ? 'menuitem' : undefined} disabled={!containsGroup}
      onClick={() => { change({ compositionGroups: s.compositionGroups.map(g => g.filter(id => !ids.includes(id))).filter(g => g.length >= 2) }, `ungroup:${Date.now()}`); finish() }}>Dégrouper</button>
    <button type="button" role={menu ? 'menuitem' : undefined} disabled={'error' in fusion} title={'error' in fusion ? fusion.error : 'Un seul panneau, sans les jeux ni les contours intérieurs.'}
      onClick={() => {
        if ('error' in fusion) return
        const groups = s.compositionGroups.map(g => g.flatMap(id => ids.includes(id) ? [fusion.id] : [id]))
        change({ compositionTree: fusion.tree, compositionCount: panelNodes(fusion.tree).length, compositionGroups: sanitizeGroups(groups, fusion.tree) }, `merge:${Date.now()}`)
        setSelection([fusion.id]); finish()
      }}>Fusionner en un panneau</button>
    {ids.length > 1 && 'error' in fusion && <p className="hint">{fusion.error}</p>}
    <button type="button" role={menu ? 'menuitem' : undefined} disabled={locked || !ids.length} title={locked ? 'Déverrouillez la sélection avant de la supprimer.' : 'Les emplacements resteront vides. Les voisins ne changent pas.'}
      onClick={() => {
        const result = deletePanels(tree, ids)
        if (!result) return
        change({ compositionTree: result, compositionGroups: sanitizeGroups(s.compositionGroups, result), compositionCount: Math.max(1, panelNodes(result).length) }, `delete:${Date.now()}`)
        setSelection([]); finish()
      }}>Supprimer et laisser vide</button>
    {locked && <p className="hint">La sélection contient un panneau verrouillé.</p>}
  </div>
}
