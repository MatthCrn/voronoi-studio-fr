import { isolateSelection, selectionBounds, selectionLocked, swapGroupAt } from '../lib/compositionEditing'
import { useCallback, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react'
import type { Settings } from '../lib/settings'
import type { Change } from './PatternPanel'
import type { StageControls } from './Stage'
import { findNode, moveElement, moveSeparation, parentOf, placeLayout, type DropSide, type LayoutNode } from '../lib/composition'
import { formatLength } from '../lib/units'
import { PanelContextMenu } from './PanelContextMenu'

type Drag = { kind: 'panel' | 'split'; source: string; ids: string[]; anchor: string; isolated: boolean; base: LayoutNode; x: number; y: number; moved: boolean } | { kind: 'pan'; x: number; y: number; px: number; py: number }
export function CompositionStage({ s, frameRef, controlRef, selected, selection, setSelection, select, change, onZoom, notice, artwork }: {
  s: Settings; frameRef: RefObject<HTMLDivElement | null>; controlRef: RefObject<StageControls | null>
  selected: string | null; selection: string[]; setSelection: (ids: string[]) => void; select: (id: string | null) => void; change: Change; onZoom: (zoom: number) => void; notice: (text: string) => void; artwork: Map<string, string>
}) {
  const root = useRef<HTMLDivElement>(null), svg = useRef<SVGSVGElement>(null), drag = useRef<Drag | null>(null)
  const [frame, setFrame] = useState({ x: 0, y: 0, width: 600, height: 500, outerWidth: 1000, outerHeight: 700 })
  const [view, setView] = useState({ zoom: 1, x: 0, y: 0 })
  const [draft, setDraft] = useState<LayoutNode | null>(null), [target, setTarget] = useState<string | null>(null), [invalid, setInvalid] = useState(false), [guide, setGuide] = useState('')
  const [ghost, setGhost] = useState<{ x: number; y: number; width: number; height: number } | null>(null)
  const [dragging, setDragging] = useState(false)
  const [menu, setMenu] = useState<{ id: string; x: number; y: number } | null>(null)
  const closeMenu = useCallback(() => setMenu(null), [])
  useLayoutEffect(() => {
    const measure = () => {
      const r = root.current?.getBoundingClientRect(), f = frameRef.current?.getBoundingClientRect()
      if (r) setFrame({ x: f ? f.left - r.left : 0, y: f ? f.top - r.top : 0, width: f?.width || r.width, height: f?.height || r.height, outerWidth: r.width, outerHeight: r.height })
    }
    measure(); const observer = new ResizeObserver(measure)
    if (root.current) observer.observe(root.current)
    if (frameRef.current) observer.observe(frameRef.current)
    return () => observer.disconnect()
  }, [frameRef])
  const fit = Math.max(1e-6, Math.min((frame.width - 40) / s.width, (frame.height - 40) / s.height))
  const scale = fit * view.zoom, ox = frame.x + frame.width / 2 - s.width * scale / 2 + view.x, oy = frame.y + frame.height / 2 - s.height * scale / 2 + view.y
  const zoomBy = useCallback((factor: number) => setView(v => ({ ...v, zoom: Math.max(.25, Math.min(20, v.zoom * factor)) })), [])
  useEffect(() => { controlRef.current = { fit: () => setView({ zoom: 1, x: 0, y: 0 }), zoomBy }; return () => { controlRef.current = null } }, [controlRef, zoomBy])
  useEffect(() => onZoom(view.zoom), [view.zoom, onZoom])
  useEffect(() => {
    const el = root.current
    if (!el) return
    const wheel = (e: WheelEvent) => { e.preventDefault(); zoomBy(Math.exp(-e.deltaY * .0015)) }
    el.addEventListener('wheel', wheel, { passive: false }); return () => el.removeEventListener('wheel', wheel)
  }, [zoomBy])
  const cancel = useCallback(() => { drag.current = null; setDraft(null); setTarget(null); setGhost(null); setInvalid(false); setGuide(''); setDragging(false) }, [])
  useEffect(() => { cancel(); setMenu(null) }, [s.compositionTree, s.width, s.height, s.compositionJeu, cancel])
  useEffect(() => {
    const escape = (e: KeyboardEvent) => { if (e.key === 'Escape') { cancel(); select(null) } }
    window.addEventListener('keydown', escape); return () => window.removeEventListener('keydown', escape)
  }, [cancel, select])
  const tree = s.compositionTree
  const displayed = draft ?? tree
  const placed = displayed ? placeLayout(displayed, s.width, s.height, s.compositionJeu) : []
  const panels = placed.filter(p => p.node.kind === 'panel' && !p.node.empty)
  const selectedBox = placed.find(p => p.node.id === selected)
  const world = (e: { clientX: number; clientY: number }) => {
    const r = root.current!.getBoundingClientRect()
    return { x: (e.clientX - r.left - ox) / scale, y: (e.clientY - r.top - oy) / scale }
  }
  const start = (event: React.PointerEvent, id: string, kind: 'panel' | 'split') => {
    if (!tree || event.button !== 0) return
    event.stopPropagation(); event.preventDefault()
    const p = world(event)
    if ((event.ctrlKey || event.metaKey) && kind === 'panel') { setSelection(selection.includes(id) ? selection.filter(p => p !== id) : [...selection, id]); return }
    if (event.shiftKey && kind === 'panel' && selection.length) {
      const group = s.compositionGroups.find(g => g.includes(id))
      if (group) { setSelection(group); return }
      let common = findNode(tree, selected ?? selection[0])!
      while (common && !findNode(common, id)) { const parent = parentOf(tree, common.id); if (!parent) break; common = parent }
      select(common?.id ?? id); return
    }
    let source = id, base = tree, ids = [id], isolated = true
    if (kind === 'panel') {
      ids = selection.includes(id) ? selection : s.compositionGroups.find(g => g.includes(id)) ?? [id]
      setSelection(ids)
      if (selectionLocked(tree, ids)) { notice('Cette sélection contient un panneau verrouillé.'); return }
      const group = isolateSelection(tree, ids, s.width, s.height, s.compositionJeu)
      isolated = !!group
      if (group) { source = group.id; base = group.tree }
    }
    drag.current = { kind, source, ids, anchor: id, isolated, base, x: p.x, y: p.y, moved: false }
    svg.current?.setPointerCapture(event.pointerId)
  }
  const move = (event: React.PointerEvent) => {
    const d = drag.current
    if (!d) return
    if (d.kind === 'pan') { setView(v => ({ ...v, x: d.px + event.clientX - d.x, y: d.py + event.clientY - d.y })); return }
    const p = world(event)
    if (!d.moved && Math.hypot(p.x - d.x, p.y - d.y) * scale < 4) return
    d.moved = true; setDragging(true)
    if (d.kind === 'split') {
      const node = findNode(d.base, d.source)
      if (node?.kind !== 'split') return
      const result = moveSeparation(d.base, d.source, node.axis === 'x' ? p.x : p.y, s.width, s.height, s.compositionJeu, s.compositionMin, s.compositionSnap && !event.altKey ? 7 / scale : 0)
      setDraft(result?.tree ?? null); setInvalid(!result); setGuide(result?.guide ?? ''); return
    }
    const original = d.isolated ? placeLayout(d.base, s.width, s.height, s.compositionJeu).find(n => n.node.id === d.source)! : selectionBounds(d.base, d.ids, s.width, s.height, s.compositionJeu)!
    setGhost({ x: original.x + p.x - d.x, y: original.y + p.y - d.y, width: original.width, height: original.height })
    const source = findNode(d.base, d.source)!
    const hit = placeLayout(d.base, s.width, s.height, s.compositionJeu).find(n => n.node.kind === 'panel' && !d.ids.includes(n.node.id) && !findNode(source, n.node.id) && p.x >= n.x && p.x <= n.x + n.width && p.y >= n.y && p.y <= n.y + n.height)
    setTarget(hit?.node.id ?? null)
    if (!hit) { setDraft(null); setInvalid(false); setGuide('Déposer sur un autre panneau'); return }
    const edges: [DropSide, number][] = [['left', (p.x - hit.x) / hit.width], ['right', (hit.x + hit.width - p.x) / hit.width], ['top', (p.y - hit.y) / hit.height], ['bottom', (hit.y + hit.height - p.y) / hit.height]]
    edges.sort((a, b) => a[1] - b[1]); const side = edges[0][1] < .23 ? edges[0][0] : 'centre'
    const result = d.isolated ? moveElement(d.base, d.source, hit.node.id, side, s.width, s.height, s.compositionJeu, s.compositionMin) : swapGroupAt(d.base, d.ids, d.anchor, hit.node.id, s.width, s.height, s.compositionJeu)
    setDraft(result); setInvalid(!result)
    setGuide(result ? side === 'centre' ? `Permuter avec ${hit.node.id}` : `Insérer ${side === 'left' ? 'à gauche' : side === 'right' ? 'à droite' : side === 'top' ? 'au-dessus' : 'en dessous'} de ${hit.node.id}` : d.isolated ? 'Position incompatible avec les limites ou les verrouillages' : 'Ce groupe doit être déposé sur des emplacements de mêmes dimensions et de même disposition')
  }
  const finish = () => {
    const d = drag.current
    if (d && d.kind !== 'pan' && d.moved) {
      if (draft && !invalid) change({ compositionTree: draft }, `compositionGesture:${Date.now()}`)
      else if (invalid) notice('Déplacement annulé : position incompatible avec les limites ou les verrouillages.')
    }
    if (d?.kind === 'panel' && !d.moved) setSelection(s.compositionGroups.find(g => g.includes(d.anchor)) ?? [d.anchor])
    cancel()
  }
  return <div ref={root} className="stage-canvas composition-stage">
    <svg ref={svg} width="100%" height="100%" aria-label="Composition de panneaux. Glisser les panneaux ou les séparations pour ajuster la composition."
      onPointerMove={move} onPointerUp={finish} onPointerCancel={cancel} onContextMenu={e => e.preventDefault()}
      onPointerDown={e => {
        if (e.target !== e.currentTarget) return
        select(null); drag.current = { kind: 'pan', x: e.clientX, y: e.clientY, px: view.x, py: view.y }; e.currentTarget.setPointerCapture(e.pointerId)
      }}>
      <g transform={`translate(${ox} ${oy}) scale(${scale})`}>
        <rect x="0" y="0" width={s.width} height={s.height} className="composition-global" pointerEvents="none" />
        {panels.map((p, i) => {
          const labelWidth = Math.max(0, Math.min(116, p.width * scale - 6)), showDimensions = labelWidth > 105 && p.height * scale > 44
          return <g key={p.node.id} role="button" tabIndex={0} aria-label={`Panneau ${p.node.id}`} data-panel-id={p.node.id}
          onContextMenu={e => { e.preventDefault(); e.stopPropagation(); cancel(); if (!selection.includes(p.node.id)) setSelection(s.compositionGroups.find(g => g.includes(p.node.id)) ?? [p.node.id]); setMenu({ id: p.node.id, x: e.clientX, y: e.clientY }) }}
          onPointerDown={e => start(e, p.node.id, 'panel')} onDoubleClick={() => select(p.node.id)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(p.node.id) } }}>
          <rect x={p.x} y={p.y} width={Math.max(0, p.width)} height={Math.max(0, p.height)} fill={['#f5f9ff', '#edf4f2', '#f5f1fa', '#fff8ee'][i % 4]} />
          {s.compositionShowPattern && !dragging && artwork.has(p.node.id) && <g data-panel-artwork={p.node.id} pointerEvents="none" dangerouslySetInnerHTML={{ __html: artwork.get(p.node.id)! }} />}
          <rect x={p.x} y={p.y} width={Math.max(0, p.width)} height={Math.max(0, p.height)} fill="none" stroke={target === p.node.id ? invalid ? '#d22a40' : '#0876d9' : s.panelContourColor} strokeWidth={target === p.node.id ? 3 / scale : 1.3 / scale} pointerEvents="none" />
          {labelWidth > 28 && <g pointerEvents="none" transform={`translate(${p.x + p.width / 2} ${p.y + p.height / 2})`}>
            <rect x={-labelWidth / 2 / scale} y={(showDimensions ? -18 : -11) / scale} width={labelWidth / scale} height={(showDimensions ? 36 : 22) / scale} fill="#ffffff" opacity=".9" rx={7 / scale} />
            <text textAnchor="middle" y={(showDimensions ? -2 : 4) / scale} fontSize={12 / scale} fontWeight="650" fill="#24384c">{p.node.id}{p.node.kind === 'panel' && p.node.locked ? ' •' : ''}</text>
            {showDimensions && <text textAnchor="middle" y={12 / scale} fontSize={10 / scale} fill="#41576e">{formatLength(p.width, s.units, s.dpi)} × {formatLength(p.height, s.units, s.dpi)}</text>}
          </g>}
        </g>})}
        {panels.filter(p => selection.includes(p.node.id)).map(p => <rect key={'selected-' + p.node.id} x={p.x} y={p.y} width={p.width} height={p.height} fill="none" stroke="#0876d9" strokeWidth={3 / scale} pointerEvents="none" />)}
        {placed.filter(p => p.node.kind === 'panel' && p.node.empty).map(p => <g key={p.node.id} role="button" tabIndex={0} aria-label={`Emplacement vide ${p.node.id}`} data-empty-id={p.node.id} onContextMenu={e => { e.preventDefault(); e.stopPropagation(); cancel(); setSelection([]); setMenu({ id: p.node.id, x: e.clientX, y: e.clientY }) }}><rect x={p.x} y={p.y} width={p.width} height={p.height} fill="#aab7c622" stroke="#728399" strokeWidth={1 / scale} strokeDasharray={`${5 / scale} ${4 / scale}`} /><text x={p.x + p.width / 2} y={p.y + p.height / 2} textAnchor="middle" fontSize={10 / scale} fill="#526174" pointerEvents="none">Emplacement vide</text></g>)}
        {selectedBox && <rect x={selectedBox.x} y={selectedBox.y} width={selectedBox.width} height={selectedBox.height} fill="none" stroke="#0876d9" strokeWidth={3 / scale} pointerEvents="none" />}
        {placed.filter(p => p.node.kind === 'split').map(p => {
          if (p.node.kind !== 'split') return null
          const vertical = p.node.axis === 'x', at = (vertical ? p.x : p.y) + ((vertical ? p.width : p.height) - s.compositionJeu) * p.node.ratio + s.compositionJeu / 2
          return <line key={p.node.id} x1={vertical ? at : p.x} x2={vertical ? at : p.x + p.width} y1={vertical ? p.y : at} y2={vertical ? p.y + p.height : at}
            stroke="transparent" strokeWidth={10 / scale} style={{ cursor: vertical ? 'ew-resize' : 'ns-resize' }} role="slider" tabIndex={0}
            aria-label={`Séparation ${p.node.id}`} aria-orientation={vertical ? 'horizontal' : 'vertical'} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(p.node.ratio * 100)}
            data-separation-id={p.node.id} onPointerDown={e => start(e, p.node.id, 'split')}
            onKeyDown={e => {
              if (!tree || !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) return
              e.preventDefault(); const step = (e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 1) * (e.shiftKey ? 10 : 1)
              const result = moveSeparation(tree, p.node.id, at + step, s.width, s.height, s.compositionJeu, s.compositionMin)
              if (result) change({ compositionTree: result.tree }, `compositionKey:${p.node.id}`)
            }} />
        })}
        {ghost && <rect {...ghost} fill={invalid ? '#d22a40' : '#0876d9'} opacity=".13" stroke={invalid ? '#d22a40' : '#0876d9'} strokeWidth={2 / scale} pointerEvents="none" />}
      </g>
    </svg>
    {guide && <div className="composition-drag-hint" role="status" data-invalid={invalid}>{guide}</div>}
    {menu && <PanelContextMenu s={s} panelId={menu.id} x={menu.x} y={menu.y} close={closeMenu} change={change} selection={selection} setSelection={setSelection} />}
  </div>
}
