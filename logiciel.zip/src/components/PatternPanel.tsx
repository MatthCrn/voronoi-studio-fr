import { memo } from 'react'
import { RANGES, type Settings } from '../lib/settings'
import { formatLength } from '../lib/units'
import { Button, DraftNumber, LengthField, NumberField, Section, Segmented, SliderField, SwitchField, type Option } from './Controls'
import type { Placement } from '../voronoi/seeding'
import type { DensityMode } from '../voronoi/density'
import type { SpatialMetrics } from '../voronoi/spatialHoles'
import { SpatialPanel } from './SpatialPanel'

export type Change = (patch: Partial<Settings>, key?: string) => void

const PLACEMENTS: Option<Placement>[] = [
  { value: 'random', label: "Aléatoire", tip: "Les points sont placés librement : la taille des cellules varie et des groupes peuvent se former." },
  { value: 'even', label: "Répartie", tip: "La répartition par disques de Poisson préserve une distance minimale entre les points pour un aspect régulier et naturel." },
  { value: 'hex', label: "Hexa.", tip: "Une grille hexagonale produit un nid d’abeilles. La dispersion rend le motif moins régulier." },
  { value: 'square', label: "Carrée", tip: "Une grille carrée produit des cellules carrées. La dispersion rend le motif moins régulier." },
]
const PLACEMENT_HINT: Record<Placement, string> = {
  random: "Aléatoire : les points sont placés librement, avec des cellules de tailles variées et des regroupements.",
  even: "Répartie : l’espacement minimal assure une répartition homogène tout en gardant un aspect naturel.",
  hex: "Hexagonale : une grille en nid d’abeilles. La dispersion décale les points pour un aspect moins régulier.",
  square: "Carrée : une grille carrée. La dispersion décale les points pour un aspect moins régulier.",
}
const DENSITIES: Option<DensityMode>[] = [
  { value: 'none', label: "Aucun", tip: "Les cellules ont à peu près la même taille partout." },
  { value: 'linear', label: "Linéaire", tip: "Les cellules deviennent plus petites vers un côté du support." },
  { value: 'radial', label: "Radial", tip: "Les cellules deviennent plus petites vers le centre ou vers le bord." },
]

// Memoised: the panel only re-renders when its own props change, not on every relax step.
export const PatternPanel = memo(function PatternPanel({ s, change, stale, onApply, actualCount, autoSpacingValue, exactSpacing, capped, onShuffle, spatialMetrics }: {
  s: Settings; change: Change; stale: boolean; onApply: () => void; actualCount: number; autoSpacingValue: number
  exactSpacing: () => number; capped: boolean; onShuffle: () => void
  spatialMetrics?: SpatialMetrics
}) {
  const grid = s.placement === 'hex' || s.placement === 'square'
  const spacingOff = s.placement === 'random' && "La répartition aléatoire ne comporte pas de réglage d’espacement."
  const countLocked = !s.autoSpacing && s.placement !== 'random' && "L’espacement détermine le nombre de cellules. Activez l’espacement automatique pour choisir ce nombre."
  const densityOff = (s.spatialEnabled && s.spatialDensity && 'Le gradient est piloté par la section Variation spatiale.')
    || (grid && "Les gradients fonctionnent avec les répartitions aléatoire et répartie. Les grilles restent régulières.")
  return <>
    {stale && <div className="notice" role="status">
      <p>Vous avez retouché des points : les nouveaux réglages du motif ne sont pas encore appliqués.</p>
      <Button className="primary wide" tip="Créer un motif avec ces réglages. Les retouches seront remplacées ; Annuler permet de les retrouver." onClick={onApply}>Appliquer les réglages…</Button>
    </div>}

    <Section title="Points">
      <div className="field count-field" data-tip={countLocked || "Nombre de cellules à créer. Les grilles arrondissent à des rangées entières."}>
        <span className="field-label">
          <span id="count-label">Cellules</span>
          <DraftNumber className="number-input inline-number" labelledBy="count-label" min={RANGES.count[0]} max={RANGES.count[1]}
            value={s.count} disabled={Boolean(countLocked)} onChange={v => change({ count: Math.round(v) }, 'count')} />
        </span>
        <input type="range" aria-labelledby="count-label" min={Math.log(RANGES.count[0])} max={Math.log(RANGES.count[1])} step="any" value={Math.log(s.count)}
          disabled={Boolean(countLocked)} aria-valuetext={`${s.count} cellules`}
          style={{ '--fill': `${((Math.log(s.count) - Math.log(RANGES.count[0])) / (Math.log(RANGES.count[1]) - Math.log(RANGES.count[0])) * 100).toFixed(1)}%` } as React.CSSProperties}
          onChange={event => change({ count: Math.round(Math.exp(Number(event.currentTarget.value))) }, 'count')} />
      </div>
      {(grid || countLocked || capped) && <p className="hint">{capped ? "Limite de 20 000 points atteinte. Augmentez l’espacement." : `${actualCount.toLocaleString('fr-FR')} cellules créées.`}</p>}

      <Segmented label="Répartition" options={PLACEMENTS} value={s.placement} onChange={placement => change({ placement }, 'placement')} />
      <p className="hint">{PLACEMENT_HINT[s.placement]}</p>

      <details className="more"><summary>Réglages des points</summary>
      <SwitchField label="Espacement automatique" checked={s.autoSpacing || s.placement === 'random'} unavailable={spacingOff}
        tip="Activé : l’espacement suit le nombre de cellules et les dimensions du support. Désactivé : vous fixez l’espacement et le nombre s’adapte."
        onChange={autoSpacing => change(autoSpacing ? { autoSpacing } : { autoSpacing, spacing: +exactSpacing().toFixed(4) }, 'autoSpacing')} />
      <LengthField label={s.placement === 'even' ? "Espacement minimal" : "Pas de la grille"} mm={s.autoSpacing ? autoSpacingValue : s.spacing}
        min={RANGES.spacing[0]} max={RANGES.spacing[1]} units={s.units} dpi={s.dpi} small
        unavailable={spacingOff || (s.autoSpacing && `L’espacement automatique vaut environ ${formatLength(autoSpacingValue, s.units, s.dpi, true)} pour ce nombre. Désactivez-le pour fixer votre propre valeur.`)}
        tip={s.placement === 'even' ? "Distance minimale autorisée entre points, dans la zone la moins dense du gradient." : "Distance entre les points voisins de la grille."}
        onChange={spacing => change({ spacing }, 'spacing')} />
      <SliderField label="Dispersion" value={Math.round(s.jitter * 100)} min={0} max={100} format={v => `${v} %`}
        unavailable={!grid && "La dispersion s’applique uniquement aux grilles hexagonales et carrées."}
        tip="Décalage maximal de chaque point de grille, en proportion de la moitié du pas." onChange={v => change({ jitter: v / 100 }, 'jitter')} />

        <div className="seed-row">
          <NumberField label="Graine" value={s.seed} min={RANGES.seed[0]} max={RANGES.seed[1]} compact
            tip="La même graine et les mêmes réglages donnent toujours le même motif. Notez-la pour reproduire le dessin." onChange={seed => change({ seed: Math.round(seed) }, 'seed')} />
          <Button tip="Choisir une nouvelle graine aléatoire pour créer un motif avec les mêmes réglages." shortcut="G" onClick={onShuffle}>Nouvelle graine</Button>
        </div>
        <SliderField label="Essais par point" value={s.tries} min={RANGES.tries[0]} max={RANGES.tries[1]}
          unavailable={s.placement !== 'even' && "Les essais concernent uniquement la répartition répartie."}
          tip="Nombre de positions essayées autour de chaque point. Une valeur élevée densifie le placement mais prend plus de temps ; 30 est la valeur courante." onChange={tries => change({ tries }, 'tries')} />
      </details>
    </Section>

    <SpatialPanel s={s} change={change} metrics={spatialMetrics} />
    <details className="more"><summary>Densité indépendante</summary>
    <Section title="Gradient de densité">
      <Segmented label="Gradient" hideLabel options={DENSITIES} value={s.density} unavailable={densityOff} onChange={density => change({ density }, 'density')} />
      {densityOff ? <p className="hint">{densityOff}</p> : s.density !== 'none' && <>
        <SliderField label="Intensité" value={s.densityStrength} min={RANGES.densityStrength[0]} max={RANGES.densityStrength[1]} step={0.5}
          format={v => `${v}×`} tip="Rapport de surface entre les plus grandes et les plus petites cellules." onChange={densityStrength => change({ densityStrength }, 'densityStrength')} />
        {s.density === 'linear'
          ? <SliderField label="Direction" value={s.densityAngle} min={0} max={355} step={5} format={v => `${v}°`}
            tip="Les cellules deviennent plus petites dans cette direction. 0° vers la droite, 90° vers le haut." onChange={densityAngle => change({ densityAngle }, 'densityAngle')} />
          : <Segmented label="Petites cellules au" value={s.densityInvert ? 'edge' : 'centre'} onChange={v => change({ densityInvert: v === 'edge' }, 'densityInvert')}
            options={[{ value: 'centre', label: "Centre", tip: "Les plus petites cellules se regroupent au centre." }, { value: 'edge', label: "Bord", tip: "Les plus petites cellules se regroupent près du bord." }]} />}
      </>}
    </Section>

    </details>
    <details className="more"><summary>Régularité des cellules</summary>
    <Section title="Relaxation">
      <SliderField label="Itérations à la génération" value={s.relaxSteps} min={RANGES.relaxSteps[0]} max={RANGES.relaxSteps[1]}
        tip="Nombre d’itérations de relaxation de Lloyd appliquées à chaque nouveau motif et à chaque clic sur Relaxer." onChange={relaxSteps => change({ relaxSteps }, 'relaxSteps')} />
      <p className="hint">Chaque itération déplace les points au centre de leur cellule. De 1 à 3 itérations donnent un aspect naturel et homogène ; davantage rendent le motif très régulier. <b>Relaxer</b> et <b>Relaxation auto</b> se trouvent dans la barre sous le support.</p>
    </Section>
    </details>
  </>
})
