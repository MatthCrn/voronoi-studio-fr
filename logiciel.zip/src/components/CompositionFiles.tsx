import { Button, Section } from './Controls'
export type CompositionExport = 'plan-svg' | 'plan-dxf' | 'png' | 'zip' | 'csv' | 'panel-svg' | 'panel-dxf'
export function CompositionFiles({ blocked, selectedPanel, exportFile }: { blocked: string | false; selectedPanel: string | null; exportFile: (kind: CompositionExport) => void }) {
  return <>
    <Section title="Plan d’ensemble">
      <div className="button-row"><Button tip="Plan d’assemblage en SVG, avec identifiants et dimensions en millimètres." unavailable={blocked} onClick={() => exportFile('plan-svg')}>Plan SVG</Button>
        <Button tip="Contours et motifs en DXF à leur position réelle, sur des calques distincts par panneau." unavailable={blocked} onClick={() => exportFile('plan-dxf')}>Plan DXF</Button>
        <Button tip="Image de la composition avec ses repères de panneaux." unavailable={blocked} onClick={() => exportFile('png')}>PNG</Button></div>
      <Button className="wide" tip="Liste des panneaux, dimensions, positions et jeu, en millimètres, pour un tableur." unavailable={blocked} onClick={() => exportFile('csv')}>Tableau des dimensions CSV</Button>
    </Section>
    <Section title="Panneaux séparés">
      <Button className="primary wide" tip="Archive contenant les SVG laser et DXF de chaque panneau, le plan, le tableau des dimensions et le projet complet." unavailable={blocked} onClick={() => exportFile('zip')}>Exporter tous les panneaux ZIP</Button>
      <div className="button-row"><Button tip="SVG laser du panneau sélectionné, aux dimensions réelles, avec son origine en haut à gauche." unavailable={blocked || (!selectedPanel && 'Sélectionnez un panneau individuel.')} onClick={() => exportFile('panel-svg')}>SVG du panneau</Button>
        <Button tip="DXF du panneau sélectionné, avec son origine locale et ses dimensions réelles." unavailable={blocked || (!selectedPanel && 'Sélectionnez un panneau individuel.')} onClick={() => exportFile('panel-dxf')}>DXF du panneau</Button></div>
      <p className="hint">{selectedPanel ? `Sélection : ${selectedPanel}. ` : ''}Chaque fichier de panneau comprend son contour et le motif activé sur ce panneau. Les points et Delaunay sont exclus. Le plan SVG porte les cotes ; les fichiers laser individuels ne contiennent pas ces annotations.</p>
      {blocked && <p className="hint error" role="status">{blocked}</p>}
    </Section>
  </>
}
