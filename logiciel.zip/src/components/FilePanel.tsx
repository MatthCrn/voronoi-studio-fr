import { memo, type ReactNode } from 'react'
import { cutContents, cutLayers, listWords } from '../lib/cutPaths'
import { pngProblem } from '../lib/render'
import type { Settings } from '../lib/settings'
import { pixelSize, UNIT_NAME } from '../lib/units'
import { holeCount } from '../voronoi/shape'
import { Button, Section, SwitchField } from './Controls'
import type { Change } from './PatternPanel'

export type ExportKind = 'png' | 'svg' | 'laser' | 'dxf'

// Memoised: the panel only re-renders when its own props change, not on every relax step.
export const FilePanel = memo(function FilePanel({ s, change, unsaved, busy, onNew, onOpen, onSave, onExport, openError, exportSection }: {
  s: Settings; change: Change; unsaved: boolean; busy: boolean
  onNew: () => void; onOpen: () => void; onSave: () => void; onExport: (kind: ExportKind) => void; openError: string
  exportSection?: ReactNode
}) {
  const [pw, ph] = pixelSize(s.width, s.height, s.dpi)
  const pngBlocked = pngProblem(pw, ph)
  const fileUnits = s.units === 'in' ? "pouces" : "millimètres"
  const working = busy && "Attendez la fin de la mise à jour du motif."
  const contents = cutContents(s)
  const nothing = !contents.length && `Aucun élément à découper. Activez Points, ${s.cellStyle === 'holes' ? "Ajours" : "Arêtes"} ou Delaunay au-dessus du support, ou incluez son contour.`
  const layers = cutLayers(s, s.shape === 'custom' && !!s.customShape && holeCount(s.customShape) > 0)
  return <>
    <Section title="Projet">
      <p className="hint save-state">{unsaved ? <><span className="dot" aria-hidden="true" />Modifications non enregistrées depuis la dernière sauvegarde.</> : "Toutes les modifications sont enregistrées."}</p>
      <div className="button-row three">
        <Button tip="Créer un nouveau dessin avec les réglages par défaut." onClick={onNew}>Nouveau</Button>
        <Button tip="Ouvrir un projet Voronoi Studio (.voronoi.json)." shortcut="⌘O" onClick={onOpen}>Ouvrir…</Button>
        <Button className="primary" tip="Enregistrer les réglages et tous les points, y compris les retouches, dans un projet réutilisable." shortcut="⌘S" unavailable={working} onClick={onSave}>Enregistrer</Button>
      </div>
      {openError && <p className="hint error" role="alert">{openError}</p>}
    </Section>

    {exportSection ?? <><Section title="Pour la découpe">
      <div className="button-row">
        <Button tip={`Tracés fins en ${fileUnits} à l’échelle réelle pour LightBurn, Glowforge et les autres logiciels laser : découpes en rouge, ajours en premier, points et lignes de Delaunay dans leurs couleurs si affichés.`} unavailable={working || nothing} onClick={() => onExport('laser')}>SVG laser</Button>
        <Button tip={`DXF AutoCAD R12 en ${fileUnits}, avec de vrais arcs pour les arrondis et des calques distincts pour les points et Delaunay si affichés ; pour Fusion, Illustrator, VCarve et la FAO.`} unavailable={working || nothing} onClick={() => onExport('dxf')}>DXF</Button>
      </div>
      <SwitchField label="Inclure le contour du support" checked={s.sheetOutline}
        tip="Ajouter le contour extérieur du support sur un calque distinct, après les découpes intérieures." onChange={sheetOutline => change({ sheetOutline }, 'sheetOutline')} />
      <p className="hint">{nothing || <>Les fichiers de découpe contiennent les éléments affichés : {listWords(contents)}, chaque ligne une seule fois. Calques : {listWords(layers)}.</>}</p>
    </Section>

    <Section title="Pour le graphisme">
      <div className="button-row">
        <Button tip={`Le dessin tel qu’affiché, avec ses couleurs, points et lignes de Delaunay visibles, en ${s.units === 'px' ? 'pixels' : UNIT_NAME[s.units === 'in' ? 'in' : 'mm']}.`}
          unavailable={working} onClick={() => onExport('svg')}>SVG</Button>
        <Button tip={`Une image de ${pw.toLocaleString('fr-FR')} × ${ph.toLocaleString('fr-FR')} px à ${s.dpi} pixels par pouce.`} unavailable={working || (pngBlocked ?? false)} onClick={() => onExport('png')}>PNG</Button>
      </div>
      <SwitchField label="Fond PNG transparent" checked={s.transparentPng}
        tip="Exporter le PNG sans le fond du support." onChange={transparentPng => change({ transparentPng }, 'transparentPng')} />
      <p className="hint">{pngBlocked ?? `PNG: ${pw.toLocaleString('fr-FR')} × ${ph.toLocaleString('fr-FR')} px. Les exports représentent toujours le support entier, quel que soit le zoom.`}</p>
    </Section>
    </>}
  </>
})
