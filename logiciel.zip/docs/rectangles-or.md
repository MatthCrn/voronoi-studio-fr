# Dimensions libres et rectangles d’or

Les formats de supports prédéfinis ont été retirés du panneau. Largeur et hauteur
sont accessibles directement. **Rectangles d’or** lie les dimensions selon l’une
des quinze proportions de Jean-Pierre Grosjean, *Le Nombre d’Or*, éditions H. Vial,
chapitres « Les rectangles liés au nombre d’Or » et classement p. 50.

Référence consultée : https://fr.scribd.com/doc/251310101/Grosjean-Jean-Pierre-Le-nombre-d-or
Un second exemplaire transcrit permet de recouper le classement :
https://fr.scribd.com/document/336422669/Le-nombre-d-or-1-618-pdf
Les silhouettes de l’interface sont dessinées par le logiciel à partir des rapports.
Elles ne reproduisent pas les illustrations du livre.

## Utilisation

1. Saisir la largeur ou la hauteur souhaitée.
2. Activer **Rectangles d’or**. La dernière dimension saisie reste fixe.
3. Ouvrir la galerie en cliquant sur le nom du rectangle sélectionné.
4. Comparer les quinze silhouettes, du rectangle le plus compact au plus allongé.
5. Modifier l’une des dimensions : elle devient la nouvelle dimension conservée.
6. Permuter largeur/hauteur pour changer l’orientation ; le rapport reste lié.

Désactiver l’interrupteur conserve les dimensions obtenues. Le choix de forme,
le verrouillage et la dimension conservée sont enregistrés dans le projet.
Annuler/rétablir restaure les dimensions et le choix ensemble.

Les unités, la forme, l’import SVG, la résolution et le comportement des points
restent disponibles dans deux sections repliées. L’option s’applique aux supports
rectangulaires. Choisir une ellipse ou une forme importée désactive le verrouillage,
en conservant les règles habituelles des formes importées.

## Rapports calculés

φ = (1 + √5) / 2. Les valeurs affichées sont arrondies à quatre décimales ;
les calculs et les fichiers utilisent les rapports complets.

| Forme | Expression du rapport grand côté / petit côté | Valeur affichée |
|---|---|---:|
| VII | √(φ / (4 − φ²)), demi-Parthénon | 1,0820 |
| XV | φ^(1/4) | 1,1278 |
| II | √φ, Chéops | 1,2720 |
| V | cot(36°) | 1,3764 |
| III | √(φ² − 1/4) | 1,5388 |
| I | φ | 1,6180 |
| XII | φ^(3/2) | 2,0582 |
| VI | √(4φ / (4 − φ²)), Parthénon | 2,1641 |
| VIII | √5 | 2,2361 |
| IX | φ² | 2,6180 |
| IV | 2 cot(36°) | 2,7528 |
| XIII | φ^(5/2) | 3,3302 |
| X | φ³ | 4,2361 |
| XIV | φ^(7/2) | 5,3884 |
| XI | φ⁴ | 6,8541 |

Le rapport exact du Parthénon est calculé à partir de sa propriété géométrique :
le rapport entre la diagonale du rectangle et celle de son demi-rectangle vaut φ.
Avec r = grand côté / petit côté, cela donne
(r² + 1) / (r²/4 + 1) = φ², donc r² = 4φ / (4 − φ²).

Les dimensions restent dans les limites physiques de l’application, de 5 à
5 000 mm pour chaque côté. Aux limites, la dimension saisissable est bornée afin
de respecter également l’autre côté et de conserver le rapport. Les dimensions
ne sont pas arrondies en interne aux chiffres affichés dans les champs.

Les nouveaux projets utilisent le format version 6. Les versions 1 à 5 restent
lisibles, avec le verrouillage désactivé par défaut. Les versions précédentes du
logiciel ne savent pas ouvrir les nouveaux projets.

## Composition

La version 1.9 ajoute la composition de plusieurs panneaux dans un format global
proportionné : voir [le guide](composition.md). Les rectangles concentriques
avec une succession de bordures constantes restent une évolution ultérieure.
