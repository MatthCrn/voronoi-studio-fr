# Mises à jour Windows

La version 1.7.0 ajoute le mécanisme, sans service distant configuré par défaut.
Le menu **Application > Mises à jour…** permet d’enregistrer une adresse HTTPS
lorsqu’un hébergement sera disponible. Ajouter cette adresse ne nécessite pas
de reconstruire ou réinstaller l’application. Aucun identifiant ou jeton n’est
embarqué dans les sources, l’application ou le flux.

## Parcours utilisateur

- Vérification au démarrage, désactivable, ou bouton **Vérifier maintenant**.
- Nouvelle version proposée avec ses notes ; aucun téléchargement automatique.
- Bouton **Télécharger**, progression et possibilité de continuer à dessiner.
- Bouton **Redémarrer et mettre à jour** après téléchargement vérifié.
- L’installation se fait alors sans repasser par les écrans de l’installateur,
  puis relance l’application.
- Avant le redémarrage, le dessin et l’état non enregistré sont écrits sans
  attendre l’autosauvegarde habituelle. Une copie du projet est également
  conservée dans `update-session-backup.json`, dans le dossier de données de
  l’application. Si cette sauvegarde échoue, le redémarrage est annulé.
- Quitter normalement ne déclenche jamais une installation en attente.
- En cas d’échec réseau ou de téléchargement, la version courante reste utilisée.

La version portable ne s’installe pas automatiquement et reste à remplacement
manuel. Le mode développement ne lance aucun installateur. Les données des
projets ne sont pas envoyées au serveur de mises à jour.

## Préparer une version

1. Augmenter la version stable dans `package.json`.
2. Adapter les notes de version du générateur de flux.
3. Exécuter `pnpm desktop:build` : tests à effectuer avant diffusion.
4. Publier l’installateur `*-installation.exe` et son fichier `.blockmap` dans
   le même dossier HTTPS. Vérifier leur disponibilité.
5. Publier **latest.yml en dernier**, pour ne jamais annoncer un fichier absent.
6. Configurer l’adresse du dossier dans l’application.

Le serveur doit fournir les fichiers directement, sans formulaire de connexion.
Un hébergement statique HTTPS convient. L’espace de prévisualisation Web privé
actuel n’est pas utilisé comme service de mises à jour. Le dépôt Git du créateur
original n’est pas une destination de publication de l’adaptation française.
Les anciens installateurs et leurs blockmaps peuvent être conservés pour
permettre les téléchargements différentiels ; un téléchargement complet reste
possible si une ancienne blockmap manque.

Le téléchargement est contrôlé par l’empreinte SHA-512 du flux. Comme les versions
précédentes, cette distribution n’a pas de certificat commercial de signature
Windows. Protéger l’accès en écriture à l’hébergement des versions. Aucun contrôle
TLS ou contrôle de signature n’est désactivé dans le programme.

## Validation et limite actuelle

Les tests couvrent les états de mise à jour, les échecs, la sauvegarde obligatoire,
le refus de rétrograder, les actions explicites et la configuration HTTPS.
Un essai avec le vrai moteur Electron vérifie la détection d’une version,
le téléchargement exact et le rejet d’un fichier altéré, sans exécuter ce fichier.
Le raccordement à un service publié et un essai de remplacement d’une version
installée restent nécessaires avant de déclarer le déploiement opérationnel.
Cette livraison n’installe rien à la place du logiciel existant de l’utilisateur.
